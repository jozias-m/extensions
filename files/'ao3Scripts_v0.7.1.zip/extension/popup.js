let links = [];
let downloadList;
let downloadItemCounter = localStorage.getItem("pap_downloadItemCounter");
if (downloadItemCounter == null) downloadItemCounter = 9
downloadItemCounter = sequenceFixedGrowthGenerator(downloadItemCounter, 1);
localStorage.setItem("pap_downloadItemCounter", downloadItemCounter);

function popupSend(message, action = "popup") {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;

    chrome.tabs.sendMessage(tabs[0].id, {
      actionType: action,
      payload: message
    });
  });
}

function popupReceive() {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log("Popup received:", message.payload);
    downloadList = message.payload.page.toString().split(",");
    if (downloadList) downloadList.shift()
    if (downloadList) downloadItems(1, false)
  });
}


function downloadItems(downloadedItemsCount, Qbool) {
  QdownloadFileUpdateNeeded = false;
  if (downloadedItemsCount == 0) {
    return;
  }
  if (downloadList == undefined) {
    return;
  }
  if (downloadList[0] == null) {
    return;
  }

  for (let i = 0; i < downloadedItemsCount; i++) {
    console.log(downloadList[i]);
    localStorage.setItem(`pap_${downloadItemCounter}`, downloadList[i]);
    localStorage.setItem("pap_downloadIndex", localStorage.getItem("pap_downloadIndex") + "," + downloadItemCounter)
    downloadItemCounter = sequenceFixedGrowthGenerator(downloadItemCounter, 1);
    localStorage.setItem("pap_downloadItemCounter", downloadItemCounter);
    if (!downloadList[i]) Qbool = true;
  }

  if (!Qbool) {
    popupSend({ action: "post", downloadList: downloadList.slice(downloadedItemsCount) }, "download");
  }
}

function updateDownload() {
  downloadItems(1, false);

  downloadIndex = localStorage.getItem("pap_downloadIndex");
  if (downloadIndex) {
    downloadIndex = downloadIndex.toString().split(",");
    for (let i = 0; i < downloadIndex.length; i++) {
      links[i] = localStorage.getItem(`pap_${downloadIndex[i]}`);
    }
    for (let i = 0; i < links.length; i++) {
      if (links[i] && links[i] != 'null' && links[i] != 'undefined') {
        console.log(`${links[i]}`);
      }
    }
    let fileDownloadList = document.getElementById("fileDownloadList");
    fileDownloadList.textContent = "";
    for (let i = 0; i < links.length; i++) {
      let div = document.createElement("div");

      div.className = "fileDownloadListItem";
      div.setAttribute("--data-downloadItem", `${links[i]}`);
      // div.textContent = ``;

      let a = document.createElement("a");

      a.href = `${links[i]}`;
      a.innerText = `${links[i]}`;

      div.appendChild(a);

      fileDownloadList.appendChild(div);
    }
  }
}

function downloadAll() {
  downloadIndex = localStorage.getItem("pap_downloadIndex").toString().split(",");
  localStorage.removeItem("pap_downloadIndex");
  for (let i = 0; i < downloadIndex.length; i++) {
    links[i] = localStorage.getItem(`pap_${downloadIndex[i]}`);
    console.log(links[i]);
    localStorage.removeItem(`pap_${downloadIndex[i]}`);
  }
  downloadItemCounter = 9;
  downloadItemCounter = sequenceFixedGrowthGenerator(downloadItemCounter, 1);
  localStorage.setItem("pap_downloadItemCounter", downloadItemCounter);
  for (let i = 0; i < links.length; i++) {
    if (links[i] && links[i] != 'null' && links[i] != 'undefined') {
      console.log(`${links[i]}`);
      window.open(links[i]);
    }
  }
}

updateDownload();
popupReceive();

function sequenceFixedGrowthGenerator(num, growthRate) {
  return (Math.ceil(num * (1 + growthRate / 100)) + growthRate);
}
function generateIndependentSeeds(growthRate, maxSeeds = 10) {
  const f = (n) =>
    Math.ceil(n * (1 + growthRate / 100)) + growthRate;

  const visited = new Set();
  const seeds = [];

  let candidate = 1;

  while (seeds.length < maxSeeds) {
    if (!visited.has(candidate)) {
      // new independent seed found
      seeds.push(candidate);

      // generate its sequence until Infinity
      let n = candidate;
      while (Number.isFinite(n) && !visited.has(n)) {
        visited.add(n);
        n = f(n);
      }
    }
    candidate++;
  }

  return seeds;
}
// generateIndependentSeeds(9, i).slice(-1)[0];

function hertoryLoggerToggleButtonF() {
  let hertoryLoggerToggleButton = document.getElementById("hertoryLoggerToggleButton");
  if (hertoryLoggerToggleButton.innerText == "on") {
    hertoryLoggerToggleButton.innerText = "off";
  } else {
    hertoryLoggerToggleButton.innerText = "on";
  }
  // updateSettings();
}
function removeHerstorybtnToggleButtonF() {
  let removeHerstorybtnToggleButton = document.getElementById("removeHerstorybtnToggleButton");
  if (removeHerstorybtnToggleButton.innerText == "on") {
    removeHerstorybtnToggleButton.innerText = "off";
  } else {
    removeHerstorybtnToggleButton.innerText = "on";
  }
  // updateSettings();
}
function archiveWorksToggleButtonF() {
  let archiveWorksToggleButton = document.getElementById("archiveWorksToggleButton");
  let archiveWoksSection = document.getElementById("archiveWoksSection");
  if (archiveWorksToggleButton.innerText == "on") {
    archiveWorksToggleButton.innerText = "off";
    archiveWoksSection.setAttribute("style", "display: none");
  } else {
    archiveWorksToggleButton.innerText = "on";
    archiveWoksSection.setAttribute("style", "display: block");
  }
  // updateSettings();
}
function customScriptsToggleButtonF() {
  let customScriptsToggleButton = document.getElementById("customScriptsToggleButton");
  let customScriptsSection = document.getElementById("customScriptsSection");
  if (customScriptsToggleButton.innerText == "on") {
    customScriptsToggleButton.innerText = "off";
    customScriptsSection.setAttribute("style", "display: none");
  } else {
    customScriptsToggleButton.innerText = "on";
    customScriptsSection.setAttribute("style", "display: block");
    refeshCustomScriptHolder();
  }
  // updateSettings();
}
function customScoreRatingSystemToggleButtonF() {
  let customScoreRatingSystemToggleButton = document.getElementById("customScoreRatingSystemToggleButton");
  let customScoreRatingSystemSection = document.getElementById("customScoreRatingSystemSection");
  if (customScoreRatingSystemToggleButton.innerText == "on") {
    customScoreRatingSystemToggleButton.innerText = "off";
    customScoreRatingSystemSection.setAttribute("style", "display: none");
  } else {
    customScoreRatingSystemToggleButton.innerText = "on";
    customScoreRatingSystemSection.setAttribute("style", "display: block");
  }
  // updateSettings();
}

function updateSettings() {
  if (hertoryLoggerToggleButton.innerText == "on") QherstoryLogger = true;
  if (removeHerstorybtnToggleButton.innerText == "on") QremoveClearHerstoryButton = true;
  if (archiveWorksToggleButton.innerText == "on") QarchiveWorks = true;
  if (customScriptsToggleButton.innerText == "on") QcustomScripts = true;

  if (hertoryLoggerToggleButton.innerText == "off") QherstoryLogger = false;
  if (removeHerstorybtnToggleButton.innerText == "off") QremoveClearHerstoryButton = false;
  if (archiveWorksToggleButton.innerText == "off") QarchiveWorks = false;
  if (customScriptsToggleButton.innerText == "off") QcustomScripts = false;

  // popupSend({ action: "post", QherstoryLogger: QherstoryLogger, QremoveClearHerstoryButton: QremoveClearHerstoryButton, QarchiveWorks: QarchiveWorks, QcustomScripts: QcustomScripts }, "settings");
}
function _jsonify(input) {
  let output;

  try {
    if (typeof input === "object") {
      output = input;
    } else {
      output = JSON.parse(input);
    }
  } catch (e) {
    output = [{ data: input }];
  }

  return output;
}
function refeshCustomScriptHolder() {
  let scriptIndex = localStorage.getItem("scriptIndexList");
  if (scriptIndex == undefined) scriptIndex = "";
  scriptIndex = scriptIndex.split(",").slice(1);

  customScriptHolder = document.getElementById("customScriptHolder");
  customScriptHolder.textContent = "";
  scriptIndex.forEach(scriptName => {
    if (scriptName == "") { } else {
      outerDiv = document.createElement("div");
      outerDiv.textContent = scriptName;
      outerDiv.id = `scriptInjecButon${scriptName}`;

      innerDiv = document.createElement("div");
      innerDiv.className = "scriptListItem";
      innerDiv.textContent = localStorage.getItem(scriptName);

      outerDiv.appendChild(innerDiv);
      customScriptHolder.appendChild(outerDiv);


      nButton = document.createElement("button");

      nButton.id = `scriptInjecButon${scriptName}`;
      nButton.className = `scriptInjecButon`;
      nButton.textContent = 'Activate';

      outerDiv.appendChild(nButton);

      nBtn = document.getElementById(`scriptInjecButon${scriptName}`);
      nBtn.addEventListener("click", addScript, false);
      nBtn.scriptContents = `${localStorage.getItem(scriptName)}`;
    }
  });
}
document.addEventListener("DOMContentLoaded", () => {
  const downloadBtn = document.getElementById("downloadAll");

  downloadBtn.addEventListener("click", downloadAll);


  const downloadBtn2 = document.getElementById("updateDownload");

  downloadBtn2.addEventListener("click", updateDownload);

  updateDownload();

  const hertoryLoggerToggleButton = document.getElementById("hertoryLoggerToggleButton");
  const removeHerstorybtnToggleButton = document.getElementById("removeHerstorybtnToggleButton");
  const archiveWorksToggleButton = document.getElementById("archiveWorksToggleButton");
  const customScriptsToggleButton = document.getElementById("customScriptsToggleButton");
  const customScoreRatingSystemToggleButton = document.getElementById("customScoreRatingSystemToggleButton");
  const newScriptButton = document.getElementById("newScriptButton");
  const customScriptEditButton = document.getElementById("customScriptEditButton");
  const setWeightsButton = document.getElementById("setWeightsButton");

  hertoryLoggerToggleButton.addEventListener("click", hertoryLoggerToggleButtonF);
  removeHerstorybtnToggleButton.addEventListener("click", removeHerstorybtnToggleButtonF);
  archiveWorksToggleButton.addEventListener("click", archiveWorksToggleButtonF);
  customScriptsToggleButton.addEventListener("click", customScriptsToggleButtonF);
  customScoreRatingSystemToggleButton.addEventListener("click", customScoreRatingSystemToggleButtonF);
  newScriptButton.addEventListener("click", makeNewScript);
  customScriptEditButton.addEventListener("click", editScripts)
  setWeightsButton.addEventListener("click", setWeights);
});

function addScript(script = `logConsole("injected via popup");`) {
  console.log(`Sending: ${script.currentTarget.scriptContents}`);
  popupSend({ action: "post", script: script.currentTarget.scriptContents }, "scriptAdd");
}

addScript(`logConsole("Scripts: popup.js, content.js and injected.js are working.");`);

function makeNewScript() {
  let scriptName = prompt("enter unqiue name of script");
  let Qvalid = true;
  // let indexCounter = 0;
  let newScript = prompt("paste script");
  let scriptIndex = localStorage.getItem("scriptIndexList");
  if (scriptIndex == undefined) scriptIndex = "";

  scriptIndex = scriptIndex.split(",");
  scriptIndex.forEach(element => {
    if (element == scriptName) {
      Qvalid = false;
    }
  });
  if (Qvalid) {
    scriptIndex += `,${scriptName}`;
    localStorage.setItem("scriptIndexList", scriptIndex);
    localStorage.setItem(scriptName, newScript);
  }
  refeshCustomScriptHolder()
}
function editScripts() {
  let customScriptEditButton = document.getElementById("customScriptEditButton");
  let customScriptEditBar = document.getElementById("customScriptEditBar");
  if (customScriptEditButton.innerText == `✎`) {
    let scriptIndex = localStorage.getItem("scriptIndexList");
    if (scriptIndex == undefined) scriptIndex = "";
    scriptIndex = scriptIndex.split(",").slice(1);

    customScriptEditBar.textContent = "";
    customScriptEditBar.style = "display: block;";
    scriptIndex.forEach(scriptName => {
      customScriptEditButton.innerText = "X";
      if (scriptName == "") { } else {

        outerDiv = document.createElement("div");
        // outerDiv.textContent = scriptName;
        outerDiv.id = `scriptEditDiv${scriptName}`;


        innerDiv = document.createElement("div");
        innerDiv.className = "scriptListItem";
        innerDiv.textContent = scriptName;

        outerDiv.appendChild(innerDiv);
        customScriptEditBar.appendChild(outerDiv);


        nButton = document.createElement("button");

        nButton.id = `scriptEditBtn${scriptName}`;
        nButton.className = `scriptEditBtn`;
        nButton.textContent = 'Delete';

        innerDiv.appendChild(nButton);

        br = document.createElement("br")
        outerDiv.appendChild(br);

        nBtn = document.getElementById(`scriptEditBtn${scriptName}`);
        nBtn.addEventListener("click", delScript, false);
        nBtn.scriptName = `${scriptName}`;
      }
    });
  } else {
    customScriptEditButton.innerText = "✎";
    customScriptEditBar.style = "display: none;";
  }
}

function delScript(scriptName) {
  scriptName = scriptName.currentTarget.scriptName;
  localStorage.removeItem(`${scriptName}`);

  let scriptIndex = localStorage.getItem("scriptIndexList");
  if (scriptIndex == undefined) scriptIndex = "";

  scriptIndex = scriptIndex.split(",");

  delete scriptIndex[scriptIndex.indexOf(scriptName)];

  for (let i = 0; i < scriptIndex.length; i++) {
    localStorage.setItem("scriptIndexList", scriptIndex);
    scriptIndex = localStorage.getItem("scriptIndexList");
    if (scriptIndex == undefined) scriptIndex = "";
    scriptIndex = scriptIndex.replace(",,", ",").replace(",,", ",").replace(",,", ",").replace(",,", ",");
    localStorage.setItem("scriptIndexList", scriptIndex);
  }
  refeshCustomScriptHolder()
  editScripts();
  editScripts();
}

function setWeights() {
  let weights = [1, 3, 0.5, 0.8, 0.1, 2];
  let weight1Inptut = document.getElementById("weight1Inptut");
  let weight2Inptut = document.getElementById("weight2Inptut");
  let weight3Inptut = document.getElementById("weight3Inptut");
  let weight4Inptut = document.getElementById("weight4Inptut");
  let weight5Inptut = document.getElementById("weight5Inptut");
  let weight6Inptut = document.getElementById("weight6Inptut");

  weight1InptutValue = weight1Inptut.value;
  weight2InptutValue = weight2Inptut.value;
  weight3InptutValue = weight3Inptut.value;
  weight4InptutValue = weight4Inptut.value;
  weight5InptutValue = weight5Inptut.value;
  weight6InptutValue = weight6Inptut.value;

  weights[0] = weight1InptutValue;
  weights[1] = weight2InptutValue;
  weights[2] = weight3InptutValue;
  weights[3] = weight4InptutValue;
  weights[4] = weight5InptutValue;
  weights[5] = weight6InptutValue;

  if (weights[0] == null) {
    weights[0] = 1;
  }
  if (weights[1] == null) {
    weights[1] = 3;
  }
  if (weights[2] == null) {
    weights[2] = 0.5;
  }
  if (weights[3] == null) {
    weights[3] = 0.8;
  }
  if (weights[4] == null) {
    weights[4] = 0.1;
  }
  if (weights[5] == null) {
    weights[5] = 2;
  }

  popupSend({ action: "post", newWeights: weights }, "setWeights");
}