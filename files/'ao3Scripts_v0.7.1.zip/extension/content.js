const extDownloadLocation = "https://jozias-m.github.io/extensions/files/extension.zip";
// const extDownloadLocation = "https://jozias-m.github.io/extensions/?download=extension.zip";

let QextensionFullUpdated = false;

const numberOfSettings = 8;

// let weights = localStorage.getItem("pap_weights");
let weights = [1, 3, 0.5, 0.8, 0.1, 10];
// Read documentation to adjust weights.

let QherstoryLogger = true;
let QremoveClearHerstoryButton = true;
let QarchiveWorks = true;
let QcustomScripts = false;
let QcustomScoreSystem = false;
let QtrainedScoreSystem = true;
let QblockAndHighlightWorks = true;
let QcustomSupText = true;

let QoptionalExtraScriptsEnabled;
if (localStorage.getItem("pap_QoptionalExtraScriptsEnabled")) {
  QoptionalExtraScriptsEnabled = true;
} else {
  QoptionalExtraScriptsEnabled = false;
}


let ao3ScriptsSettings = localStorage.getItem("ao3ScriptsSettings");
let importedSettings = ["a", "a", "a", "b", "b", "a", "a", "a"];

let worksToDownload = localStorage.getItem("worksToDownload");
if (worksToDownload === null) worksToDownload = "";
worksToDownload = worksToDownload.toString();

let currWorkId;
if (document.location.href.match(/works\/(\d\d*).*/)) {
  currWorkId = document.location.href.match(/works\/(\d\d*).*/)[1];
  logConsole(`current work id: ${currWorkId}`);
}

if (true) {
  QbypassVersionCheck = false;
  checkExtensionVersion();
  //   if (QextensionFullUpdated) {
  if (ao3ScriptsSettings == undefined) {
    ao3ScriptsSettingsConfigure(false);
  } else {
    if (ao3ScriptsSettings.length != numberOfSettings + 2) {
      recoverSettings();
    } else {
      ao3ScriptsSettings = ao3ScriptsSettings.slice(2);
      for (let i = 0; i < numberOfSettings; i++) {
        importedSettings[i] = ao3ScriptsSettings.slice(i, i + 1);
      }
    }
  }
  ao3ScriptsSettingsConfigure(true);
  //   }
}

function manualRunScripts(notFirstTime) {
  if (QherstoryLogger && QextensionFullUpdated) {
    (function ($) {
      var DEBUG = false;

      // newest more-or-less major version, for the update notice
      var current_version = "2.03";

      var kudos_history = {},
        seen_buttons = {},
        saved_settings = {};
      var main = $("#main");

      // check if reversi
      var body_bg_color = window.getComputedStyle(
        document.body,
      ).backgroundColor;
      if (body_bg_color == "rgb(51, 51, 51)") {
        main.addClass("kh-reversi");
      }

      // uncomment the next five lines if you need to clear your local lists (then comment them again after refreshing the page once)
      // localStorage.removeItem('kudoshistory_kudosed');
      // localStorage.removeItem('kudoshistory_checked');
      // localStorage.removeItem('kudoshistory_seen');
      // localStorage.removeItem('kudoshistory_bookmarked');
      // localStorage.removeItem('kudoshistory_skipped');

      var KHList = {
        init: function init(name, max_length) {
          this.name = name;
          this.max_length = max_length || 200000;
          this.list = localStorage.getItem("kudoshistory_" + this.name) || ",";
          return this;
        },

        reload: function reload() {
          this.list =
            localStorage.getItem("kudoshistory_" + this.name) || this.list;
          return this;
        },
        save: function save() {
          try {
            localStorage.setItem(
              "kudoshistory_" + this.name,
              this.list.slice(0, this.max_length),
            );
          } catch (e) {
            localStorage.setItem(
              "kudoshistory_" + this.name,
              this.list.slice(0, this.list.length * 0.9),
            );
          }
          return this;
        },
        hasId: function hasId(work_id) {
          if (this.list.indexOf("," + work_id + ",") > -1) {
            this.list =
              "," + work_id + this.list.replace("," + work_id + ",", ",");
            return true;
          } else {
            return false;
          }
        },
        add: function add(work_id) {
          this.list =
            "," + work_id + this.list.replace("," + work_id + ",", ",");
          return this;
        },
        remove: function remove(work_id) {
          this.list = this.list.replace("," + work_id + ",", ",");
          return this;
        },
      };

      var KHSetting = {
        init: function init(setting) {
          this.name = setting.name;
          this.label = setting.label;
          this.description = setting.description;
          this.options = setting.options;
          this.current = saved_settings[this.name] || setting.default_value;
          return this;
        },

        next: function next() {
          this.current =
            this.options[this.options.indexOf(this.current) + 1] ||
            this.options[0];
          this.updateButton();
          this.save();
          addMainClass(true);
        },
        getButton: function getButton() {
          this.button_link = $("<a></a>")
            .text(this.label + ": " + this.current.toUpperCase())
            .prop("title", this.options.join(" / ").toUpperCase());
          this.button = $('<li class="kh-menu-setting"></li>').append(
            this.button_link,
          );
          var this_setting = this;
          this.button.click(function () {
            this_setting.next();
          });
          return this.button;
        },
        updateButton: function updateButton() {
          this.button_link.text(this.label + ": " + this.current.toUpperCase());
        },
        changeValue: function changeValue(value) {
          this.current = value;
          this.updateButton();
          this.updateSettingRow();
          this.save();
          addMainClass(true);
        },
        getSettingRow: function getSettingRow() {
          var setting_row_info = $(
            '<p class="kh-setting-info kh-hide-element">' +
            this.description +
            "</p>",
          );
          var setting_row_info_button = $(
            '<a class="help symbol question kh-setting-info-button"><span class="symbol question"><span>?</span></span></a>',
          );
          var setting_row_label = $(
            '<span class="kh-setting-label">' + this.label + ": </span>",
          ).append(setting_row_info_button);
          this.setting_row_options = $(
            '<span class="kh-setting-options"></span>',
          );
          this.setting_row = $('<p class="kh-setting-row"></p>').append(
            setting_row_label,
            this.setting_row_options,
            setting_row_info,
          );
          this.updateSettingRow();
          setting_row_info_button.click(function () {
            setting_row_info.toggleClass("kh-hide-element");
          });
          return this.setting_row;
        },
        updateSettingRow: function updateSettingRow() {
          var this_setting = this;
          this_setting.setting_row_options.empty();
          this.options.forEach(function (option) {
            var option_link = $('<a class="kh-setting-option"></a>');
            option_link.click(function () {
              this_setting.changeValue(option);
            });

            if (this_setting.current == option) {
              option_link
                .html("<strong>" + option.toUpperCase() + "</strong>")
                .addClass("kh-setting-option-selected");
            } else {
              option_link.text(option.toUpperCase());
            }

            this_setting.setting_row_options.append(
              " ",
              option_link,
              ' <span class="kh-setting-separator">&bull;</span>',
            );
          });
        },
        save: function save() {
          saved_settings[this.name] = this.current;
          localStorage.setItem(
            "kudoshistory_settings",
            JSON.stringify(saved_settings),
          );
        },
        check: function check(compare) {
          return this.current === (compare || "yes");
        },
      };

      var settings_list = [
        {
          name: "kudosed_display",
          label: "Kudosed works",
          description:
            "Hide the works on lists, show the whole blurb, or show just the blurb header.",
          options: ["hide", "show", "collapse"],
          default_value: "collapse",
        },
        {
          name: "seen_display",
          label: "Seen works",
          description:
            "Hide the works on lists, show the whole blurb, or show just the blurb header.",
          options: ["hide", "show", "collapse"],
          default_value: "collapse",
        },
        {
          name: "skipped_display",
          label: "Skipped works",
          description:
            'Hide the works on lists, replace the blurb content with "Skipped", or show just the blurb header.',
          options: ["hide", "placeholder", "collapse"],
          default_value: "placeholder",
        },
        {
          name: "toggles_display",
          label: "Blurb options",
          description:
            "The controls on top right of the blurb that let you mark/unmark the work as seen or skipped from the list.",
          options: ["hide", "show", "on hover"],
          default_value: "on hover",
        },
        {
          name: "highlight_bookmarked",
          label: "Highlight bookmarked",
          description:
            "Show a striped stripe (yeah) on the right for works you've bookmarked.",
          options: ["yes", "no"],
          default_value: "yes",
        },
        {
          name: "highlight_new",
          label: "Highlight new",
          description:
            "Show a thin coloured stripe on the left of the blurb for works you're seeing for the first time. Only shows on the lists.",
          options: ["yes", "no"],
          default_value: "yes",
        },
        {
          name: "autoseen",
          label: "Mark as seen on open",
          description:
            "Automatically mark as seen when you open the work page.",
          options: ["yes", "no"],
          default_value: "no",
        },
        {
          name: "background_check",
          label: "Check for kudos while browsing works lists",
          description:
            "The script checks kudos on the works in the background. <strong>Warning:</strong> This may cause too many requests to AO3 if you browse too quickly, and it's not very reliable since AO3 started paginating kudos (so the script may not find yours if it's further down the list).",
          options: ["yes", "no"],
          default_value: "no",
        },
      ];

      if (typeof Storage !== "undefined") {
        saved_settings =
          JSON.parse(localStorage.getItem("kudoshistory_settings")) || {};

        kudos_history = {
          kudosed: Object.create(KHList).init("kudosed"),
          checked: Object.create(KHList).init("checked"),
          seen: Object.create(KHList).init("seen", 2000000),
          bookmarked: Object.create(KHList).init("bookmarked"),
          skipped: Object.create(KHList).init("skipped"),

          username: localStorage.getItem("kudoshistory_username"),

          saveLists: function () {
            DEBUG && logConsole("saving lists");
            this.kudosed.save();
            this.checked.save();
            this.seen.save();
            this.bookmarked.save();
            this.skipped.save();
          },
        };

        settings_list.forEach(function (setting) {
          kudos_history[setting.name] = Object.create(KHSetting).init(setting);
        });

        var userlink = $('#greeting li.dropdown > a[href^="/users/"]');

        if (!kudos_history.username) {
          localStorage.setItem("kudoshistory_lastver", current_version);
        }

        // if logged in
        if (userlink.length) {
          var found_username = userlink.attr("href").split("/")[2];
          DEBUG && logConsole("found username: " + found_username);

          if (kudos_history.username !== found_username) {
            kudos_history.username = found_username;
            localStorage.setItem(
              "kudoshistory_username",
              kudos_history.username,
            );
          }
        }
        // if not logged in, but remembers username
        else if (!!kudos_history.username) {
          DEBUG &&
            logConsole(
              "didn't find username on page, saved username: " +
              kudos_history.username,
            );
        } else {
          kudos_history.username = prompt(
            "AO3: Kudosed and seen history\n\nYour AO3 username:",
          );
          localStorage.setItem("kudoshistory_username", kudos_history.username);
        }

        $(document).ajaxStop(function () {
          kudos_history.saveLists();
        });

        // add css rules for kudosed works
        addCss();

        var works_and_bookmarks = $("li.work.blurb, li.bookmark.blurb");

        // if there's a list of works or bookmarks
        if (works_and_bookmarks.length) {
          addSeenMenu();

          var blurb_index = $(".index");

          // click on header to collapse/expand
          blurb_index.on("click", ".header", function (e) {
            if (!$(e.target).is("a") && !$(e.target).is("span")) {
              $(this).closest(".blurb").toggleClass("collapsed-blurb");
              e.stopPropagation();
            }
          });

          // toggle seen/skipped
          blurb_index.on("click", ".kh-toggle", function (e) {
            changeBlurbStatus(
              $(this).closest(".blurb"),
              $(this).data("list"),
              true,
            );
            e.stopPropagation();
          });

          // click on delete bookmark
          blurb_index.on(
            "click",
            '.own.user a[data-method="delete"]',
            function () {
              var work_id = $(this).closest(".blurb").data("work_id");

              if (work_id) {
                kudos_history.bookmarked.reload().remove(work_id).save();
              }
            },
          );

          // for each work and bookmark blurb
          works_and_bookmarks.not(".deleted").each(function () {
            blurbCheck($(this));
          });
        }

        // if it's the first time after an update
        addNotice();

        // if it's a work page
        if ($("#workskin").length) {
          var work_meta = $("dl.work.meta.group");

          // get work id
          var work_id = $("#kudo_commentable_id").val();
          DEBUG && logConsole("work_id " + work_id);

          if (kudos_history.autoseen.check()) {
            kudos_history.seen.add(work_id);
          }

          // check if work id is on the seen list
          var is_seen = kudos_history.seen.hasId(work_id);

          if (is_seen) {
            work_meta.addClass("marked-seen");
          }

          addSeenButtons();

          // if work id is on the kudosed list
          if (kudos_history.kudosed.hasId(work_id)) {
            work_meta.addClass("has-kudos");
            DEBUG && logConsole("- on kudosed list");
          } else {
            // check if there are kudos from the user
            var user_kudos = $("#kudos").find(
              '[href="/users/' + kudos_history.username + '"]',
            );

            if (user_kudos.length) {
              // highlight blurb and add work id to kudosed list
              kudos_history.kudosed.add(work_id);
              kudos_history.checked.remove(work_id);
              work_meta.addClass("has-kudos");
            } else {
              // add work id to checked list
              kudos_history.checked.add(work_id);

              $("#new_kudo").one("click", function () {
                kudos_history.kudosed.reload().add(work_id).save();
                kudos_history.checked.reload().remove(work_id).save();
                work_meta.addClass("has-kudos");
              });
            }
          }

          // check if it's bookmarked
          var bookmark_button_text = $("a.bookmark_form_placement_open")
            .filter(":first")
            .text();

          if (bookmark_button_text.indexOf("Edit") > -1) {
            // highlight blurb
            kudos_history.bookmarked.add(work_id);
            work_meta.addClass("is-bookmarked");
          } else {
            kudos_history.bookmarked.remove(work_id);
          }
        }

        // save all lists
        kudos_history.saveLists();
      }

      // check if work is on lists
      function blurbCheck(blurb) {
        var work_id;
        var blurb_id = blurb.attr("id");

        if (blurb.hasClass("work")) {
          work_id = blurb_id.replace("work_", "");
        } else if (blurb.hasClass("bookmark")) {
          var work_link = blurb.find("h4 a:first").attr("href");

          // if it's not a deleted work and not a series or external bookmark
          if (
            !!work_link &&
            work_link.indexOf("series") === -1 &&
            work_link.indexOf("external_work") === -1
          ) {
            work_id = work_link.split("/").pop();

            // if it's your own bookmark
            var own_bookmark = blurb.find("div.own.user.module.group");
            if (own_bookmark.length) {
              kudos_history.bookmarked.add(work_id);
            }
          }
        }

        blurb.data("work_id", work_id);

        DEBUG &&
          logConsole("blurb check " + blurb_id + ", work_id: " + work_id);

        if (!work_id) {
          return false;
        }

        var found_on_list = false;
        var blurb_classes = "blurb-with-toggles";
        blurb.prepend(
          '<div class="kh-toggles">mark/unmark as: <a class="kh-toggle" data-list="seen">seen</a> &bull; <a class="kh-toggle" data-list="skipped">skipped</a>',
        );

        // if work id is on the kudosed list
        if (kudos_history.kudosed.hasId(work_id)) {
          DEBUG && logConsole("- is kudosed");
          blurb_classes += " has-kudos collapsed-blurb";
          found_on_list = true;
        }

        // if work id is on the seen list
        if (kudos_history.seen.hasId(work_id)) {
          DEBUG && logConsole("- is seen");
          blurb_classes += " marked-seen collapsed-blurb";
          found_on_list = true;
        }

        // not on the kudosed/seen list
        if (!found_on_list) {
          // if work id is on the checked list
          if (kudos_history.checked.hasId(work_id)) {
            DEBUG && logConsole("- is checked");
          } else {
            blurb_classes += " new-blurb";

            if (kudos_history.background_check.check()) {
              loadKudos(blurb);
            } else {
              DEBUG && logConsole("- marking as checked");
              kudos_history.checked.add(work_id);
            }
          }
        }

        // if work id is on the bookmarked list
        if (kudos_history.bookmarked.hasId(work_id)) {
          DEBUG && logConsole("- is bookmarked");
          blurb_classes += " is-bookmarked";
        }

        // if work id is on the skipped list
        if (kudos_history.skipped.hasId(work_id)) {
          DEBUG && logConsole("- is skipped");
          blurb_classes += " skipped-work collapsed-blurb";
        }

        blurb.addClass(blurb_classes);
      }

      // load kudos for blurb
      function loadKudos(blurb) {
        var work_id = blurb.data("work_id");

        if (!work_id) {
          return false;
        }

        DEBUG && logConsole("- loading kudos for " + work_id);

        // add a div to the blurb that will house the kudos
        var kudos_container = $('<div style="display: none;"></div>');
        blurb.append(kudos_container);

        // retrieve a list of kudos from the work
        var work_url =
          window.location.protocol +
          "//" +
          window.location.hostname +
          "/works/" +
          work_id +
          "/kudos #kudos";
        kudos_container.load(work_url, function () {
          // check if there are kudos from the user
          var user_kudos = kudos_container.find(
            '[href="/users/' + kudos_history.username + '"]',
          );

          if (user_kudos.length) {
            // highlight blurb and add work id to kudosed list
            blurb.addClass("has-kudos collapsed-blurb");
            kudos_history.kudosed.add(work_id);
          } else {
            // add work id to checked list
            kudos_history.checked.add(work_id);
          }
        });
      }

      // mark all works on the page as seen
      function markPageSeen() {
        kudos_history.seen.reload();

        // for each blurb
        works_and_bookmarks
          .not(".marked-seen")
          .not(".deleted")
          .each(function () {
            changeBlurbStatus($(this), "seen", false, true);
          });

        kudos_history.seen.save();
      }

      // mark all works on the page as unseen
      function markPageUnseen() {
        kudos_history.seen.reload();

        // for each blurb
        works_and_bookmarks.not(".deleted").each(function () {
          changeBlurbStatus($(this), "seen", false, false);
        });

        kudos_history.seen.save();
      }

      // mark/unmark blurb as X
      function changeBlurbStatus(blurb, list, save_list, add_to_list) {
        var work_id = blurb.data("work_id");

        if (work_id) {
          save_list && kudos_history[list].reload();

          var blurb_class = {
            seen: "marked-seen",
            skipped: "skipped-work",
          };

          if (add_to_list == undefined) {
            add_to_list = !kudos_history[list].hasId(work_id);
          }

          if (add_to_list) {
            DEBUG && logConsole("marking as " + list + " " + work_id);
            kudos_history[list].add(work_id);
            blurb.addClass(blurb_class[list] + " collapsed-blurb");
          } else {
            DEBUG && logConsole("unmarking as " + list + " " + work_id);
            kudos_history[list].remove(work_id);
            blurb.removeClass(blurb_class[list]);
          }

          save_list && kudos_history[list].save();
        }
      }

      // re-check the page for kudos
      function recheckKudos() {
        kudos_history.kudosed.reload();
        kudos_history.checked.reload();

        // for each non-kudosed blurb
        works_and_bookmarks
          .not(".has-kudos")
          .not(".deleted")
          .each(function () {
            loadKudos($(this));
          });
      }

      // check the page for bookmarks
      function checkForBookmarks() {
        kudos_history.bookmarked.reload();

        // for each work and bookmark blurb
        works_and_bookmarks.not(".deleted").each(function () {
          var blurb = $(this);
          var work_id = blurb.data("work_id");

          if (!work_id) {
            return false;
          }

          DEBUG && logConsole("- loading bookmark buttons for " + work_id);

          // add a div to the blurb that will house the kudos
          var bookmark_container = $('<div style="display: none;"></div>');
          blurb.append(bookmark_container);

          // retrieve the bookmark button from the work
          var work_url =
            window.location.protocol +
            "//" +
            window.location.hostname +
            "/works/" +
            work_id +
            " a.bookmark_form_placement_open:first";
          bookmark_container.load(work_url, function () {
            // check if there is a bookmark from the user
            var bookmark_button_text = bookmark_container.find("a").text();

            if (bookmark_button_text.indexOf("Edit") > -1) {
              // highlight blurb
              blurb.addClass("is-bookmarked");
              kudos_history.bookmarked.add(work_id);
            } else {
              blurb.removeClass("is-bookmarked");
              kudos_history.bookmarked.remove(work_id);
            }
          });
        });
      }

      // show the box with import/export options
      function importExport() {
        var importexport_bg = $('<div id="importexport-bg"></div>');

        var importexport_box = $('<div id="importexport-box"></div>');

        var box_button_save = $(
          '<input type="button" id="importexport-button-save" value="Import lists" />',
        );
        box_button_save.click(function () {
          var confirmed = confirm("Sure you want to replace your saved lists?");

          if (confirmed) {
            var import_lists = JSON.parse($("#import-seen-list").val());

            for (var list_name in import_lists) {
              if (kudos_history[list_name]) {
                kudos_history[list_name].list = import_lists[list_name];
                kudos_history[list_name].save();
              }
            }

            $("#importexport-save").prepend("Lists imported! ");
          }
        });

        var box_button_close = $(
          '<input type="button" id="importexport-button-close" value="Close" />',
        );

        var list_types = [
          "kudosed",
          "seen",
          "bookmarked",
          "skipped",
          "checked",
        ];

        var list_types_checkboxes = [];
        list_types.forEach(function (list_type) {
          list_types_checkboxes.push(
            '<label class="kh-export-checkbox-label"><input type="checkbox" id="kh-export-checkbox-' +
            list_type +
            '" checked />' +
            list_type +
            "</label>",
          );
        });

        var box_button_generate = $(
          '<input type="button" id="importexport-button-generate" value="Generate your export" />',
        );
        box_button_generate.click(function () {
          var export_lists = {};
          list_types.forEach(function (list_type) {
            if ($("#kh-export-checkbox-" + list_type).prop("checked")) {
              export_lists[list_type] = kudos_history[list_type].reload().list;
            }
          });
          $("#export-seen-list").val(JSON.stringify(export_lists));
        });

        importexport_box.append(
          $('<p class="actions"></p>').append(box_button_close),
          $("<h3></h3>").text("Settings"),
        );

        settings_list.forEach(function (setting) {
          importexport_box.append(kudos_history[setting.name].getSettingRow());
        });

        importexport_box.append(
          $('<h3 style="margin-top: 1.5em;"></h3>').text(
            "Export your saved lists",
          ),
          $("<p></p>").text(
            "Select which lists to export (leave them all selected if you're not sure) and generate your export. Then copy your current lists from the field below and save wherever you want as a backup.",
          ),
          $("<p></p>").append(list_types_checkboxes),
          $('<p class="actions" id="importexport-generate"></p>').append(
            box_button_generate,
          ),
          $(
            '<input type="text" id="export-seen-list" class="kh-text-input" />',
          ),
          $('<h3 style="margin-top: 1.5em;"></h3>').text("Import your lists"),
          $("<p></p>").html(
            'Put your saved lists in the field below and select the "Import lists" button. <strong>Warning:</strong> it will <u>replace</u> your current lists.',
          ),
          $(
            '<input type="text" id="import-seen-list" class="kh-text-input" />',
          ),
          $('<p class="actions" id="importexport-save"></p>').append(
            box_button_save,
          ),
        );

        $("body").append(importexport_bg);
        main.append(importexport_box);

        box_button_close.add(importexport_bg).click(function () {
          importexport_box.detach();
          importexport_bg.detach();
        });
      }

      // add the seen/unseen buttons
      function addSeenButtons() {
        seen_buttons = {
          is_seen: is_seen,
          buttons_links: [],

          change: function () {
            DEBUG && logConsole(this);
            this.is_seen = !this.is_seen;
            kudos_history.seen.reload();

            if (this.is_seen) {
              kudos_history.seen.add(work_id);
              work_meta.addClass("marked-seen");
            } else {
              kudos_history.seen.remove(work_id);
              work_meta.removeClass("marked-seen");
            }

            kudos_history.seen.save();
            this.updateButtons();
            DEBUG && logConsole(this);
          },
          getButton: function () {
            var button_link = $("<a></a>").html(
              this.is_seen ? "Unseen &cross;" : "Seen &check;",
            );
            var button = $('<li class="kh-seen-button"></li>').append(
              button_link,
            );
            var this_setting = this;
            button.click(function () {
              this_setting.change();
            });
            this.buttons_links.push(button_link);
            return button;
          },
          updateButtons: function () {
            for (var i = 0; i < this.buttons_links.length; i++) {
              this.buttons_links[i].html(
                this.is_seen ? "Unseen &cross;" : "Seen &check;",
              );
            }
          },
        };

        $("li.bookmark").after(seen_buttons.getButton());
        $("#new_kudo").parent().after(seen_buttons.getButton());
      }

      // attach the menu
      function addSeenMenu() {
        // create a button for the menu
        function getMenuButton(button_text, on_click) {
          var button = $("<li><a>" + button_text + "</a></li>");
          if (on_click) {
            button.click(on_click);
            button.addClass("kh-menu-setting");
          } else {
            button.addClass("kh-menu-header");
          }
          return button;
        }

        // get the header menu
        var header_menu = $("ul.primary.navigation.actions");

        // create menu button
        var seen_menu = $('<li class="dropdown"></li>').html(
          "<a>Seen works</a>",
        );

        // create dropdown menu
        var drop_menu = $('<ul class="menu dropdown-menu"></li>');

        // append buttons to the dropdown menu
        drop_menu.append(
          getMenuButton("Settings and import/export", importExport),
          getMenuButton("&mdash; For all works on this page: &mdash;"),
          getMenuButton("Mark as seen", markPageSeen),
          getMenuButton("Unmark as seen", markPageUnseen),
          getMenuButton("Re-check for kudos", recheckKudos),
          getMenuButton("Check for bookmarks", checkForBookmarks),
          getMenuButton("&mdash; Settings (click to change): &mdash;"),
        );

        settings_list.forEach(function (setting) {
          drop_menu.append(kudos_history[setting.name].getButton());
        });

        seen_menu.append(drop_menu);
        header_menu.find("li.search").before(seen_menu);
      }

      // add a notice about an update
      function addNotice() {
        var last_version =
          localStorage.getItem("kudoshistory_lastver") || current_version;

        if (last_version < current_version) {
          var update_2_3 =
            "<h3>version 2.3</h3>\
                    <p><b>&bull; Checking the works for kudos in the background while browsing works lists is now disabled by default.</b> It looks like it can do more harm than good these days - it may cause too many requests to AO3 if you browse too quickly, and it's not very reliable since AO3 started paginating kudos (so the script may not find yours if it's further down the list). If you need it, you can turn it back on in settings, or use \"Re-check for kudos\" on the current page.</p>\
                    <p><b>&bull; More options for the export.</b> You can pick which lists you want to export.</p>";

          var update_notice = $(
            '<div id="kudoshistory-update" class="notice"></div>',
          );

          update_notice.append(
            "<h3><b>Kudosed and seen history userscript updated!</b></h3>",
            update_2_3,
            "<p style='text-align: right;'><b><a id='kudoshistory-hide-update'>Don't show this again</a></b></p>",
          );

          main.prepend(update_notice);

          $("#kudoshistory-hide-update").click(function () {
            localStorage.setItem("kudoshistory_lastver", current_version);
            update_notice.detach();
          });
        }
      }

      // add css rules to page head
      function addCss() {
        var css =
          '.kh-main{--bg-img-kudosed: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAIAAAADnC86AAAABnRSTlMAAAAAAABupgeRAAAACXBIWXMAAAsTAAALEwEAmpwYAAAGj0lEQVR4nO2YeVATdxTHf7ubhRyEJNyQBAIVoo0iiINV0HFs8ShtrVYqh4LDaLX1QKhFbdVpba0djxYL0kOtOFI60mpt7XiAxcEDLQMoGORMwACSA3JBwiab7PaPODRCSKB26nSm37923+/93ue3v3373m8Wkkgk4FkIfibU/8ETklmjqXk769HFy8buHsJsnuh0ynicSIIgTCYCx1U3q/zmxlOYHgCAnl8vquvuahrukxbLpPVrwzLT/3lw14/n2gq/RdksTK4IzVgV/s5bAAB25FQAQaTFAsEwnc+bEHW8YJIgrBhmlWMAAEYw32bkRE/nLX0F1+mF2Zup/n4AAMKMS45/R+dy9a1ttAB/werUpwUHr1xhxbD2b05wpk8LfHnRsH3K9ncBABD8OFFM6v7O78+QFgsAgM7jhqQlDw+NFjRWATFrNJZBg/0e6puaaTwuymQ6WaLszE8teQUkSUZ+vCcg4UUnng7AlkEDplDey30fU6rmlBRN9P3Jy65ajEO811917uZgq2uztunEjbZrde3diYIDFr40fI3r9QiVCru5jQvsKQzXNT4AJAkgiDkpbEJUe2kbxLWbc5jCCI8wQeDihZyoSBfgyTlbQpKTesuu6ptbmcKIvw3WNzVbMUxb36Ctb8C12hHgMZPr6WXWaKpS15jVGt+5cZNzttCCAscE99+p1jU1e82M8RRGwG6o69BqTcep4r471YAkWdNEz2Vm0LhB9g7y8grCggcuShj9XT0BJkymgXZp75XygbZ2n9mz+CuWUej0saiqW7frd+ymMOisqSIIQfRNzZhSNWXbVv6KZS5XPBI8LFO/ui3/K11TU3DSG7zlS0evd1DacSdjnd+8ONGuHQiNBgAgcFxyvKij6HTUwU/95sUPe5IEoay8iVDdfWbPcg22ydD58N72DyAIjjq0n87j2g/Vbs4ZetQbV1oMIYi9vS471yDtjD9bAlEoAACzWtNypIAWFBiyMglls+w9nbVFhiBkdvFJ7xdiq1LXSI6dBCRps1sxTNsgDkl5cwQVACBISx5SKMxaLQCgv7qmLjs3cFHCpPVrR1CBy1oNo6hw6yamMPzB/kOqG7divjyMslmAJAkcpzAYo/0RqjsEQRBC6b1cLj15KubIYWqAv+PIzsEAgEFpB2m1xpcWDykUt5LTjbIuhEaj87jy8t9HOysqKt28vLT1DZITRTOPHhmLOi7wQGs7gZmoAf5zSk5BMFSVtmagtU20e6fq1u3eS2X2njpxo+zHc5zoyJYvC2d8ccDdx9tJWNcFpLXga9/4Oba6Y+pXV2duwJTKmPzPByXSlrwCr9iZ3Fdeht1QeXmFsvKGb9xsrfhBWGY6f/lS52FdP7FJpRruE+7eXrEnvkJZrJpN2XQ+L/Z4ISaXt+TlNx3MG5RIow9/5u7rQ/X3c0kFLpPLrNGaVH0Uxl9lxN3HO/bY0T8yN9Rl50Yd2Bd3pnhILsd1egiCjD29stKzgrRkw0OZu7c3xcNB9g3LxVb3Vd3pOvdL9KH9I+zqmrqajVthFKXzeab+fsvAIEkQT8RFkICEBVNycxwmv+snlpdXsKc+b2/B5IrO4h8U1yoBAASOD0o7KEwPftJyXK/vvVQWmpHmv2C+satbJ34gKz1LWq2Rn3w4YbDFaNSKGwWrU2y3hk6Z5NgJxbXrpNUKUSic6Omop6ey8gaEIKHpqd3nL0AwLEhLQVmenpOFAQkvIjRa9/kLpNU6us64AHf99DPKZHqEhZr6+lryChQVlaTVijKZ3NcSgxKXMEJDAACNe/c/unSlZuNWk7KPNU2EejIfr7j+fte580GJSxxSnYFxvb77/AXRzvdkpWdb8wsJM07jBglWpQQtWWjrCjaJdm3HlEp17V0AgM+sWABBBI5XpWRgckVw0nJh1sax4iNZWVkOB1o+z9eJG3X3xY8uXqH6+onef0+YvZk9bSqMPtGnIRj2jZsjL7tqMRgFq1LofB6EIIyQYGN3z0BzKyOEP9aRzXFWK65dr9+xCwDgxuGEv70uKHGxrduMJUOnrOe3i2GZ6fb9W3Ov4f6evTOOHPIIFYye4iCc4aFM/NE+CIYFq1MEq1OdH6RtYgiCIzZtUFbecGOz2NMfn604UZFubLZB2jFe8EBrGy3Af3QPdimvmBntXx/ru13NmREFAOg8XULjcf0XzHfo7GirbX0XgiZEHZ6ruFb5sOSMWaP1nBwh2r0ToVLHDf5X9B/8I/BfBf8JLkPPLSJAcPwAAAAASUVORK5CYII=");--bg-img-seen: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAKCAIAAABJ+IsHAAAABnRSTlMAAAAAAABupgeRAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAHUlEQVR4nGO8e/cuw0AApgGxddTiUYtHLR4WFgMAbToCqzgxIWEAAAAASUVORK5CYII=");--bg-img-bookmarked: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAKCAIAAABJ+IsHAAAABnRSTlMAAAAAAABupgeRAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAcklEQVR4nMXNwQ3EIAxEUTJ7sTBF0IsRDY/boROQ9holKHuBja9P33O01sLteu8kU0pmBmCHXuE/q2a27e8vxd1U9aFcpTibu6tqKWVarlWcLcb4UK5VvLIaQsAYw91FZFru00/OWURqrdOS5CbFK6skvyCa8BKdjaG8AAAAAElFTkSuQmCC")}.has-kudos.marked-seen,.has-kudos{background:var(--bg-img-kudosed) left no-repeat,var(--bg-img-seen) left repeat-y !important;padding-left:50px !important}@media screen and (max-width: 42em){.has-kudos.marked-seen,.has-kudos{background-size:20px !important;padding-left:30px !important}}.marked-seen{background:var(--bg-img-seen) left repeat-y !important;padding-left:50px !important}@media screen and (max-width: 42em){.marked-seen{background-size:20px !important;padding-left:30px !important}}.kh-highlight-bookmarked-yes .is-bookmarked,dl.is-bookmarked{background:var(--bg-img-bookmarked) right repeat-y !important;padding-right:50px !important}@media screen and (max-width: 42em){.kh-highlight-bookmarked-yes .is-bookmarked,dl.is-bookmarked{background-size:20px !important;padding-right:30px !important}}.kh-highlight-bookmarked-yes .is-bookmarked.has-kudos,dl.is-bookmarked.has-kudos,.kh-highlight-bookmarked-yes .is-bookmarked.has-kudos.marked-seen,dl.is-bookmarked.has-kudos.marked-seen{background:var(--bg-img-kudosed) left no-repeat,var(--bg-img-seen) left repeat-y,var(--bg-img-bookmarked) right repeat-y !important}@media screen and (max-width: 42em){.kh-highlight-bookmarked-yes .is-bookmarked.has-kudos,dl.is-bookmarked.has-kudos,.kh-highlight-bookmarked-yes .is-bookmarked.has-kudos.marked-seen,dl.is-bookmarked.has-kudos.marked-seen{background-size:20px !important}}.kh-highlight-bookmarked-yes .is-bookmarked.marked-seen,dl.is-bookmarked.marked-seen{background:var(--bg-img-seen) left repeat-y,var(--bg-img-bookmarked) right repeat-y !important}@media screen and (max-width: 42em){.kh-highlight-bookmarked-yes .is-bookmarked.marked-seen,dl.is-bookmarked.marked-seen{background-size:20px !important}}#kudoshistory-update a,.kh-menu-setting a,.kh-seen-button a{cursor:pointer}.kh-menu-setting a{white-space:normal;height:auto}.kh-menu-header a{padding:.5em .5em .25em !important;text-align:center;font-weight:bold}#kudoshistory-update{padding:.5em 1em 1em 1em}#kudoshistory-update img{max-width:300px;height:auto}#importexport-box{position:fixed;top:0px;bottom:0px;left:0px;right:0px;width:60%;height:80%;max-width:800px;margin:auto;overflow-y:auto;border:10px solid #eee;box-shadow:0px 0px 8px 0px rgba(0,0,0,.2);padding:0 20px;background-color:#fff;z-index:999}#importexport-box input[type=button]{height:auto;cursor:pointer}#importexport-box p.actions{float:none;text-align:right}#importexport-box .kh-setting-row{line-height:1.6em}#importexport-box .kh-setting-label{display:inline-block;width:13.5em}@media screen and (max-width: 42em){#importexport-box .kh-setting-label{display:block;width:auto}}#importexport-box .kh-setting-label .kh-setting-info-button{font-size:.8em;cursor:pointer}#importexport-box .kh-setting-option{padding:0 3px;border-radius:4px;border:0;color:#111;background:#eee;cursor:pointer}#importexport-box .kh-setting-option.kh-setting-option-selected{color:#fff;background:#900}#importexport-box .kh-setting-separator:last-child{display:none}#importexport-box .kh-setting-info{position:relative;border:1px solid;padding:1px 5px}#importexport-box .kh-setting-info:before{content:" ";position:absolute;top:-12px;border:6px solid transparent;border-bottom-color:initial}#importexport-box .kh-text-input{width:95%}#importexport-box .kh-export-checkbox-label{display:inline-block;cursor:pointer}#importexport-box #importexport-generate,#importexport-box #importexport-save{text-align:left}#importexport-bg{position:fixed;width:100%;height:100%;background-color:#000;opacity:.7;z-index:998}.kh-toggles{display:none;position:absolute;top:-22px;font-size:10px;line-height:10px;right:-1px;background:#fff;border:1px solid #ddd;padding:5px}.kh-toggles a{cursor:pointer}.kh-reversi #importexport-box{background-color:#333;border-color:#222}.kh-reversi #importexport-box .kh-setting-option-selected{background:#5998d6}.kh-reversi .kh-toggles{background:#333;border-color:#555}.kh-hide-element{display:none}.kh-highlight-bookmarked-yes .bookmark.is-bookmarked p.status{padding-right:40px}@media screen and (max-width: 42em){.kh-highlight-bookmarked-yes .bookmark.is-bookmarked p.status{padding-right:20px}}.kh-skipped-display-collapse .collapsed-blurb.skipped-work h6.landmark.heading,.kh-seen-display-collapse .collapsed-blurb.marked-seen h6.landmark.heading,.kh-kudosed-display-collapse .collapsed-blurb.has-kudos h6.landmark.heading,.kh-skipped-display-collapse .collapsed-blurb.skipped-work>ul,.kh-seen-display-collapse .collapsed-blurb.marked-seen>ul,.kh-kudosed-display-collapse .collapsed-blurb.has-kudos>ul,.kh-skipped-display-collapse .collapsed-blurb.skipped-work blockquote.userstuff.summary,.kh-seen-display-collapse .collapsed-blurb.marked-seen blockquote.userstuff.summary,.kh-kudosed-display-collapse .collapsed-blurb.has-kudos blockquote.userstuff.summary,.kh-skipped-display-collapse .collapsed-blurb.skipped-work dl.stats,.kh-seen-display-collapse .collapsed-blurb.marked-seen dl.stats,.kh-kudosed-display-collapse .collapsed-blurb.has-kudos dl.stats,.kh-skipped-display-collapse .collapsed-blurb.skipped-work .header .fandoms.heading,.kh-seen-display-collapse .collapsed-blurb.marked-seen .header .fandoms.heading,.kh-kudosed-display-collapse .collapsed-blurb.has-kudos .header .fandoms.heading{display:none !important}.kh-skipped-display-collapse .collapsed-blurb.skipped-work .required-tags,.kh-seen-display-collapse .collapsed-blurb.marked-seen .required-tags,.kh-kudosed-display-collapse .collapsed-blurb.has-kudos .required-tags,.kh-skipped-display-collapse .collapsed-blurb.skipped-work .mystery .icon,.kh-seen-display-collapse .collapsed-blurb.marked-seen .mystery .icon,.kh-kudosed-display-collapse .collapsed-blurb.has-kudos .mystery .icon{opacity:.6;transform:scale(0.4);transform-origin:top left}.kh-skipped-display-collapse .collapsed-blurb.skipped-work .header,.kh-seen-display-collapse .collapsed-blurb.marked-seen .header,.kh-kudosed-display-collapse .collapsed-blurb.has-kudos .header{min-height:22px;cursor:zoom-in}.kh-skipped-display-collapse .collapsed-blurb.skipped-work .header .heading,.kh-seen-display-collapse .collapsed-blurb.marked-seen .header .heading,.kh-kudosed-display-collapse .collapsed-blurb.has-kudos .header .heading{margin-left:32px}.kh-skipped-display-collapse .skipped-work:not(.collapsed-blurb) .header,.kh-seen-display-collapse .marked-seen:not(.collapsed-blurb) .header,.kh-kudosed-display-collapse .has-kudos:not(.collapsed-blurb) .header{cursor:zoom-out}.kh-kudosed-display-hide:not(.bookmarks-show) li.has-kudos{display:none !important}.kh-seen-display-hide:not(.bookmarks-show) li.marked-seen{display:none !important}.kh-skipped-display-hide .skipped-work{display:none}.kh-skipped-display-placeholder .skipped-work>*{display:none}.kh-skipped-display-placeholder .skipped-work:before{content:"Skipped"}.kh-highlight-new-yes li.new-blurb{border-left:5px solid #900}.kh-highlight-new-yes.kh-reversi#main li.new-blurb{border-left-color:#5998d6}.kh-toggles-display-on-hover li.blurb-with-toggles:hover>.kh-toggles{display:block}.kh-toggles-display-show li.blurb-with-toggles{margin-top:31px}.kh-toggles-display-show li.blurb-with-toggles .kh-toggles{display:block}';

        var style = $('<style type="text/css"></style>').appendTo($("head"));
        style.html(css);

        addMainClass();
      }

      function addMainClass(update) {
        var classes_to_remove = ["kh-main"];
        var classes_to_add = ["kh-main"];

        settings_list.forEach(function (setting) {
          var setting_class_name = setting.name.replace("_", "-");
          classes_to_add.push(
            "kh-" +
            setting_class_name +
            "-" +
            kudos_history[setting.name].current.replace(" ", "-"),
          );

          if (update) {
            setting.options.forEach(function (option) {
              classes_to_remove.push(
                "kh-" + setting_class_name + "-" + option.replace(" ", "-"),
              );
            });
          }
        });

        if (update) {
          main.removeClass(classes_to_remove.join(" "));
        }

        main.addClass(classes_to_add.join(" "));
      }
    })(jQuery);
  }

  if (QremoveClearHerstoryButton && QextensionFullUpdated) {
    if (document.location.href.match(/users\/.*\/readings.*$/)) {
      const ulItems = document
        .getElementById("main")
        .getElementsByTagName("ul")[0];

      const lisItems = ulItems.getElementsByTagName("li");

      Array.from(lisItems)
        .slice(2)
        .forEach((li) => li.remove());
    }
  }

  if (QarchiveWorks && QextensionFullUpdated) {
    if (document.location.href.match(/works\/\d\d*.*$/)) {
      const actionsList = document.querySelector('ul.work.navigation.actions');
      if (!actionsList) {
        logConsole("Error:", "Actions list not found", true);
      }

      const li = document.createElement('li');
      li.className = 'pap-archive';

      const downloadButton = document.createElement('button');
      downloadButton.textContent = 'Archive';
      downloadButton.setAttribute("onclick", "downloadWork('html')");

      li.appendChild(downloadButton, false);

      actionsList.appendChild(li);
    }
  }
  if (false) {      // script disabled
    if (notFirstTime) {
      if (QcustomScoreSystem && QextensionFullUpdated) {
        // setScoreRatingWeight(1, 3, 0.5, 0.8, 0.1, 2);
        // Read documentation to adjust weights.

        olIndexForPage = 0;
        url = document.location.href;
        let QrunScript = true;
        let QrunScriptAlt = false;
        switch (true) {
          case url.match(/\/works\/search.*/) != null:
            olIndexForPage = 1;
            break;
          case url.match(/\/tags\/.*/) != null:
            olIndexForPage = 1;
            break;
          case url.match(/\/users\/.*/) != null:
            olIndexForPage = 0;
            break;
          case url.match(/\/works\/\d*/) != null:
            QrunScript = false;
            QrunScriptAlt = true;
            break;
          default:
            QrunScript = false;
            break;
        }

        function runScript() {
          let main = document.getElementById("main");
          let workList = main.getElementsByTagName("ol")[olIndexForPage];
          workList = workList.getElementsByClassName("work");
          // kudos
          // bookmarks
          // comments
          // hits
          // engamgment
          function runScore() {
            for (let i = 0; i < workList.length; i++) {
              let tmpStatsA = [];
              let tmpStatsB = [];
              let tmpStatsAB = [];
              let tmpStatsC = [];

              const work = workList[i];
              let stats = work.getElementsByClassName("stats")[0];
              stats = stats.getElementsByTagName("div");

              tmpStatsA = [];
              tmpStatsB = [];
              for (let j = 0; j < stats.length; j++) {
                let stat = stats[j];
                stat = stat.getElementsByTagName("dd");

                tmpStatsA[j] = stat[0].className;
                tmpStatsB[j] = stat[0].innerText;
              }

              tmpStatsAB[0] = tmpStatsA;
              tmpStatsAB[1] = tmpStatsB;
              tmpStatsC[i] = tmpStatsAB;

              let words = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("words")];
              let chapters = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("chapters")];
              let comments = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("comments")];
              let kudos = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("kudos")];
              let bookmarks = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("bookmarks")];
              let hits = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("hits")];

              if (words == null) { words = "0"; }
              if (chapters == null) { chapters = "0"; }
              if (comments == null) { comments = "0"; }
              if (kudos == null) { kudos = "0"; }
              if (bookmarks == null) { bookmarks = "0"; }
              if (hits == null) { hits = "0"; }

              words = Number(words.replaceAll(" ", ""));
              comments = Number(comments.replaceAll(" ", ""));
              kudos = Number(kudos.replaceAll(" ", ""));
              bookmarks = Number(bookmarks.replaceAll(" ", ""));
              hits = Number(hits.replaceAll(" ", ""));

              chapters = chapters.split("/");
              if (chapters[1] == "?") chapters[1] == "1"

              let wordsPChapter = words / chapters[0];
              let commentsPChapter = comments / chapters[0];
              let commentsPKudos = ((comments / kudos) * 10);   // 1 - 10
              let bookmarksPKudos = ((bookmarks / kudos) * 10); // 1 - 10
              let kudosPH = ((kudos / hits) * 100) - 3;           // 1 - 10
              let engagmentCBKpH = ((comments * 1) + (bookmarks * 1) + (kudos * 1)) / (hits / 100); // 0 -> 0 -> 10 - 100
              let smallOrNewFicBoost = smallOrNewFicBoostCalc(hits, engagmentCBKpH); // 1 - 10
              hits = hitsCurveCalculator(hits);               // 1 - 10

              score = 0;
              score += kudosPH * weights[0];
              score += bookmarksPKudos * weights[1];
              score += commentsPKudos * weights[2];
              score += hits * weights[3];
              score += engagmentCBKpH * weights[4];
              score += smallOrNewFicBoost * weights[5];

              if (score == NaN) { score = kudosPH * 10; }
              if (score == NaN) { score = 3; }

              score = Math.floor(score);

              scoreDiv = document.getElementById(`ao3S_insretedScore${i}`);
              scoreDiv.innerHTML = "";
              scoreDiv.className = "'ao3S";
              scoreDiv.id = `ao3S_insretedScore${i}`;

              dt = document.createElement("dt");
              dt.className = "'Score";
              dt.innerText = "'Score";
              scoreDiv.appendChild(dt);

              dd = document.createElement("dd");
              dd.className = "'Score";
              dd.innerText = score;
              scoreDiv.appendChild(dd);

              workList[i].getElementsByTagName("dl")[0].appendChild(scoreDiv)
            }
          }

          function hitsCurveCalculator(input) {
            switch (true) {
              case input < 101:
                input = 0;
                break;

              case 100 < input < 201:
                input = 1;
                break;

              case 200 < input < 301:
                input = 2;
                break;

              case 300 < input < 401:
                input = 3;
                break;

              case 400 < input < 451:
                input = 4;
                break;

              case 450 < input < 501:
                input = 5;
                break;

              case 500 < input < 751:
                input = 6;
                break;

              case 750 < input < 1501:
                input = 7;
                break;

              case 1500 < input < 2251:
                input = 8;
                break;

              case 2250 < input < 5001:
                input = 9;
                break;

              default:
                input = 5;
                break;
            }
            input++;

            return input;
          }
          function smallOrNewFicBoostCalc(hits, engagmentCBKpH) {
            boost = 0;
            boost += (500 - hits);
            boost += (20 - engagmentCBKpH * weights[4]);
            if (boost < -5) boost = -5;
            if (boost > 520) boost = 520;

            boost = boost + 5;
            boost = boost / 52;

            return boost;
          }
          runScore();
        }

        if (QrunScript) {
          runScript();
          // logConsole('script running');
        } else {
          if (QrunScriptAlt) {
            // runScriptAlt();
            // logConsole("script not avaaliable yet for running on work page");
          } else {
            // logConsole("not running");
          }
        }
      }
    } else {
      if (QcustomScoreSystem && QextensionFullUpdated) {
        // setScoreRatingWeight(1, 3, 0.5, 0.8, 0.1, 2);
        // Read documentation to adjust weights.

        olIndexForPage = 0;
        url = document.location.href;
        let QrunScript = true;
        let QrunScriptAlt = false;
        switch (true) {
          case url.match(/\/works.search.*/) != null:
            olIndexForPage = 1;
            break;
          case url.match(/\/tags\/.*/) != null:
            olIndexForPage = 1;
            break;
          case url.match(/\/users\/.*/) != null:
            olIndexForPage = 0;
            break;
          case url.match(/\/works\/\d*/) != null:
            QrunScript = false;
            QrunScriptAlt = true;
            break;
          default:
            QrunScript = false;
            break;
        }

        function runScript() {
          let main = document.getElementById("main");
          let workList = main.getElementsByTagName("ol")[olIndexForPage];
          workList = workList.getElementsByClassName("work");
          // kudos
          // bookmarks
          // comments
          // hits
          // engamgment
          function runScore() {
            for (let i = 0; i < workList.length; i++) {
              let tmpStatsA = [];
              let tmpStatsB = [];
              let tmpStatsAB = [];
              let tmpStatsC = [];

              const work = workList[i];
              let stats = work.getElementsByClassName("stats")[0];
              stats = stats.getElementsByTagName("div");

              tmpStatsA = [];
              tmpStatsB = [];
              for (let j = 0; j < stats.length; j++) {
                let stat = stats[j];
                stat = stat.getElementsByTagName("dd");

                tmpStatsA[j] = stat[0].className;
                tmpStatsB[j] = stat[0].innerText;
              }

              tmpStatsAB[0] = tmpStatsA;
              tmpStatsAB[1] = tmpStatsB;
              tmpStatsC[i] = tmpStatsAB;

              let words = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("words")];
              let chapters = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("chapters")];
              let comments = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("comments")];
              let kudos = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("kudos")];
              let bookmarks = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("bookmarks")];
              let hits = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("hits")];

              if (words == null) words = "0"
              if (chapters == null) chapters = "0"
              if (comments == null) comments = "0"
              if (kudos == null) kudos = "0"
              if (bookmarks == null) bookmarks = "0"
              if (hits == null) hits = "0"

              words = Number(words.replaceAll(" ", ""));
              comments = Number(comments.replaceAll(" ", ""));
              kudos = Number(kudos.replaceAll(" ", ""));
              bookmarks = Number(bookmarks.replaceAll(" ", ""));
              hits = Number(hits.replaceAll(" ", ""));

              chapters = chapters.split("/");
              if (chapters[1] == "?") chapters[1] == "1"

              let wordsPChapter = words / chapters[0];
              let commentsPChapter = comments / chapters[0];
              let commentsPKudos = ((comments / kudos) * 10);   // 1 - 10
              let bookmarksPKudos = ((bookmarks / kudos) * 10); // 1 - 10
              let kudosPH = ((kudos / hits) * 100) - 3;           // 1 - 10
              let engagmentCBKpH = ((comments * 1) + (bookmarks * 1) + (kudos * 1)) / (hits / 100); // 0 -> 0 -> 10 - 100
              let smallOrNewFicBoost = smallOrNewFicBoostCalc(hits, engagmentCBKpH); // 1 - 10
              hits = hitsCurveCalculator(hits);               // 1 - 10

              score = 0;
              score += kudosPH * weights[0];
              score += bookmarksPKudos * weights[1];
              score += commentsPKudos * weights[2];
              score += hits * weights[3];
              score += engagmentCBKpH * weights[4];
              score += smallOrNewFicBoost * weights[5];

              if (score == NaN) score = kudosPH * 10;
              if (score == NaN) score = 3;

              score = Math.floor(score);

              scoreDiv = document.createElement("div");
              scoreDiv.className = "'ao3S";
              scoreDiv.id = `ao3S_insretedScore${i}`;

              dt = document.createElement("dt");
              dt.className = "'Score";
              dt.innerText = "'Score";
              scoreDiv.appendChild(dt);

              dd = document.createElement("dd");
              dd.className = "'Score";
              dd.innerText = score;
              scoreDiv.appendChild(dd);

              workList[i].getElementsByTagName("dl")[0].appendChild(scoreDiv)
            }
          }

          function hitsCurveCalculator(input) {
            switch (true) {
              case input < 101:
                input = 0;
                break;

              case 100 < input < 201:
                input = 1;
                break;

              case 200 < input < 301:
                input = 2;
                break;

              case 300 < input < 401:
                input = 3;
                break;

              case 400 < input < 451:
                input = 4;
                break;

              case 450 < input < 501:
                input = 5;
                break;

              case 500 < input < 751:
                input = 6;
                break;

              case 750 < input < 1501:
                input = 7;
                break;

              case 1500 < input < 2251:
                input = 8;
                break;

              case 2250 < input < 5001:
                input = 9;
                break;

              default:
                input = 5;
                break;
            }
            input++;

            return input;
          }
          function smallOrNewFicBoostCalc(hits, engagmentCBKpH) {
            boost = 0;
            boost += (500 - hits);
            boost += (20 - engagmentCBKpH * weights[4]);
            if (boost < -5) boost = -5;
            if (boost > 520) boost = 520;

            boost = boost + 5;
            boost = boost / 52;

            return boost;
          }
          runScore();
        }
        runScript();
        if (QrunScript) {
          runScript();
          // logConsole('script running');
        } else {
          if (QrunScriptAlt) {
            // runScriptAlt();
            // logConsole("script not avaaliable yet for running on work page");
          } else {
            // logConsole("not running");
          }
        }
      }
    }
  }
  if (QtrainedScoreSystem && QextensionFullUpdated) {
    function ao3Qscore_ByC89sd_v2_35() {
      // ==UserScript==
      // @name        AO3 Qscore
      // @description Autosorting 'Quality' Indicator trained on 11k+ works. Very generous with small fics, rewards engagement over popularity (bookmarks-collections/kudos instead of hits) with a 0-100 score spread. Sort & position toggles included.
      // @version     2.35
      // @author      C89sd
      // @namespace   https://greasyfork.org/users/1376767
      // @match       https://archiveofourown.org/*
      // @grant       GM_addStyle
      // @noframes
      // ==/UserScript==
      'use strict';

      // ======================== CONFIGURATION ========================

      const SORT_USER_PAGE = true;

      /*
      # Scoring:
      There are 3 metrics pairs: (bookmarks, collections, comments)/kudos.
      Each pair has a trained regression model validated above a certain `min`.
      Each metric is tested against min, and if it passes, it is scored by the model; otherwise it gets dimmed to 0.
      The final score is derived by mixing all valid scores using a blend of MAX() and AVERAGE().
       
      - MAX     Keeps the best score, rewards works at the top of any single metric.
                Gives 100 scores if any of the metrics are 100.
      - AVERAGE Rewards works with the most high scores, and most valid metrics (3>2>1).
                Missing scores bring down the final score by blending in a 0.
                Only gives 100 scores if all three metrics are 100.
       
      Lowering `min` to be more generous with small works and show more scores
      would corrupt the top scores by making the models generate outside of their range.
       
      To solve this, I added `bmin`. If all the metrics are invalid (<min), the score
      is recomputed with the lower `>bmin` threshold. These scores are dimmed and placed at the bottom.
      Scores that fail this test as well get a dimmed 0.
      Since these scores are less accurate, they use a separate `BMIN_ALPHA` factor to smooth them more.
       
        If you do not care about being generous with small works, you can set 'ENABLE_BMIN=false',
      and raise the `dim_below` thresholds to fold more final scores in the dimmed section,
      or raise `min` but this will use the worse `bmin` to score those in the dimmed section.
        OR, if you want to adjust the separate BMIN_ALPHA for dimmed scores,
      you can keep `min=dim_below` and raise `bmin` and `min` directly .
      */

      // Add indicators showing the individual scores with z_scale applied (bookmarks, collections, comments).
      // Border color: yellow=bmin_valid, red=invalid.
      const DEBUG = false;
      // const DEBUG = true;

      // Blending factor between MAX and AVERAGE `finalScore = A*MAX+(1-A)*AVG`. 1=MAX, 0=AVERAGE
      const ALPHA = 0.99;
      const BMIN_ALPHA = 0.75;
      const ENABLE_BMIN = true;

      // Weight of missing scores in the Average formula.
      // Example: (ALPHA=0.7, zero_weight=0.3, avg_weight=1): 2 valid + 1 invalid (−3 pts); 1 valid + 2 invalid (−10 pts);
      const AVG_ZERO_WEIGHT = 0.3;

      // `min`        Metrics below this value are invalid and will not contribute to the final ALPHA blended score.
      // `bmin`       Bottom min. If ENABLE_BMIN=true, invalid final scores are *rescored* with `bmin` and `BMIN_ALPHA`, dimmed and sorted at the end.
      //
      // `dim_below`  Dim final scores if all metrics are below this second threshold.
      //              This is a convenience to hide smaller works without touching min.
      //              `dim_below=0` is disabled and default to `min`: the only dimmed scores are from the range [bmin,min[.
      // `avg_weight` Weight of a score in the weighted AVERAGE score.
      // `z_scale`    Scales the positive z-scores, resulting in fewer 100s for that metric.
      //              To halve the number of 100 scores: const Halve100 = 0.9176338854906885;
      //                                                 const Halve99  = 0.892167842806324;
      const THRESHOLDS = {
        'kudos': { bmin: 5, min: 8, /**/ dim_below: 0 }, // Gates all others.
        //
        'bookmarks': { bmin: 1, min: 3, /**/ dim_below: 0, avg_weight: 1.0, z_scale: 1.0 },
        'collections': { bmin: 1, min: 2, /**/ dim_below: 0, avg_weight: 1.0, z_scale: 1.0 },
        'comments': { bmin: Infinity, min: Infinity, /**/ dim_below: 0, avg_weight: 1.0, z_scale: 1.0 }, // bmin: 3, min: 3
        //
        'chapters': { bmin: 1, min: 2, /**/ dim_below: 0 }
      };
      // Replace {.dim_below=0 by .min}
      Object.values(THRESHOLDS).forEach(obj => obj.dim_below === 0 && (obj.dim_below = obj.min));
      // Note on 'chapters':
      //    ('comments','kudos') is actually ('comment_per_chapter','kudos_per_chapter').
      //    which is why this metric is gated on 'chapters' as well.

      // ======================== MODEL & CONSTANTS ========================

      let MODEL = { "Z_95": 1.0364333894937898, "regressions": [{ "x_metric": "bookmarks", "y_metric": "kudos", "x_grid": [0.0, 0.3323, 0.6646, 0.997, 1.3293, 1.6616, 1.9939, 2.3263, 2.6586, 2.9909, 3.3232, 3.6556, 3.9879, 4.3202, 4.6525, 4.9849, 5.3172, 5.6495, 5.9818, 6.3142, 6.6465, 6.9788, 7.3111, 7.6435, 7.9758, 8.3081, 8.6404, 8.9728, 9.3051, 9.6374, 9.9697, 10.3021, 10.6344, 10.9667, 11.299, 11.6314, 11.9637, 12.296, 12.6283, 12.9607], "q05_curve_y": [2.1722, 2.3297, 2.4859, 2.6704, 2.9142, 3.2016, 3.5162, 3.8411, 4.1655, 4.4864, 4.8014, 5.1093, 5.4097, 5.7043, 5.9953, 6.2845, 6.5734, 6.863, 7.1536, 7.4456, 7.7394, 8.036, 8.337, 8.6442, 8.9592, 9.2832, 9.6137, 9.9459, 10.2753, 10.5945, 10.894, 11.1935, 11.493, 11.7925, 12.092, 12.3915, 12.691, 12.9905, 13.29, 13.5895], "q50_curve_y": [2.6252, 2.8076, 2.99, 3.1987, 3.4591, 3.7542, 4.0665, 4.3786, 4.6822, 4.9785, 5.2694, 5.5568, 5.8423, 6.1263, 6.4088, 6.6897, 6.9693, 7.2481, 7.5271, 7.8075, 8.0904, 8.3768, 8.6675, 8.9631, 9.2643, 9.5715, 9.883, 10.1953, 10.5046, 10.8076, 11.1071, 11.4066, 11.7061, 12.0056, 12.3051, 12.6046, 12.9041, 13.2036, 13.5031, 13.8026], "q95_curve_y": [3.2949, 3.4494, 3.6051, 3.7878, 4.0228, 4.2933, 4.5821, 4.8722, 5.1554, 5.4336, 5.7092, 5.9846, 6.2616, 6.5397, 6.8183, 7.0964, 7.3736, 7.6496, 7.925, 8.2006, 8.4768, 8.7546, 9.0347, 9.3182, 9.606, 9.899, 10.1957, 10.493, 10.7875, 11.0783, 11.3778, 11.6773, 11.9768, 12.2763, 12.5758, 12.8753, 13.1748, 13.4743, 13.7738, 14.0733], "mu": 0.010967210394413519, "sigma": 1.0618674385105822 }, { "x_metric": "collections", "y_metric": "kudos", "x_grid": [0.0, 0.1849, 0.3698, 0.5547, 0.7395, 0.9244, 1.1093, 1.2942, 1.4791, 1.664, 1.8489, 2.0338, 2.2186, 2.4035, 2.5884, 2.7733, 2.9582, 3.1431, 3.328, 3.5128, 3.6977, 3.8826, 4.0675, 4.2524, 4.4373, 4.6222, 4.8071, 4.9919, 5.1768, 5.3617, 5.5466, 5.7315, 5.9164, 6.1013, 6.2861, 6.471, 6.6559, 6.8408, 7.0257, 7.2106], "q05_curve_y": [1.414, 2.2679, 3.0662, 3.8165, 4.5249, 5.1912, 5.8014, 6.3417, 6.8012, 7.1803, 7.486, 7.7255, 7.9099, 8.0571, 8.1842, 8.3065, 8.4306, 8.5581, 8.6903, 8.8278, 8.9698, 9.1149, 9.2619, 9.4096, 9.5572, 9.7011, 9.8291, 9.957, 10.0849, 10.2129, 10.3408, 10.4688, 10.5967, 10.7246, 10.8526, 10.9805, 11.1085, 11.2364, 11.3644, 11.4923], "q50_curve_y": [4.6143, 5.0468, 5.4793, 5.9118, 6.344, 6.7656, 7.1615, 7.5184, 7.8241, 8.0778, 8.2846, 8.4498, 8.5805, 8.6882, 8.7847, 8.8811, 8.9822, 9.0886, 9.2013, 9.3202, 9.4438, 9.5706, 9.6989, 9.8278, 9.9566, 10.0849, 10.2128, 10.3408, 10.4687, 10.5966, 10.7246, 10.8525, 10.9805, 11.1084, 11.2363, 11.3643, 11.4922, 11.6202, 11.7481, 11.8761], "q95_curve_y": [7.5724, 7.5553, 7.6064, 7.7156, 7.8738, 8.0693, 8.2843, 8.4997, 8.6981, 8.872, 9.021, 9.1463, 9.2512, 9.3418, 9.4254, 9.5093, 9.596, 9.6856, 9.7781, 9.8735, 9.9715, 10.0714, 10.1726, 10.2747, 10.3775, 10.4844, 10.6124, 10.7403, 10.8683, 10.9962, 11.1241, 11.2521, 11.38, 11.508, 11.6359, 11.7638, 11.8918, 12.0197, 12.1477, 12.2756], "mu": -0.021871244232891534, "sigma": 1.0510446029054428 }, { "x_metric": "comments", "y_metric": "kudos", "x_grid": [0.0, 0.3328, 0.6657, 0.9985, 1.3314, 1.6642, 1.9971, 2.3299, 2.6628, 2.9956, 3.3285, 3.6613, 3.9942, 4.327, 4.6599, 4.9927, 5.3256, 5.6584, 5.9913, 6.3241, 6.657, 6.9898, 7.3227, 7.6555, 7.9884, 8.3212, 8.6541, 8.9869, 9.3198, 9.6526, 9.9855, 10.3183, 10.6512, 10.984, 11.3169, 11.6497, 11.9826, 12.3154, 12.6483, 12.9811], "q05_curve_y": [2.0093, 2.3035, 2.5978, 2.8931, 3.1913, 3.4928, 3.7983, 4.1076, 4.4169, 4.7214, 5.0158, 5.2959, 5.5604, 5.8098, 6.0444, 6.2648, 6.4745, 6.6782, 6.8804, 7.0851, 7.289, 7.4859, 7.6695, 7.8344, 7.9817, 8.116, 8.2422, 8.3681, 8.495, 8.6219, 8.7488, 8.8757, 9.0026, 9.1294, 9.2563, 9.3832, 9.5101, 9.637, 9.7639, 9.8908], "q50_curve_y": [2.8284, 3.1258, 3.4232, 3.7217, 4.0229, 4.3275, 4.636, 4.9483, 5.2606, 5.5679, 5.8652, 6.1481, 6.4155, 6.6677, 6.9051, 7.1284, 7.3411, 7.5479, 7.7533, 7.9612, 8.1685, 8.369, 8.5563, 8.7249, 8.8761, 9.0144, 9.1446, 9.2716, 9.3984, 9.5253, 9.6522, 9.7791, 9.906, 10.0329, 10.1597, 10.2866, 10.4135, 10.5404, 10.6673, 10.7942], "q95_curve_y": [3.6809, 3.9759, 4.271, 4.5671, 4.866, 5.1684, 5.4748, 5.785, 6.0954, 6.4009, 6.6965, 6.9777, 7.2435, 7.4942, 7.7301, 7.9519, 8.1631, 8.3682, 8.5721, 8.7784, 8.9842, 9.183, 9.3686, 9.5355, 9.6847, 9.8211, 9.9493, 10.0758, 10.2027, 10.3296, 10.4564, 10.5833, 10.7102, 10.8371, 10.964, 11.0909, 11.2178, 11.3446, 11.4715, 11.5984], "mu": -0.02560361702737164, "sigma": 1.0479841045712814 }] };

      /* -- Halve100 --
      from scipy.stats import norm
      z = norm.ppf(98.5/100)      # round([99.5,100]) = 100
      p = 0.5 * (1 - norm.cdf(z)) # make 100s half as likely
      print("sigma scale:", z / norm.ppf(1 - p))
      */

      // --- HELPER FUNCTIONS ---
      function interpolate(xs, ys, targetX) {
        if (targetX <= xs[0]) return ys[0];
        if (targetX >= xs[xs.length - 1]) return ys[ys.length - 1];
        const i = xs.findIndex(x => x > targetX) - 1;
        const fraction = (targetX - xs[i]) / (xs[i + 1] - xs[i]);
        return ys[i] + fraction * (ys[i + 1] - ys[i]);
      }

      function sum(arr) { return arr.reduce((a, b) => a + b, 0); }

      function ncdf(z) {
        let t = 1 / (1 + 0.2315419 * Math.abs(z));
        let d = 0.3989423 * Math.exp(-z * z / 2);
        let prob = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
        if (z > 0) prob = 1 - prob;
        return prob;
      }

      // ======================== CORE SCORING FUNCTION ========================

      function calculateScore(article, metrics) {
        let valid_scores = []
        let bmin_valid_scores = []
        let all_scores = []
        let all_dimmed = true;

        for (const regression of MODEL.regressions) {
          const x_metric = regression.x_metric; // bookmarks
          const y_metric = regression.y_metric; // kudos

          let is_valid =
            metrics[x_metric] >= THRESHOLDS[x_metric].min &&
            metrics[y_metric] >= THRESHOLDS[y_metric].min &&
            (x_metric === 'comments' ? metrics['chapters'] >= THRESHOLDS['chapters'].min : true);

          let is_bmin_valid =
            is_valid ||
            metrics[x_metric] >= THRESHOLDS[x_metric].bmin &&
            metrics[y_metric] >= THRESHOLDS[y_metric].bmin &&
            (x_metric === 'comments' ? metrics['chapters'] >= THRESHOLDS['chapters'].bmin : true);

          let not_dimmed =
            is_valid &&
            metrics[x_metric] >= THRESHOLDS[x_metric].dim_below &&
            metrics[y_metric] >= THRESHOLDS[y_metric].dim_below &&
            (x_metric === 'comments' ? metrics['chapters'] >= THRESHOLDS['chapters'].dim_below : true);
          if (not_dimmed) all_dimmed = false;

          // Compute score
          const x_point = Math.log1p(metrics[x_metric]);
          const y_point = Math.log1p(metrics[y_metric]);

          const y_center = interpolate(regression.x_grid, regression.q50_curve_y, x_point);
          const y_lower = interpolate(regression.x_grid, regression.q05_curve_y, x_point);
          const y_upper = interpolate(regression.x_grid, regression.q95_curve_y, x_point);

          let ratio;
          let z_scale = 1.0;
          if (y_point >= y_center) {
            const upper_diff = y_upper - y_center;
            ratio = (upper_diff > 1e-6) ? (y_point - y_center) / upper_diff : 0.0;
          } else {
            const lower_diff = y_center - y_lower;
            ratio = (lower_diff > 1e-6) ? (y_point - y_center) / lower_diff : 0.0;
            z_scale = THRESHOLDS[x_metric].z_scale; // only scale positive zscores
          }
          const z_score = - MODEL.Z_95 * ratio; // flip the upside down graph

          const standardized_z = (z_score - regression.mu) / regression.sigma;
          const score = 100 * ncdf(standardized_z * z_scale);

          let res = { x_metric, score, is_valid, is_bmin_valid, dimmed: !not_dimmed, weight: THRESHOLDS[x_metric].avg_weight };
          if (is_valid) valid_scores.push(res);
          if (is_bmin_valid) bmin_valid_scores.push(res);
          all_scores.push(res);
        }

        const valid = (valid_scores.length > 0);
        const bmin_valid = (bmin_valid_scores.length > 0);

        if (valid) {
          // AVERAGE
          let premult_sum = 0.0,
            weights_sum = 0.0;
          for (let s of all_scores) {
            premult_sum += s.is_valid ? s.score * s.weight : 0.0;
            weights_sum += s.is_valid ? s.weight : s.weight * AVG_ZERO_WEIGHT;
          }
          let avg_score = premult_sum / weights_sum;

          // MAX
          let max_score = 0.0;
          for (let s of valid_scores) max_score = Math.max(max_score, s.score);

          const final_score = ALPHA * max_score + (1 - ALPHA) * avg_score;

          return [final_score, valid, true, all_dimmed, all_scores];
        }

        if (ENABLE_BMIN && bmin_valid) {
          // AVERAGE
          let premult_sum = 0.0,
            weights_sum = 0.0;
          for (let s of all_scores) {
            premult_sum += s.is_bmin_valid ? s.score * s.weight : 0.0;
            weights_sum += s.is_bmin_valid ? s.weight : s.weight * AVG_ZERO_WEIGHT;
          }
          let avg_score = premult_sum / weights_sum;

          // MAX
          let max_score = 0.0; // include invalid
          for (let s of bmin_valid_scores) max_score = Math.max(max_score, s.score);

          const final_score = BMIN_ALPHA * max_score + (1 - BMIN_ALPHA) * avg_score;

          return [final_score, false, true, true, all_scores];
        }

        return [0, false, false, true, all_scores];
      }

      // ---------------------------------- COLORS ----------------------------------




      const isDarkMode = window.getComputedStyle(document.body).color.match(/\d+/g)[0] > 128;
      if (isDarkMode) document.documentElement.classList.add('dark-theme');

      const HSL_STRINGS = [
        'hsl(0.0, 90.7%, 92.3%)',
        'hsl(47.8, 67.1%, 81.5%)',
        'hsl(118.4, 51.2%, 85%)',
        'hsl(122.9, 35.1%, 63.4%)',
      ];
      const COLORS = HSL_STRINGS.map(str => (([h, s, l]) => ({ h, s, l }))(str.match(/[\d.]+/g).map(Number)));

      function clamp(a, b, x) { return x < a ? a : (x > b ? b : x); }
      function color(t, range = 1.0, use3colors = false) {
        let a, b;
        t = t / range;
        if (t < 0) { t = 0.0; }
        if (use3colors && t > 1.0) { t = 1.0; }
        else if (t > 1.5) { t = 1.5; }

        if (t < 0.5) {
          a = COLORS[0], b = COLORS[1];
          t = t * 2.0;
        } else if (t <= 1.0) {
          a = COLORS[1], b = COLORS[2];
          t = (t - 0.5) * 2.0;
        } else {
          a = COLORS[2], b = COLORS[3];
          t = (t - 1.0) * 2.0;
        }
        const h = clamp(0, 360, a.h + (b.h - a.h) * t);
        const s = clamp(0, 100, a.s + (b.s - a.s) * t);
        const l = clamp(0, 100, a.l + (b.l - a.l) * t);
        return `hsl(${h.toFixed(1)}, ${s.toFixed(1)}%, ${l.toFixed(1)}%)`;
      }

      // ---------------------------------- NAVBAR ----------------------------------
      let navSortingString = null;
      let sortingTxt = ['⇊', '⇅'];
      let navCornerString = null;
      let cornerTxt = ['⇱', '⇲'];
      {
        let navbar = document.querySelector('ul.primary');
        if (navbar) {
          let searchBox = navbar.querySelector('.search');
          if (searchBox) {
            {
              let li = document.createElement('li');
              li.classList.add('dropdown');
              navSortingString = localStorage.getItem('C89AO3_sorting') || sortingTxt[0];
              navSortingString = sortingTxt.includes(navSortingString) ? navSortingString : sortingTxt[0];
              let a = document.createElement('a');
              a.className = 'halfWidth';
              a.textContent = navSortingString;
              a.href = '#';
              a.addEventListener('click', (e) => {
                navSortingString = sortingTxt[(sortingTxt.indexOf(a.textContent) + 1) % sortingTxt.length];
                a.textContent = navSortingString;
                localStorage.setItem('C89AO3_sorting', navSortingString);
                a.blur();
                toggleSorting(true);
              });
              li.appendChild(a);
              navbar.insertBefore(li, searchBox);
            }
            {
              let li = document.createElement('li');
              li.classList.add('dropdown');
              navCornerString = localStorage.getItem('C89AO3_corner') || cornerTxt[0];
              navCornerString = cornerTxt.includes(navCornerString) ? navCornerString : cornerTxt[0];
              let a = document.createElement('a');
              a.className = 'halfWidth';
              a.textContent = navCornerString;
              a.href = '#';
              a.addEventListener('click', (e) => {
                navCornerString = cornerTxt[(cornerTxt.indexOf(a.textContent) + 1) % cornerTxt.length];
                a.textContent = navCornerString;
                localStorage.setItem('C89AO3_corner', navCornerString);
                a.blur();
                toggleCorner();
              });
              li.appendChild(a);
              navbar.insertBefore(li, searchBox);
            }
          }
        }
      }

      // ---------------------------------- MAIN ----------------------------------

      const commaRegex = /,/g
      function parse(str) {
        return str ? parseInt(str.replace(commaRegex, ''), 10) : null;
      }

      let sortingData = [];
      const articles = document.querySelectorAll('li.work[role="article"], li.bookmark[class*="work-"], dl.work.meta.group');

      function removeOldScores() {
        document.querySelectorAll('.scoreA').forEach(el => el.remove());
      }

      function isVisible(el) { return window.getComputedStyle(el).display !== "none"; }

      function processArticles() {
        removeOldScores();
        sortingData = [];
        let i = 0;

        for (let article of articles) {
          let bookmarkCornerOccupied = !!article.querySelector('.status'); // isVisible(article.querySelector('.status'));
          let insideAWork = article?.tagName === 'DL';

          let stats = article.querySelector('dl.stats');
          if (!stats) continue;

          const metrics = {
            bookmarks: parse(stats.querySelector('dd.bookmarks')?.textContent) || 0,
            collections:
              insideAWork
                ? article.querySelector('dd.collections')?.children.length || 0
                : parse(stats.querySelector('dd.collections')?.textContent) || 0,
            comments: parse(stats.querySelector('dd.comments')?.textContent) || 0,
            kudos: parse(stats.querySelector('dd.kudos')?.textContent) || 0,
            chapters: parse(stats.querySelector('dd.chapters')?.textContent.split('/')[0]) || 1,
          };


          if (bookmarkCornerOccupied) article.classList.add('cornerFull');
          if (insideAWork) article.classList.add('inWork');


          let [finalScore, valid, bmin_valid, dimmed, all_scores] = calculateScore(article, metrics);

          function makeIndicator(score) {
            const el = document.createElement('span');
            el.classList.add('scoreA');
            el.textContent = Math.round(score);
            el.style.backgroundColor = Number.isNaN(score) ? '#b8b8b8' : color(score / 100, 1, true);
            if (dimmed) el.classList.add('darkenA');
            return el;
          }

          stats.appendChild(document.createTextNode(' '));

          const indicator = makeIndicator(finalScore);
          stats.appendChild(indicator);

          if (DEBUG) {
            const span = document.createElement("span");
            span.textContent = indicator.textContent;
            span.style.minWidth = '28px';
            span.style.zIndex = '999';
            span.style.boxShadow = 'rgba(0, 0, 0, 0.38) 0px 0px 10px';

            indicator.textContent = '';
            indicator.prepend(span);

            indicator.style.display = 'flex';
            indicator.style.alignItems = 'center';
            indicator.style.right = '85px';
            if (!valid) {
              if (bmin_valid) indicator.classList.add('bminValidA');
              else indicator.classList.add('invalidA');
            }

            stats.appendChild(indicator);

            all_scores.forEach(({ score, dimmed, is_valid, is_bmin_valid }) => {
              const dbg = makeIndicator(score);
              if (dimmed) dbg.classList.add('darkenA');
              if (is_valid) { } // dbg.classList.add('validA');
              else if (is_bmin_valid) dbg.classList.add('bminValidA');
              else dbg.classList.add('invalidA');
              dbg.style.position = 'static';
              dbg.style.display = 'inline-block';
              dbg.style.minWidth = '28px';
              indicator.appendChild(dbg);
            });
          }

          let sortKey = dimmed ? finalScore : finalScore + 100;
          sortingData.push({ indicator, article, score: finalScore, index: i++, bookmarkCornerOccupied, insideAWork, sortKey });
        }
      }

      function updateAllScores() {
        processArticles();
        toggleSorting();
        toggleCorner();
      }

      // ---------------------------------- SORTING ----------------------------------

      let isSorted = false;
      function toggleSorting(manual = false) {
        if (location.href.includes('/users/') && !SORT_USER_PAGE && !manual) return; // don't sort user pages unless manually toggled
        if (location.href.includes('/series/')) return; // keep series pages chronological

        let parent = articles[0]?.parentNode;
        if (parent) {
          let run = false;
          if (navSortingString === sortingTxt[0]) {
            sortingData.sort((a, b) => b.sortKey - a.sortKey); isSorted = true; run = true;
          } else if (isSorted) {
            sortingData.sort((a, b) => a.index - b.index); isSorted = false; run = true;
          }
          if (run) sortingData.forEach(({ article }) => {
            parent.appendChild(article);
          });
        }
      }

      // ---------------------------------- CORNER TOGGLE ----------------------------------

      let isInCorner = false;
      function toggleCorner() {
        let run = false;
        if (navCornerString === cornerTxt[0]) {
          isInCorner = true; run = true;
        } else if (isInCorner) {
          isInCorner = false; run = true;
        }
        if (run) {
          sortingData.forEach(({ article, indicator, insideAWork }) => {
            if (indicator) {
              article.querySelector('.datetime')?.classList.add('isDate'); // can be null if inside a work

              if (isInCorner) {
                let cornerParent = insideAWork ? article : article.querySelector('div.header.module');
                if (cornerParent) {
                  article.classList.add('inCorner');
                  cornerParent.appendChild(indicator);
                }
              }
              else {
                let stats = article.querySelector('dl.stats');
                if (stats) {
                  article.classList.remove('inCorner');
                  stats.appendChild(indicator);
                }
              }
            }
          });
        }
      }


      GM_addStyle(`
  /* half width navbar toggle */
  .halfWidth { width: 1.3ch !important; padding: 0.429em calc(0.75em/1) !important; }
 
  /* Indicator styling */
  .scoreA { display: inline-block; width: 28px; text-align: center; line-height: 18px; padding: 0; color: rgb(42,42,42); }  /* em scales different on mobile */
 
  /* Position inside Work pages (needs repeated selector to win) */
  .inWork.inWork.inWork          .scoreA { float: right; }  /* .stats becomes float:left inside works */
  .inWork.inWork.inWork.inCorner .scoreA { position: absolute; top: 10px; right: 10px; z-index: 1; }
 
   /* Default corner position */
  .inCorner .scoreA { position: absolute; top: -3px; right: -2px; }
  .inCorner .isDate { top: 17px; }
 
   /* Move extra below the corner Private Bookmark icon */
  .inCorner.cornerFull:not(.khx-collapsed) .isDate { top: calc(17px + 28px); }
  .inCorner.cornerFull:not(.khx-collapsed) .scoreA { top: 27px; }
 
  /* ?? khx fix skipped before:: text
   .skipped-work .isDate { top: -18px; } */
 
  @-moz-document url-prefix() {
    @media (max-width: 655px) {
      .scoreA {
        width: 26px; /* on desktop 26px doesn't cover the date, 27 does, but the 26px gap looks nicer on mobile. */
      }
    }
  }
  :root {
    --boost:    85%;
    --boostDM:  75%; /* 82%; */
    --darken:   55%;
    --darkenDM: 33.3%;
  }
  :root.dark-theme {
    --darken: var(--darkenDM);
    --boost:  var(--boostDM);
  }
  .scoreA {
    background-image: linear-gradient(hsl(0, 0%, var(--boost)), hsl(0, 0%, var(--boost)));
    background-blend-mode: color-burn;
  }
  .scoreA.darkenA, .darkenA {
    background-image: linear-gradient(hsl(0, 0%, var(--darken)), hsl(0, 0%, var(--darken)));
    background-blend-mode: multiply;
  }
  .invalidA { border: solid 1px #d00 }
  .validA { border: solid 1px #008d00 }
  .bminValidA { border: solid 1px #e1a518 }
`);
      function GM_addStyle(input) {
        let head = document.getElementsByTagName("head")[0];
        let style = document.createElement("style");
        style.innerText = input;
        head.appendChild(style);
      }

      updateAllScores()
    }
    ao3Qscore_ByC89sd_v2_35();
  }
  if (QblockAndHighlightWorks && QextensionFullUpdated) {
    function blockerAndHighleter(tagBlacklistFU = "*W. D. Gaster*, */reader*, *reader/*", tagHighlightsFU = "*Chara*, *chara*") {
      // ==UserScript==
      // @name          AO3 Blocker
      // @description   Fork of ao3 savior; blocks works based on certain conditions
      // @author        JacenBoy
      // @namespace     https://github.com/JacenBoy/ao3-blocker#readme
      // @license       Apache-2.0; http://www.apache.org/licenses/LICENSE-2.0
      // @match         http*://archiveofourown.org/*
      // @version       3.1
      // @require       https://openuserjs.org/src/libs/sizzle/GM_config.js
      // @require       https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js
      // @grant         GM.getValue
      // @grant         GM.setValue
      // @run-at        document-end
      // ==/UserScript==

      /* globals $, GM_config */

      let HighlightColorHex = "373432";
      (function () {
        "use strict";
        window.ao3Blocker = {};

        // Initialize GM_config options
        GM_config.init({
          "id": "ao3Blocker",
          "title": "AO3 Blocker",
          "fields": {
            "tagBlacklist": {
              "label": "Tag Blacklist",
              "type": "text",
              "default": tagBlacklistFU
            },
            "tagWhitelist": {
              "label": "Tag Whitelist",
              "type": "text",
              "default": ""
            },
            "tagHighlights": {
              "label": "Highlighted Tags",
              "type": "text",
              "default": tagHighlightsFU
            },
            "authorBlacklist": {
              "label": "Author Blacklist",
              "type": "text",
              "default": ""
            },
            "titleBlacklist": {
              "label": "Title Blacklist",
              "type": "text",
              "default": ""
            },
            "summaryBlacklist": {
              "label": "Summary Blacklist",
              "type": "text",
              "default": ""
            },
            "showReasons": {
              "label": "Show Block Reason",
              "type": "checkbox",
              "default": true
            },
            "showPlaceholders": {
              "label": "Show Work Placeholder",
              "type": "checkbox",
              "default": true
            },
            "alertOnVisit": {
              "label": "Alert When Opening Blocked Work",
              "type": "checkbox",
              "default": false
            },
            "debugMode": {
              "label": "Debug Mode",
              "type": "checkbox",
              "default": true
            }
          },
          "events": {
            "save": () => {
              window.ao3Blocker.updated = true;
              alert("Your changes have been saved.");
            },
            "close": () => {
              if (window.ao3Blocker.updated) location.reload();
            },
            "init": () => {
              // Config is now available
              window.ao3Blocker.config = {
                "showReasons": GM_config.get("showReasons"),
                "showPlaceholders": GM_config.get("showPlaceholders"),
                "alertOnVisit": GM_config.get("alertOnVisit"),
                "authorBlacklist": GM_config.get("authorBlacklist").toLowerCase().split(/,(?:\s)?/g).map(i => i.trim()),
                "titleBlacklist": GM_config.get("titleBlacklist").toLowerCase().split(/,(?:\s)?/g).map(i => i.trim()),
                "tagBlacklist": GM_config.get("tagBlacklist").toLowerCase().split(/,(?:\s)?/g).map(i => i.trim()),
                "tagWhitelist": GM_config.get("tagWhitelist").toLowerCase().split(/,(?:\s)?/g).map(i => i.trim()),
                "tagHighlights": GM_config.get("tagHighlights").toLowerCase().split(/,(?:\s)?/g).map(i => i.trim()),
                "summaryBlacklist": GM_config.get("summaryBlacklist").toLowerCase().split(/,(?:\s)?/g).map(i => i.trim()),
                "debugMode": GM_config.get("debugMode")
              }

              addMenu();
              addStyle();
              setTimeout(checkWorks, 10);
            }
          },
          "css": ".config_var {display: grid; grid-template-columns: repeat(2, 0.7fr);}"
        });

        // Define the custom styles for the script
        const STYLE = "\n  html body .ao3-blocker-hidden {\n    display: none;\n  }\n  \n  .ao3-blocker-cut {\n    display: none;\n  }\n  \n  .ao3-blocker-cut::after {\n    clear: both;\n    content: '';\n    display: block;\n  }\n  \n  .ao3-blocker-reason {\n    margin-left: 5px;\n  }\n  \n  .ao3-blocker-hide-reasons .ao3-blocker-reason {\n    display: none;\n  }\n  \n  .ao3-blocker-unhide .ao3-blocker-cut {\n    display: block;\n  }\n  \n  .ao3-blocker-fold {\n    align-items: center;\n    display: flex;\n    justify-content: flex-start;\n  }\n  \n  .ao3-blocker-unhide .ao3-blocker-fold {\n    border-bottom: 1px dashed;\n    margin-bottom: 15px;\n    padding-bottom: 5px;\n  }\n  \n  button.ao3-blocker-toggle {\n    margin-left: auto;\n  }\n";

        // addMenu() - Add a custom menu to the AO3 menu bar to control our configuration options
        function addMenu() {
          // Define our custom menu and add it to the AO3 menu bar
          const headerMenu = $("ul.primary.navigation.actions");
          const blockerMenu = $("<li class=\"dropdown\"></li>").html("<a>AO3 Blocker</a>");
          headerMenu.find("li.search").before(blockerMenu);
          const dropMenu = $("<ul class=\"menu dropdown-menu\"></ul>");
          blockerMenu.append(dropMenu);

          // Add the "Toggle Block Reason" option to the menu
          const reasonButton = $("<li></li>").html(`<a>${window.ao3Blocker.config.showReasons ? "Hide" : "Show"} Block Reason</a>`);
          reasonButton.on("click", () => {
            if (window.ao3Blocker.config.showReasons) {
              GM_config.set("showReasons", false);
            } else {
              GM_config.set("showReasons", true);
            }
            GM_config.save();
            reasonButton.html(`<a>${window.ao3Blocker.config.showReasons ? "Hide" : "Show"} Block Reason</a>`);
          });
          dropMenu.append(reasonButton);

          // Add the "Toggle Work Placeholder" option to the menu
          const placeholderButton = $("<li></li>").html(`<a>${window.ao3Blocker.config.showPlaceholders ? "Hide" : "Show"} Work Placeholder</a>`);
          placeholderButton.on("click", () => {
            if (window.ao3Blocker.config.showPlaceholders) {
              GM_config.set("showPlaceholders", false);
            } else {
              GM_config.set("showPlaceholders", true);
            }
            GM_config.save();
            placeholderButton.html(`<a>${window.ao3Blocker.config.showPlaceholders ? "Hide" : "Show"} Work Placeholder</a>`);
          });
          dropMenu.append(placeholderButton);

          // Add the "Toggle Block Alerts" option to the menu
          const alertButton = $("<li></li>").html(`<a>${window.ao3Blocker.config.alertOnVisit ? "Don't Show" : "Show"} Blocked Work Alerts</a>`);
          alertButton.on("click", () => {
            if (window.ao3Blocker.config.alertOnVisit) {
              GM_config.set("alertOnVisit", false);
            } else {
              GM_config.set("alertOnVisit", true);
            }
            GM_config.save();
            alertButton.html(`<a>${window.ao3Blocker.config.alertOnVisit ? "Don't Show" : "Show"} Blocked Work Alerts</a>`);
          });
          dropMenu.append(alertButton);

          // Add an option to show the config dialog
          const settingsButton = $("<li></li>").html("<a>All Settings</a>");
          settingsButton.on("click", () => { GM_config.open(); });
          dropMenu.append(settingsButton);
        }

        // Define the CSS namespace. All CSS classes are prefixed with this.
        const CSS_NAMESPACE = "ao3-blocker";

        // addStyle() - Apply the custom stylesheet to AO3
        function addStyle() {
          const style = $(`<style class="${CSS_NAMESPACE}"></style>`).html(STYLE);

          $("head").append(style);
        }

        // getCut(work) - Move standard AO3 work information (tags, summary, etc.) to a custom element for blocked works. This will be hidden by default on blocked works but can be shown if thre user chooses.
        function getCut(work) {
          const cut = $(`<div class="${CSS_NAMESPACE}-cut"></div>`);

          $.makeArray(work.children()).forEach((child) => {
            return cut.append(child);
          });

          return cut;
        }

        // getFold(reason) - Create the work placeholder for blocked works. Optionally, this will show why the work was blocked and give the user the option to unhide it.
        function getFold(reasons) {
          const fold = $(`<div class="${CSS_NAMESPACE}-fold"></div>`);
          const note = $(`<span class="${CSS_NAMESPACE}-note"</span>`).text("This work is hidden! ");

          fold.html(note);
          fold.append(getReasonSpan(reasons));
          fold.append(getToggleButton());

          return fold;
        }

        // getToggleButton() - Create a button that will show or hide the "cut" on blocked works.
        function getToggleButton() {
          const button = $(`<button class="${CSS_NAMESPACE}-toggle"></button>`).text("Unhide");
          const unhideClassFragment = `${CSS_NAMESPACE}-unhide`;

          button.on("click", (event) => {
            const work = $(event.target).closest(`.${CSS_NAMESPACE}-work`);

            if (work.hasClass(unhideClassFragment)) {
              work.removeClass(unhideClassFragment);
              work.find(`.${CSS_NAMESPACE}-note`).text("This work is hidden.");
              $(event.target).text("Unhide");
            } else {
              work.addClass(unhideClassFragment);
              work.find(`.${CSS_NAMESPACE}-note`).text("ℹ️ This work was hidden.");
              $(event.target).text("Hide");
            }
          });

          return button;
        }

        // getReasonSpan(reason) - Create the element that holds the block reason information on blocked works.
        function getReasonSpan(reasons) {
          const span = $(`<span class="${CSS_NAMESPACE}-reason"></span>`);

          if (!reasons || reasons.length === 0) {
            return span;
          }

          const reasonTexts = [];

          reasons.forEach((reason) => {
            if (reason.tags) {
              if (reason.tags.length === 1) {
                reasonTexts.push(`tags include <strong>${reason.tags[0]}</strong>`);
              } else {
                const tagList = reason.tags.map(tag => `<strong>${tag}</strong>`).join(', ');
                reasonTexts.push(`tags include ${tagList}`);
              }
            }

            if (reason.authors) {
              if (reason.authors.length === 1) {
                reasonTexts.push(`author is <strong>${reason.authors[0]}</strong>`);
              } else {
                const authorList = reason.authors.map(author => `<strong>${author}</strong>`).join(', ');
                reasonTexts.push(`authors include ${authorList}`);
              }
            }

            if (reason.titles) {
              if (reason.titles.length === 1) {
                reasonTexts.push(`title matches <strong>${reason.titles[0]}</strong>`);
              } else {
                const titleList = reason.titles.map(title => `<strong>${title}</strong>`).join(', ');
                reasonTexts.push(`title matches ${titleList}`);
              }
            }

            if (reason.summaryTerms) {
              if (reason.summaryTerms.length === 1) {
                reasonTexts.push(`summary includes <strong>${reason.summaryTerms[0]}</strong>`);
              } else {
                const termList = reason.summaryTerms.map(term => `<strong>${term}</strong>`).join(', ');
                reasonTexts.push(`summary includes ${termList}`);
              }
            }
          });

          if (reasonTexts.length > 0) {
            // Join multiple reasons with semicolons for better readability
            const reasonText = reasonTexts.join('; ');
            span.html(`(Reason: ${reasonText}.)`);
          }

          return span;
        }

        // blockWork(work, reason, config) - Replace the standard AO3 work information with the placeholder "fold", and place the "cut" below it, hidden.
        function blockWork(work, reasons, config) {
          if (!reasons) return;

          if (config.showPlaceholders) {
            const fold = getFold(reasons);
            const cut = getCut(work);

            work.addClass(`${CSS_NAMESPACE}-work`);
            work.html(fold);
            work.append(cut);

            if (!config.showReasons) {
              work.addClass(`${CSS_NAMESPACE}-hide-reasons`);
            }
          } else {
            work.addClass(`${CSS_NAMESPACE}-hidden`);
          }
        }

        function matchTermsWithWildCard(term0, pattern0) {
          const term = term0.toLowerCase();
          const pattern = pattern0.toLowerCase();

          if (term === pattern) return true;
          if (pattern.indexOf("*") === -1) return false;

          const lastMatchedIndex = pattern.split("*").filter(Boolean).reduce((prevIndex, chunk) => {
            const matchedIndex = term.indexOf(chunk);
            return prevIndex >= 0 && prevIndex <= matchedIndex ? matchedIndex : -1;
          }, 0);

          return lastMatchedIndex >= 0;
        }

        function isTagWhitelisted(tags, whitelist) {
          const whitelistLookup = whitelist.reduce((lookup, tag) => {
            lookup[tag.toLowerCase()] = true;
            return lookup;
          }, {});

          return tags.some((tag) => {
            return !!whitelistLookup[tag.toLowerCase()];
          });
        }

        function findBlacklistedItem(list, blacklist, comparator) {
          let matchingEntry = void 0;

          list.some((item) => {
            blacklist.some((entry) => {
              const matched = comparator(item.toLowerCase(), entry.toLowerCase());

              if (matched) matchingEntry = entry;

              return matched;
            });
          });

          return matchingEntry;
        }

        function equals(a, b) {
          return a === b;
        }
        function contains(a, b) {
          return a.indexOf(b) !== -1;
        }

        function getBlockReason(_ref, _ref2) {
          const _ref$authors = _ref.authors,
            authors = _ref$authors === undefined ? [] : _ref$authors,
            _ref$title = _ref.title,
            title = _ref$title === undefined ? "" : _ref$title,
            _ref$tags = _ref.tags,
            tags = _ref$tags === undefined ? [] : _ref$tags,
            _ref$summary = _ref.summary,
            summary = _ref$summary === undefined ? "" : _ref$summary;
          const _ref2$authorBlacklist = _ref2.authorBlacklist,
            authorBlacklist = _ref2$authorBlacklist === undefined ? [] : _ref2$authorBlacklist,
            _ref2$titleBlacklist = _ref2.titleBlacklist,
            titleBlacklist = _ref2$titleBlacklist === undefined ? [] : _ref2$titleBlacklist,
            _ref2$tagBlacklist = _ref2.tagBlacklist,
            tagBlacklist = _ref2$tagBlacklist === undefined ? [] : _ref2$tagBlacklist,
            _ref2$tagWhitelist = _ref2.tagWhitelist,
            tagWhitelist = _ref2$tagWhitelist === undefined ? [] : _ref2$tagWhitelist,
            _ref2$summaryBlacklis = _ref2.summaryBlacklist,
            summaryBlacklist = _ref2$summaryBlacklis === undefined ? [] : _ref2$summaryBlacklis;

          // If whitelisted, don't block regardless of other conditions
          if (isTagWhitelisted(tags, tagWhitelist)) {
            return null;
          }

          const reasons = [];

          // Check for blocked tags (collect all matching tags)
          const blockedTags = [];
          tags.forEach((tag) => {
            tagBlacklist.forEach((blacklistedTag) => {
              // Skip empty or whitespace-only terms
              if (blacklistedTag.trim() && matchTermsWithWildCard(tag.toLowerCase(), blacklistedTag.toLowerCase())) {
                blockedTags.push(blacklistedTag);
              }
            });
          });
          if (blockedTags.length > 0) {
            reasons.push({ tags: blockedTags });
          }

          // Check for blocked authors (collect all matching authors)
          const blockedAuthors = [];
          authors.forEach((author) => {
            authorBlacklist.forEach((blacklistedAuthor) => {
              // Skip empty or whitespace-only terms
              if (blacklistedAuthor.trim() && author.toLowerCase() === blacklistedAuthor.toLowerCase()) {
                blockedAuthors.push(blacklistedAuthor);
              }
            });
          });
          if (blockedAuthors.length > 0) {
            reasons.push({ authors: blockedAuthors });
          }

          // Check for blocked title
          const blockedTitles = [];
          titleBlacklist.forEach((blacklistedTitle) => {
            // Skip empty or whitespace-only terms
            if (blacklistedTitle.trim() && matchTermsWithWildCard(title.toLowerCase(), blacklistedTitle.toLowerCase())) {
              blockedTitles.push(blacklistedTitle);
            }
          });
          if (blockedTitles.length > 0) {
            reasons.push({ titles: blockedTitles });
          }

          // Check for blocked summary terms
          const blockedSummaryTerms = [];
          summaryBlacklist.forEach((summaryTerm) => {
            // Skip empty or whitespace-only terms
            if (summaryTerm.trim() && summary.toLowerCase().indexOf(summaryTerm.toLowerCase()) !== -1) {
              blockedSummaryTerms.push(summaryTerm);
            }
          });
          if (blockedSummaryTerms.length > 0) {
            reasons.push({ summaryTerms: blockedSummaryTerms });
          }

          return reasons.length > 0 ? reasons : null;
        }

        const _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

        function getText(element) {
          return $(element).text().replace(/^\s*|\s*$/g, "");
        }
        function selectTextsIn(root, selector) {
          return $.makeArray($(root).find(selector)).map(getText);
        }

        function selectFromWork(container) {
          return _extends({}, selectFromBlurb(container), {
            title: selectTextsIn(container, ".title")[0],
            summary: selectTextsIn(container, ".summary .userstuff")[0]
          });
        }

        function selectFromBlurb(blurb) {
          return {
            authors: selectTextsIn(blurb, "a[rel=author]"),
            tags: [].concat(selectTextsIn(blurb, "a.tag"), selectTextsIn(blurb, ".required-tags .text")),
            title: selectTextsIn(blurb, ".header .heading a:first-child")[0],
            summary: selectTextsIn(blurb, "blockquote.summary")[0]
          };
        }

        // checkWorks() - Scan all works on the page and block them if they match one of the conditions set by the user.
        function checkWorks() {
          const debugMode = window.ao3Blocker.config.debugMode;

          const config = window.ao3Blocker.config;
          // If this is a work page, save the element for future use.
          const workContainer = $("#main.works-show") || $("#main.chapters-show");
          let blocked = 0;
          let total = 0;

          if (debugMode) {
            console.groupCollapsed("AO3 BLOCKER");

            if (!config) {
              console.warn("Exiting due to missing config.");
              return;
            }
          }

          // Loop through all works on the search page and check if they match one of the conditions.
          $.makeArray($("li.blurb")).forEach((blurb) => {
            blurb = $(blurb);
            const blockables = selectFromBlurb(blurb);
            const reason = getBlockReason(blockables, config);

            total++;

            if (reason) {
              blockWork(blurb, reason, config);
              blocked++;

              if (debugMode) {
                console.groupCollapsed(`- blocked ${blurb.attr("id")}`);
                logConsole(blurb.html(), reason);
                console.groupEnd();
              }
            } else if (debugMode) {
              console.groupCollapsed(`  skipped ${blurb.attr("id")}`);
              logConsole(blurb.html());
              console.groupEnd();
            }

            blockables.tags.forEach((tag) => {
              if (config.tagHighlights.includes(tag.toLowerCase())) {
                // blurb.css("background-color", "rgba(255,255,0,0.1)");
                blurb.css("background-color", `#${HighlightColorHex}`);
                if (debugMode) {
                  console.groupCollapsed(`? highlighted ${blurb.attr("id")}`);
                  logConsole(blurb.html());
                  console.groupEnd();
                }
              }
            });
          });

          // If this is a work page, the work was navigated to from another site (i.e. an external link), and the user had block alerts enabled, show a warning.
          if (config.alertOnVisit && workContainer && document.referrer.indexOf("//archiveofourown.org") === -1) {

            const blockables = selectFromWork(workContainer);
            const reason = getBlockReason(blockables, config);

            if (reason) {
              blocked++;
              blockWork(workContainer, reason, config);
            }
          }

          if (debugMode) {
            logConsole(`Blocked ${blocked} out of ${total} works`);
            console.groupEnd();
          }
        }
      }());
    }
    blockerAndHighleter();
  }
  if (QoptionalExtraScriptsEnabled && QextensionFullUpdated) {
    // ==UserScript==
    // @name        ao3 saved filters
    // @description Adds fields for persistent global & fandom filters to works index pages on AO3
    // @namespace   ao3
    // @include     http*://www.archiveofourown.org/*works*
    // @include     http*://archiveofourown.org/*works*
    // @grant       none
    // @version     1.5
    // ==/UserScript==

    (function ($) {
      // config
      var TAG_OWNERSHIP_PERCENT = 70; // the top fandom which owns works in the current tag must own at least this percent in order to be considered the search's active fandom

      var works = $('#main.works-index'), form = $('form#work-filters');
      if (!works[0] || !form[0]) return;

      var fandomName = (function () {
        var fandom = $('#include_fandom_tags label').first().text(),
          fandomCount = parseInt(
            fandom.substring(fandom.lastIndexOf('(') + 1, fandom.lastIndexOf(')'))
          ),
          tagCount = works.find('.heading').first().text();

        tagCount = tagCount.substring(0, tagCount.indexOf(' Works'));
        tagCount = parseInt(tagCount.substring(tagCount.lastIndexOf(' ') + 1));

        fandom = fandom.substring(0, fandom.lastIndexOf('(')).trim();

        if (!fandom || !fandomCount || !tagCount) { return; }

        return (fandomCount / tagCount * 100 > TAG_OWNERSHIP_PERCENT) ? fandom : null;
      })(),
        tempKey = 'temp-filter', tempFilter = localStorage[tempKey],
        tempGlobalKey = 'temp-global-filter',
        tempGlobalFilter = localStorage[tempGlobalKey],
        tempFandomKey = 'temp-fandom-filter',
        tempFandomFilter = localStorage[tempFandomKey],
        globalKey = 'global-filter', fandomKey = fandomName ? 'filter-' + fandomName : '',
        globalBox = $('<textarea>').val(localStorage[globalKey] ?
          localStorage[globalKey] : ''),
        fandomBox = fandomKey ?
          globalBox.clone().val(localStorage[fandomKey] ? localStorage[fandomKey] : '') : $(),
        search = $('#work_search_query'),
        dt = search.parents('dd').first().prev(dt),
        realSearch = $('<textarea>')
          .attr('name', search.attr('name'))
          .css('display', 'none')
          .insertAfter(search.removeAttr('name')),
        collapser = $('<dt>').addClass('saved-filters-collapser'),
        rightArrow = $('<img>').attr('src', '/images/arrow-right.gif?1352358192'),
        downArrow = $('<img>').attr('src', '/images/arrow-down.gif?1352358192'),
        container = $('<div>').addClass('saved-filters'),
        prevSearch = (function () {
          var ps, key = realSearch.attr('name') + '=';
          if (decodeURIComponent(window.location).indexOf(key) > 0) {
            ps = decodeURIComponent(window.location);
            ps = ps.substring(ps.indexOf(key) + key.length);
            ps = ps.indexOf('&') != -1 ? ps.substring(0, ps.indexOf('&')) : ps;
          }
          return ps;
        })();

      $('<style>').text(
        '.saved-filters-collapser { cursor: pointer; } .saved-filters, saved-filters > div { margin-bottom: 0.6em; } .saved-filters { border-style: solid; border-width: 1px; padding: 0.6em; } .saved-filters textarea { min-height: 8em; } .saved-filters div label { padding-left: 3px; } .prev-search span { color: #000; } .prev-search .temp { background: #ACEA72; } .prev-search .global { background: #93D2ED; } .prev-search .fandom { background: #B9AAED; }'
      ).appendTo($('head'));

      globalBox.addClass('global-filter')
        .add(fandomBox.addClass('fandom-filter'))
        .each(function () {
          var ta = $(this),
            cls = ta.attr('class'),
            title = cls.charAt(0).toUpperCase() + cls.substring(1, cls.indexOf('-')) + ':';

          $('<div>').addClass(`${cls} ao3-saved-filters-section`)
            .prepend(title)
            .append(ta.removeClass(),
              $('<label>').text('Enabled')
                .prepend(
                  $('<input>').attr({ 'type': 'checkbox' })
                    .addClass('js-enabled-checkbox')
                    .css({
                      clip: 'auto',
                      'margin-right': '0.3em',
                      position: 'relative',
                      width: 'auto',
                    })
                ),
              $('<button>')
                .attr('type', 'button')
                .addClass('action js-save-filter')
                .text('Save')
            ).appendTo(container);
        });

      container.find('.ao3-saved-filters-section').each(function () {
        var $section = $(this),
          $checkbox = $section.find('.js-enabled-checkbox'),
          $saveButton = $section.find('.js-save-filter'),
          key = $saveButton.parents('.global-filter')[0] ? globalKey : fandomKey,
          checked = localStorage[key + '-on'] !== 'false';

        $checkbox.attr('checked', checked);
        $saveButton.click(function () {
          localStorage[key] = $saveButton.siblings('textarea').val();
          localStorage[key + '-on'] = $checkbox.is(':checked') + '';
        });
      });

      if (tempFilter && search.val().indexOf(tempFilter) != -1) {
        search.val(tempFilter);
      } else {
        localStorage[tempFilter] = '';
        search.val('');
      }

      container = $('<dd>').append(container);

      collapser.prepend(rightArrow,
        ' Saved filters'
      ).click(function () {
        container.toggle();
        collapser.children('img').replaceWith(
          container.is(':visible') ? downArrow : rightArrow);
      }).add(container.hide()).insertBefore(dt);

      form.submit(function () {
        var val = search.val() || '';

        container.find('.ao3-saved-filters-section').each(function () {
          var $section = $(this);
          var $textarea = $section.find('textarea');
          var enabled = $section.find('.js-enabled-checkbox').is(':checked');
          var key = $textarea.parents('.global-filter')[0] ? tempGlobalKey : tempFandomKey;

          if ($textarea.val() && enabled) {
            localStorage[key] = $textarea.val();

            if ((' ' + val + ' ').indexOf(' ' + $textarea.val() + ' ') < 0) {
              val += ' ' + $textarea.val();
            }
          } else if (localStorage[key]) {
            localStorage[key] = '';
          }
        });

        localStorage[tempKey] = search.val();
        realSearch.val(val);
      });

      if (prevSearch) {
        prevSearch = 'Your filter was: ' + decodeURIComponent(prevSearch).split('+').join(' ') + '.';
        if (tempFilter) {
          prevSearch = prevSearch.replace(tempFilter, '<span class="temp">' + tempFilter + '</span>');
        }
        if (tempGlobalFilter) {
          prevSearch = prevSearch.replace(tempGlobalFilter, '<span class="global">' + tempGlobalFilter + '</span>');
        }
        if (tempFandomFilter) {
          prevSearch = prevSearch.replace(tempFandomFilter, '<span class="fandom">' + tempFandomFilter + '</span>');
        }

        works.find('.heading').first().after(
          $('<div>').addClass('prev-search').append(prevSearch));
      } else if ((localStorage[globalKey] && localStorage[globalKey + '-on'] !== 'false') ||
        (localStorage[fandomKey] && localStorage[fandomKey + '-on'] !== 'false')) {
        form.submit();
      }

    })(window.jQuery);
  }
  if (false) {  // script disabled
    if (document.location.href.match(/works\/(\d\d*).*/)) {
      let firstTimeFicDislike = true;
      let QficDisliked;
      setInterval(() => {
        if (firstTimeFicDislike) {
          if (localStorage.getItem(`pap_fds${currWorkId}`)) {
            QficDisliked = true;
          } else {
            QficDisliked = false;
          }
          let dislikeBtnStyle;
          let ficDislikeText;
          let dislikeDestURL = document.location.href.split("?")[0] + "#feedback";
          if (document.location.href.split("?")[1] == "#feedback" || QficDisliked) {
            logConsole("Fic disliked");
            ficDisliked = true;
            ficDislikeText = "Fic Disliked";
            QficDisliked = true;
            dislikeBtnStyle = "color: red;";
            dislikeDestURL = document.location.href.split("?")[0] + "#kudos_message?disliked=false";
          } else {
            ficDisliked = false;
            ficDislikeText = "Dislike 🖓";
            QficDisliked = false;
            dislikeBtnStyle = "";
            dislikeDestURL = document.location.href.split("?")[0] + "#feedback";
          }

          let pap_feedback = document.getElementById("feedback");
          pap_feedback = pap_feedback.getElementsByClassName("actions")[0];

          let pap_li = document.createElement("li");
          pap_li.id = "dislike_button"

          let pap_form = document.createElement("form");
          pap_form.id = "new_dislike";
          pap_form.action = dislikeDestURL;
          pap_form.autocomplete = "off";

          // let pap_input = document.createElement("input");
          // pap_input.value = "58887757";
          // pap_input.autocomplete = "off";
          // pap_input.type = "hidden";
          // pap_input.name = "dislike[commentable_id]";
          // pap_input.id = "dislike_commentable_id";
          // pap_form.appendChild(pap_input);

          // let pap_input2 = document.createElement("input");
          // pap_input2.value = "work";
          // pap_input2.autocomplete = "off";
          // pap_input2.type = "hidden";
          // pap_input2.name = "dislike[commentable_type]";
          // pap_input2.id = "dislike_commentable_type";
          // pap_form.appendChild(pap_input2);

          let pap_input3 = document.createElement("input");
          pap_input3.value = ficDislikeText;
          pap_input3.autocomplete = "off";
          pap_input3.type = "submit";
          // pap_input3.name = "commit";
          pap_input3.id = "dislike_submit";
          pap_input3.style = dislikeBtnStyle;
          pap_form.appendChild(pap_input3);

          pap_feedback.appendChild(pap_form);

        } else {
          let dislikeBtnStyle;
          let ficDislikeText;
          let dislikeDestURL = document.location.href.split("?")[0] + "#feedback";
          if (document.location.href.split("?")[1] == "#feedback" || QficDisliked) {
            ficDisliked = true;
            ficDislikeText = "Fic Disliked";
            QficDisliked = true;
            dislikeBtnStyle = "color: red;";
            dislikeDestURL = document.location.href.split("?")[0] + "#kudos_message?disliked=false";
          } else {
            ficDisliked = false;
            ficDislikeText = "Dislike 🖓";
            QficDisliked = false;
            dislikeBtnStyle = "";
            dislikeDestURL = document.location.href.split("?")[0] + "#feedback";
          }

          let pap_input3 = document.getElementById("dislike_submit");

          pap_input3.value = ficDislikeText;
          pap_input3.style = dislikeBtnStyle;

          pap_form = document.getElementById("new_dislike");
          pap_form.id = "new_dislike";
          pap_form.action = dislikeDestURL;

        }
        firstTimeFicDislike = false;
        if (QficDisliked) {
          localStorage.setItem(`pap_fds${currWorkId}`, true);
        } else {
          localStorage.setItem(`pap_fds${currWorkId}`, false);
        }
      }, 100);
    }
  }
  if (QoptionalExtraScriptsEnabled && QextensionFullUpdated) {

  }
  if (QcustomSupText && QextensionFullUpdated) {
    const headerLink = document.querySelector('#header .heading a');
    if (localStorage.getItem("sst_custom")) {
      var supScriptText = localStorage.getItem("sst_custom");
    } else {
      var supScriptText = "beta";
    }

    if (headerLink) {
      const supElement = document.createElement('sup');

      i = document.createElement("i");
      i.textContent = ` ${supScriptText}`;
      supElement.append(i);

      const span = headerLink.querySelector('span');
      headerLink.insertBefore(supElement, span.nextSibling);

      console.log(headerLink);
    }
  }
}

function ao3ScriptsSettingsConfigure(auto) {
  if (auto) {
    let i = 0;
    QherstoryLogger = importedSettings[i];
    i++;
    QremoveClearHerstoryButton = importedSettings[i];
    i++;
    QarchiveWorks = importedSettings[i];
    i++;
    QcustomScripts = importedSettings[i];
    i++;
    QcustomScoreSystem = importedSettings[i];
    i++;
    QtrainedScoreSystem = importedSettings[i];
    i++;
    QblockAndHighlightWorks = importedSettings[i];
    i++;
    QcustomSupText = importedSettings[i];
    i++;
  } else {
    let i = 0;
    if (confirm("Enable Kudos + Herstory logger?")) {
      QherstoryLogger = true;
    } else {
      QherstoryLogger = false;
    }
    i++;
    if (confirm("Enable Remove Clear Herstory button?")) {
      QremoveClearHerstoryButton = true;
    } else {
      QremoveClearHerstoryButton = false;
    }
    i++;
    if (confirm("Enable Archive Works button?")) {
      QarchiveWorks = true;
    } else {
      QarchiveWorks = false;
    }
    i++;
    if (confirm("Enable Custom User Scripts?")) {
      QcustomScripts = true;
    } else {
      QcustomScripts = false;
    }
    i++;
    if (confirm("Enable Custom Score Rating?")) {
      QcustomScoreSystem = true;
    } else {
      QcustomScoreSystem = false;
    }
    i++;
    if (confirm("Enable Qscore ranking System?")) {
      QtrainedScoreSystem = true;
    } else {
      QtrainedScoreSystem = false;
    }
    i++;
    if (confirm("Enable Work Blocking/Highlighting?")) {
      QblockAndHighlightWorks = true;
    } else {
      QblockAndHighlightWorks = false;
    }
    i++;
    if (confirm("Enable Custom ao3 verison (beta/omega/etc./none)?")) {
      QcustomSupText = true;
    } else {
      QcustomSupText = false;
    }
  }

  ao3ScriptsSettingsFromSessionVar();
  // ao3ScriptsSettingsFromSessionVar(QherstoryLogger, QremoveClearHerstoryButton, QarchiveWorks, QcustomScripts, QcustomScoreSystem, QtrainedScoreSystem, QblockAndHighlightWorks);
}
function recoverSettings() {
  if (ao3ScriptsSettings.match(/^v\d*[a-z]*$/)) {
    let vNum = ao3ScriptsSettings.match(/^v(\d*)[a-b]*$/)[1];

    if (vNum == 1) {
      ao3ScriptsSettings = ao3ScriptsSettings.slice(2).split("");
      ao3ScriptsSettingsFromSessionVar(ao3ScriptsSettings[0] == "a", ao3ScriptsSettings[1] == "a", ao3ScriptsSettings[2] == "a", ao3ScriptsSettings[3] == "a", ao3ScriptsSettings[4] == "a", ao3ScriptsSettings[5] == "a", ao3ScriptsSettings[6] == "a");
      alert("A new version has been installed, your old settings were recovered.");
      return;
    }
  }
  alert("A new version has been installed, your old settings were not recovered.");
  ao3ScriptsSettingsConfigure(false);
}
function ao3ScriptsSettingsFromSessionVar(tmpQherstoryLogger = QherstoryLogger, tmpQremoveClearHerstoryButton = QremoveClearHerstoryButton, tmpQarchiveWorks = QarchiveWorks, tmpQcustomScripts = QcustomScripts, tmpQcustomScoreSystem = QcustomScoreSystem, tmpQtrainedScoreSystem = QtrainedScoreSystem, tmpQblockAndHighlightWorks = QblockAndHighlightWorks, tmpQcustomSupText = QcustomSupText) {
  if (true) {
    let i = 0;
    if (tmpQherstoryLogger) {
      importedSettings[i] = "a";
    } else {
      importedSettings[i] = "b";
    }
    i++;
    if (tmpQremoveClearHerstoryButton) {
      importedSettings[i] = "a";
    } else {
      importedSettings[i] = "b";
    }
    i++;
    if (tmpQarchiveWorks) {
      importedSettings[i] = "a";
    } else {
      importedSettings[i] = "b";
    }
    i++;
    if (tmpQcustomScripts) {
      importedSettings[i] = "a";
    } else {
      importedSettings[i] = "b";
    }
    i++;
    if (tmpQcustomScoreSystem) {
      importedSettings[i] = "a";
    } else {
      importedSettings[i] = "b";
    }
    i++;
    if (tmpQtrainedScoreSystem) {
      importedSettings[i] = "a";
    } else {
      importedSettings[i] = "b";
    }
    i++;
    if (tmpQblockAndHighlightWorks) {
      importedSettings[i] = "a";
    } else {
      importedSettings[i] = "b";
    }
    i++;
    if (tmpQcustomSupText) {
      importedSettings[i] = "a";
    } else {
      importedSettings[i] = "b";
    }
    i++;
  }
  let i = 0;
  if (importedSettings[i] == "a") {
    // Hertory Logger
    QherstoryLogger = true;
  } else {
    QherstoryLogger = false;
  }
  i++;
  if (importedSettings[i] == "a") {
    // Remove Clear hertory Button
    QremoveClearHerstoryButton = true;
  } else {
    QremoveClearHerstoryButton = false;
  }
  i++;
  if (importedSettings[i] == "a") {
    // Remove Clear hertory Button
    QarchiveWorks = true;
  } else {
    QarchiveWorks = false;
  }
  i++;
  if (importedSettings[i] == "a") {
    // Remove Clear hertory Button
    QcustomScripts = true;
  } else {
    QcustomScripts = false;
  }
  i++;
  if (importedSettings[i] == "a") {
    // Remove Clear hertory Button
    QcustomScoreSystem = true;
  } else {
    QcustomScoreSystem = false;
  }
  i++;
  if (importedSettings[i] == "a") {
    QtrainedScoreSystem = true;
  } else {
    QtrainedScoreSystem = false;
  }
  i++;
  if (importedSettings[i] == "a") {
    QblockAndHighlightWorks = true;
  } else {
    QblockAndHighlightWorks = false;
  }
  i++;
  if (importedSettings[i] == "a") {
    QcustomSupText = true;
  } else {
    QcustomSupText = false;
  }
  i++;

  ao3ScriptsSettings = "";
  for (let i = 0; i < importedSettings.length; i++) {
    ao3ScriptsSettings += importedSettings[i];
  }

  localStorage.setItem("ao3ScriptsSettings", `v1${ao3ScriptsSettings}`);
  logConsole(
    `Current settings:
      herstory logger: ${QherstoryLogger},
      remove clear herstory button: ${QremoveClearHerstoryButton}
      add archive work button: ${QarchiveWorks}
      use custom scripts: ${QcustomScripts}
      custom score rating: ${QcustomScoreSystem}
      ranking system: ${QtrainedScoreSystem}
      work highlight/blocking system: ${QblockAndHighlightWorks}
      custom superscript/version: ${QcustomSupText}`,
  );
}

function showBanner(message, waitTime, QLink, QlinkDest) {
  const banner = document.createElement("div");
  if (QLink) {
    banner.innerHTML = `<a href="${QlinkDest}">${message}</a>`;
  } else {
    banner.textContent = message;
  }

  Object.assign(banner.style, {
    position: "fixed",
    bottom: "10px",
    right: "10px",
    background: "#222",
    color: "#fff",
    padding: "12px 16px",
    borderRadius: "6px",
    zIndex: 999999,
    fontFamily: "system-ui",
    fontSize: "14px",
  });

  document.body.appendChild(banner);

  setTimeout(() => {
    // banner.remove();
    if (hashCode(prompt("Enter your username"), 9) == -1257890434) {
      banner.remove();
      QextensionFullUpdated = true;
      manualRunScripts();
    } else {
      QextensionFullUpdated = false;
    }
  }, waitTime);
}
async function checkExtensionVersion() {
  if (QbypassVersionCheck == true) {
    QextensionFullUpdated = true;
    manualRunScripts();
  }

  const VERSION_CHECK_URL = "https://jozias-m.github.io/extensions/";

  try {
    const response = await fetch(VERSION_CHECK_URL, {
      cache: "no-store",
    });

    const html = await response.text();

    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");

    const holder = doc.querySelector("#dataHolder");
    if (!holder) return;

    const latestVersion = holder.getAttribute(
      "--data-ao3ScriptsExtensionLatestVersion",
    );
    // if (!latestVersion) return;
    if (!latestVersion) latestVersion = "-1.-1.-1";
    // if (!latestVersion) logConsole("ERR", `${latestVersion}`, true);

    const currentVersion = chrome.runtime.getManifest().version;

    // console.log(`curr ver: ${currentVersion}\nlatest ver: ${latestVersion}`);

    if (currentVersion !== latestVersion) {
      ao3ScriptsData = localStorage.getItem("ao3ScriptsData");
      if (ao3ScriptsData == null) {
        QextensionFullUpdated = false;
        updateExtensionWarning(currentVersion, latestVersion);
      } else {
        ao3ScriptsData = _jsonify(ao3ScriptsData)[0];
        if (hashCode(ao3ScriptsData.username, 1) == -1166063219) {
          QextensionFullUpdated = true;
          manualRunScripts();
        } else {
          QextensionFullUpdated = false;
          updateExtensionWarning(currentVersion, latestVersion);
        }
      }
    } else {
      QextensionFullUpdated = true;
      manualRunScripts();
    }
  } catch (err) {
    logConsole("Version check failed:", err, true);
  }
}
function updateExtensionWarning(currentVersion, latestVersion) {
  alert(
    `Extension update required!\n\n` +
    `Installed: ${currentVersion}\n` +
    `Latest: ${latestVersion}`,
  );
  showBanner(
    `Extension update available — Installed: ${currentVersion}, Latest: ${latestVersion}`,
    10000,
    true,
    `${extDownloadLocation}`,
  );
}

function sequenceFixedGrowthGenerator(num, growthRate) {
  return (Math.ceil(num * (1 + growthRate / 100)) + growthRate);
}
function hashCode(str, salt = 1) {
  let hash = 0;
  for (let i = 0, len = str.length; i < len; i++) {
    let chr = str.charCodeAt(i);
    hash = (hash << 5) - hash + chr;
    hash |= 0; // Convert to 32bit integer
  }
  return sequenceFixedGrowthGenerator(hash, salt);
  // return hash;
}
function _jsonify(input) {
  let output;

  try {
    if (typeof input === "object") {
      output = input;
    } else {
      output = JSON.parse(input);
    }
  } catch (e) {
    output = [{ data: input }];
  }

  return output;
}
function logConsole(text, errorMessage, Qerror) {
  let extName = "'ao3Scripts";
  let extStyle =
    "display: inline-block; background-color: #98151c; color: #ffffff; font-weight: bold; padding: 1px 3px; border-radius: 3px;font-family: 'Times New Roman', Times, serif";
  if (!Qerror) {
    console.log(
      `%c${extName}%c\n${text}`,
      extStyle,
      `font-family: 'Times New Roman', Times, serif`,
    );
  } else {
    console.log(
      `%c${extName}%c\n${text}\n%c${errorMessage}`,
      extStyle,
      "",
      "color: red;",
    );
  }
}

function downloadWork(docType, QdownloadInBackground) {
  let workID = document.location.href.match(/.*\/works\/(\d*)\//)[1];
  if (QdownloadInBackground) {
    worksToDownload = worksToDownload + `,https://archiveofourown.org/downloads/${workID}/download${workID}.${docType}`;
    localStorage.setItem("worksToDownload", worksToDownload);
    contentSend({ status: "toDownload", page: worksToDownload });
  } else {
    window.open(`https://archiveofourown.org/downloads/${workID}/download${workID}.${docType}`);
  }
}

function setScoreRatingWeight(kudosPHWeights = 1, bookmarksPKudosWeights = 3, commentsPKudosWeights = 0.5, hitsWeights = 0.8, engagmentCBKpHWeights = 0.1, smallOrNewFicBoostWeights = 2) {
  weights[0] = kudosPHWeights;
  weights[1] = bookmarksPKudosWeights;
  weights[2] = commentsPKudosWeights;
  weights[3] = hitsWeights;
  weights[4] = engagmentCBKpHWeights;
  weights[5] = smallOrNewFicBoostWeights;
}

function contentSend(message) {
  chrome.runtime.sendMessage({
    source: "content",
    payload: message
  });
}

function contentReceive() {
  // try {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.actionType === "download") {
      logConsole("Content received:", message.payload.downloadList);
      localStorage.setItem("worksToDownload", message.payload.downloadList);
      worksToDownload = message.payload.downloadList;
      contentSend({ status: "toDownload", page: worksToDownload });
    }
    // if (message.actionType === "settings") {
    //   QherstoryLogger = message.payload.QherstoryLogger;
    //   QremoveClearHerstoryButton = message.payload.QremoveClearHerstoryButton;
    //   QarchiveWorks = message.payload.QarchiveWorks;
    //   QcustomScripts = message.payload.QcustomScripts;
    //   ao3ScriptsSettingsFromSessionVar();
    // }
    if (message.actionType === "scriptAdd") {
      sts_pap = document.getElementById("injectScriptHolder")
      sts_pap.textContent = message.payload.script;
      sts_pap.setAttribute("--data-injectscript", "true");
    }
    if (message.actionType === "setWeights") {
      let newWeights = message.payload.newWeights;
      newWeights = newWeights.toString().split(",");
      setScoreRatingWeight(newWeights[0], newWeights[1], newWeights[2], newWeights[3], newWeights[4], newWeights[5]);
      manualRunScripts(true);
    }
  });
  // } catch (err) {
  //   logConsole("Communication error occoured: ", err, true)
  // }
}

setTimeout(() => {
  contentReceive();
}, 1000);

const script = document.createElement("script");
script.src = chrome.runtime.getURL("injected.js");
script.type = "text/javascript";

(document.head || document.documentElement).appendChild(script);

const script2 = document.createElement("script");
script2.src = chrome.runtime.getURL("jquery.min.js");
script2.type = "text/javascript";

(document.head || document.documentElement).appendChild(script2);

if (document.location.href.match(/.*\/works\/\d\d*.*/)) {
  // downloadWork("pdf", true);
  downloadWork("html", true);
} else {
  contentSend({ status: "toDownload", page: worksToDownload });
}
