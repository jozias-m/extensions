/*
Copyright 2009+, GM_config Contributors (https://github.com/sizzlemctwizzle/GM_config)

GM_config Collaborators/Contributors:
    Mike Medley <medleymind@gmail.com>
    Joe Simmons
    Izzy Soft
    Marti Martz
    Adam Thompson-Sharpe

GM_config is distributed under the terms of the GNU Lesser General Public License.

    GM_config is free software: you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

// ==UserScript==
// @exclude       *
// @author        Mike Medley <medleymind@gmail.com> (https://github.com/sizzlemctwizzle/GM_config)
// @icon          https://raw.githubusercontent.com/sizzlemctwizzle/GM_config/master/gm_config_icon_large.png

// ==UserLibrary==
// @name          GM_config
// @description   A lightweight, reusable, cross-browser graphical settings framework for inclusion in user scripts.
// @copyright     2009+, Mike Medley (https://github.com/sizzlemctwizzle)
// @license       LGPL-3.0-or-later; https://raw.githubusercontent.com/sizzlemctwizzle/GM_config/master/LICENSE

// @homepageURL   https://openuserjs.org/libs/sizzle/GM_config
// @homepageURL   https://github.com/sizzlemctwizzle/GM_config
// @supportURL    https://github.com/sizzlemctwizzle/GM_config/issues

// ==/UserScript==

// ==/UserLibrary==

/* jshint esversion: 8 */

let GM_config = (function (GM) {
  // This is the initializer function
  function GM_configInit(config, args) {
    // Initialize instance variables
    if (typeof config.fields == "undefined") {
      config.fields = {};
      config.onInit = config.onInit || function() {};
      config.onOpen = config.onOpen || function() {};
      config.onSave = config.onSave || function() {};
      config.onClose = config.onClose || function() {};
      config.onReset = config.onReset || function() {};
      config.isOpen = false;
      config.title = 'User Script Settings';
      config.css = {
        basic: [
          "#GM_config * { font-family: arial,tahoma,myriad pro,sans-serif; }",
          "#GM_config { background: #FFF; }",
          "#GM_config input[type='radio'] { margin-right: 8px; }",
          "#GM_config .indent40 { margin-left: 40%; }",
          "#GM_config .field_label { font-size: 12px; font-weight: bold; margin-right: 6px; }",
          "#GM_config .radio_label { font-size: 12px; }",
          "#GM_config .block { display: block; }",
          "#GM_config .saveclose_buttons { margin: 16px 10px 10px; padding: 2px 12px; }",
          "#GM_config .reset, #GM_config .reset a," +
            " #GM_config_buttons_holder { color: #000; text-align: right; }",
          "#GM_config .config_header { font-size: 20pt; margin: 0; }",
          "#GM_config .config_desc, #GM_config .section_desc, #GM_config .reset { font-size: 9pt; }",
          "#GM_config .center { text-align: center; }",
          "#GM_config .section_header_holder { margin-top: 8px; }",
          "#GM_config .config_var { margin: 0 0 4px; }",
          "#GM_config .section_header { background: #414141; border: 1px solid #000; color: #FFF;",
          " font-size: 13pt; margin: 0; }",
          "#GM_config .section_desc { background: #EFEFEF; border: 1px solid #CCC; color: #575757;" +
            " font-size: 9pt; margin: 0 0 6px; }"
          ].join('\n') + '\n',
        basicPrefix: "GM_config",
        stylish: ""
      };
    }
    config.frameStyle = [
      'bottom: auto; border: 1px solid #000; display: none; height: 75%;',
      'left: 0; margin: 0; max-height: 95%; max-width: 95%; opacity: 0;',
      'overflow: auto; padding: 0; position: fixed; right: auto; top: 0;',
      'width: 75%; z-index: 9999;'
	].join(' ');

    var settings = null;
    if (args.length == 1 &&
      typeof args[0].id == "string" &&
      typeof args[0].appendChild != "function") settings = args[0];
    else {
      // Provide backwards-compatibility with argument style intialization
      settings = {};

      // loop through GM_config.init() arguments
      for (let i = 0, l = args.length, arg; i < l; ++i) {
        arg = args[i];

        // An element to use as the config window
        if (typeof arg.appendChild == "function") {
          settings.frame = arg;
          continue;
        }

        switch (typeof arg) {
          case 'object':
            for (let j in arg) { // could be a callback functions or settings object
              if (typeof arg[j] != "function") { // we are in the settings object
                settings.fields = arg; // store settings object
                break; // leave the loop
              } // otherwise it must be a callback function
              if (!settings.events) settings.events = {};
              settings.events[j] = arg[j];
            }
            break;
          case 'function': // passing a bare function is set to open callback
            settings.events = {onOpen: arg};
            break;
          case 'string': // could be custom CSS or the title string
            if (/\w+\s*\{\s*\w+\s*:\s*\w+[\s|\S]*\}/.test(arg))
              settings.css = arg;
            else
              settings.title = arg;
            break;
        }
      }
    }

    /* Initialize everything using the new settings object */
    // Set the id
    if (settings.id) config.id = settings.id;
    else if (typeof config.id == "undefined") config.id = 'GM_config';

    // Set the title
    if (settings.title) config.title = settings.title;

    // Set the custom css
    if (settings.css) config.css.stylish = settings.css;

    // Set the frame
    if (settings.frame) config.frame = settings.frame;
	
    // Set the style attribute of the frame
    if (typeof settings.frameStyle === 'string') config.frameStyle = settings.frameStyle;

    // Set the event callbacks
    if (settings.events) {
      let events = settings.events;
      for (let e in events) {
        config["on" + e.charAt(0).toUpperCase() + e.slice(1)] = events[e];
      }
    }

    // If the id has changed we must modify the default style
    if (config.id != config.css.basicPrefix) {
      config.css.basic = config.css.basic.replace(
        new RegExp('#' + config.css.basicPrefix, 'gm'), '#' + config.id);
      config.css.basicPrefix = config.id;
    }

    // Create the fields
    config.isInit = false;
    if (settings.fields) {
      config.read(null, (stored) => { // read the stored settings
        let fields = settings.fields,
            customTypes = settings.types || {},
            configId = config.id;

        for (let id in fields) {
          let field = fields[id],
              fieldExists = false;

          if (config.fields[id]) {
            fieldExists = true;
          }

          // for each field definition create a field object
          if (field) {
            if (config.isOpen && fieldExists) {
                config.fields[id].remove();
            }

            config.fields[id] = new GM_configField(field, stored[id], id,
              customTypes[field.type], configId);

            // Add field to open frame
            if (config.isOpen) {
              config.fields[id].wrapper = config.fields[id].toNode();
              config.frameSection.appendChild(config.fields[id].wrapper);
            }
          } else if (!field && fieldExists) {
            // Remove field from open frame
            if (config.isOpen) {
              config.fields[id].remove();
            }

            delete config.fields[id];
          }
        }

        config.isInit = true;
        config.onInit.call(config);
      });
    } else {
      config.isInit = true;
      config.onInit.call(config);
    }
  }

  let construct = function () {
    // Parsing of input provided via frontends
    GM_configInit(this, arguments);
  };
  construct.prototype = {
    // Support re-initalization
    init: function() {
      GM_configInit(this, arguments);
    },

    // call GM_config.open() from your script to open the menu
    open: function () {
      // don't open before init is finished
      if (!this.isInit) {
        setTimeout(() => this.open(), 0);
        return;
      }
      // Die if the menu is already open on this page
      // You can have multiple instances but you can't open the same instance twice
      let match = document.getElementById(this.id);
      if (match && (match.tagName == "IFRAME" || match.childNodes.length > 0)) return;

      // Sometimes "this" gets overwritten so create an alias
      let config = this;

      // Function to build the mighty config window :)
      function buildConfigWin (body, head) {
        let create = config.create,
            fields = config.fields,
            configId = config.id,
            bodyWrapper = create('div', {id: configId + '_wrapper'});

        // Append the style which is our default style plus the user style
        head.appendChild(
          create('style', {
          type: 'text/css',
          textContent: config.css.basic + config.css.stylish
        }));

        // Add header and title
        bodyWrapper.appendChild(create('div', {
          id: configId + '_header',
          className: 'config_header block center'
        }, config.title));

        // Append elements
        let section = bodyWrapper,
            secNum = 0; // Section count

        // loop through fields
        for (let id in fields) {
          let field = fields[id],
              settings = field.settings;

          if (settings.section) { // the start of a new section
            section = bodyWrapper.appendChild(create('div', {
                className: 'section_header_holder',
                id: configId + '_section_' + secNum
              }));

            if (!Array.isArray(settings.section))
              settings.section = [settings.section];

            if (settings.section[0])
              section.appendChild(create('div', {
                className: 'section_header center',
                id: configId + '_section_header_' + secNum
              }, settings.section[0]));

            if (settings.section[1])
              section.appendChild(create('p', {
                className: 'section_desc center',
                id: configId + '_section_desc_' + secNum
              }, settings.section[1]));
            ++secNum;
          }
          
          if (secNum === 0) {
            section = bodyWrapper.appendChild(create('div', {
                className: 'section_header_holder',
                id: configId + '_section_' + (secNum++)
            }));
          }

          // Create field elements and append to current section
          section.appendChild((field.wrapper = field.toNode()));
        }
        
        config.frameSection = section;

        // Add save and close buttons
        bodyWrapper.appendChild(create('div',
          {id: configId + '_buttons_holder'},

          create('button', {
            id: configId + '_saveBtn',
            textContent: 'Save',
            title: 'Save settings',
            className: 'saveclose_buttons',
            onclick: function () { config.save(); }
          }),

          create('button', {
            id: configId + '_closeBtn',
            textContent: 'Close',
            title: 'Close window',
            className: 'saveclose_buttons',
            onclick: function () { config.close(); }
          }),

          create('div',
            {className: 'reset_holder block'},

            // Reset link
            create('a', {
              id: configId + '_resetLink',
              textContent: 'Reset to defaults',
              href: '#',
              title: 'Reset fields to default values',
              className: 'reset',
              onclick: function(e) { e.preventDefault(); config.reset(); }
            })
        )));

        body.appendChild(bodyWrapper); // Paint everything to window at once
        config.center(); // Show and center iframe
        window.addEventListener('resize', config.center, false); // Center frame on resize

        // Call the open() callback function
        config.onOpen(config.frame.contentDocument || config.frame.ownerDocument,
                      config.frame.contentWindow || window,
                      config.frame);

        // Close frame on window close
        window.addEventListener('beforeunload', function () {
            config.close();
        }, false);

        // Now that everything is loaded, make it visible
        config.frame.style.display = "block";
        config.isOpen = true;
      }

      // Either use the element passed to init() or create an iframe
      if (this.frame) {
        this.frame.id = this.id; // Allows for prefixing styles with the config id
        if (this.frameStyle) this.frame.setAttribute('style', this.frameStyle);
        buildConfigWin(this.frame, this.frame.ownerDocument.getElementsByTagName('head')[0]);
      } else {
        // Create frame
        this.frame = this.create('iframe', { id: this.id });
        if (this.frameStyle) this.frame.setAttribute('style', this.frameStyle);
        document.body.appendChild(this.frame);

        // In WebKit src can't be set until it is added to the page
        this.frame.src = '';
        // we wait for the iframe to load before we can modify it
        let that = this;
        this.frame.addEventListener('load', function(e) {
            let frame = config.frame;
            if (!frame.contentDocument) {
              that.log("GM_config failed to initialize default settings dialog node!");
            } else {
              let body = frame.contentDocument.getElementsByTagName('body')[0];
              body.id = config.id; // Allows for prefixing styles with the config id
              buildConfigWin(body, frame.contentDocument.getElementsByTagName('head')[0]);
            }
        }, false);
      }
    },

    save: function () {
      this.write(null, null, (vals) => this.onSave(vals));
    },

    close: function() {
      // If frame is an iframe then remove it
      if (this.frame && this.frame.contentDocument) {
        this.remove(this.frame);
        this.frame = null;
      } else if (this.frame) { // else wipe its content
        this.frame.innerHTML = "";
        this.frame.style.display = "none";
      }

      // Null out all the fields so we don't leak memory
      let fields = this.fields;
      for (let id in fields) {
        let field = fields[id];
        field.wrapper = null;
        field.node = null;
      }

      this.onClose(); //  Call the close() callback function
      this.isOpen = false;
    },

    set: function (name, val) {
      this.fields[name].value = val;

      if (this.fields[name].node) {
        this.fields[name].reload();
      }
    },

    get: function (name, getLive) {
      /* Migration warning */
      if (!this.isInit) {
        this.log('GM_config: get called before init, see https://github.com/sizzlemctwizzle/GM_config/issues/113');
      }

      let field = this.fields[name],
          fieldVal = null;

      if (getLive && field.node) {
        fieldVal = field.toValue();
      }

      return fieldVal != null ? fieldVal : field.value;
    },

    write: function (store, obj, cb) {
      let forgotten = null,
          values = null;
      if (!obj) {
        let fields = this.fields;

        values = {};
        forgotten = {};

        for (let id in fields) {
          let field = fields[id];
          let value = field.toValue();

          if (field.save) {
            if (value != null) {
              values[id] = value;
              field.value = value;
            } else
              values[id] = field.value;
          } else
            forgotten[id] = value != null ? value : field.value;
        }
      }

      (async () => {
        try {
          let val = this.stringify(obj || values);
          await this.setValue(store || this.id, val);
        } catch(e) {
          this.log("GM_config failed to save settings!");
        }
        cb(forgotten);
      })();
    },

    read: function (store, cb) {
      (async () => {
        let val = await this.getValue(store || this.id, '{}');
        try {
          let rval = this.parser(val);
          cb(rval);
        } catch(e) {
          this.log("GM_config failed to read saved settings!");
          cb({});
        }
      })();
    },

    reset: function () {
      let fields = this.fields;

      // Reset all the fields
      for (let id in fields) { fields[id].reset(); }

      this.onReset(); // Call the reset() callback function
    },

    create: function () {
      let A = null,
          B = null;
      switch(arguments.length) {
        case 1:
          A = document.createTextNode(arguments[0]);
          break;
        default:
          A = document.createElement(arguments[0]);
          B = arguments[1];
          for (let b in B) {
            if (b.indexOf("on") == 0)
              A.addEventListener(b.substring(2), B[b], false);
            else if (",style,accesskey,id,name,src,href,which,for".indexOf("," +
                     b.toLowerCase()) != -1)
              A.setAttribute(b, B[b]);
            else
              A[b] = B[b];
          }
          if (typeof arguments[2] == "string")
            A.innerHTML = arguments[2];
          else
            for (let i = 2, len = arguments.length; i < len; ++i)
              A.appendChild(arguments[i]);
      }
      return A;
    },

    center: function () {
      let node = this.frame;
      if (!node) return;
      let style = node.style,
          beforeOpacity = style.opacity;
      if (style.display == 'none') style.opacity = '0';
      style.display = '';
      style.top = Math.floor((window.innerHeight / 2) - (node.offsetHeight / 2)) + 'px';
      style.left = Math.floor((window.innerWidth / 2) - (node.offsetWidth / 2)) + 'px';
      style.opacity = '1';
    },

    remove: function (el) {
      if (el && el.parentNode) el.parentNode.removeChild(el);
    }
  };

  construct.prototype.name = 'GM_config';
  construct.prototype.constructor = construct;
  let isGM4 = typeof GM.getValue !== 'undefined' &&
    typeof GM.setValue !== 'undefined';
  let isGM = isGM4 || (typeof GM_getValue !== 'undefined' &&
    typeof GM_getValue('a', 'b') !== 'undefined');
  construct.prototype.isGM = isGM;

  if (!isGM4) {
    let promisify = (old) => (...args) => {
      return new Promise((resolve, reject) => {
        try {
          resolve(old.apply(this, args));
        } catch (e) {
          reject(e);
        }
      });
    };

    let getValue = isGM ? GM_getValue
      : (name, def) => {
        let s = localStorage.getItem(name);
        return s !== null ? s : def;
      };
    let setValue = isGM ? GM_setValue
      : (name, value) => localStorage.setItem(name, value);
    let log = typeof GM_log !== 'undefined' ? GM_log : console.log;

    GM.getValue = promisify(getValue);
    GM.setValue = promisify(setValue);
    GM.log = promisify(log);
  }

  construct.prototype.stringify = JSON.stringify;
  construct.prototype.parser = JSON.parse;
  construct.prototype.getValue = GM.getValue;
  construct.prototype.setValue = GM.setValue;
  construct.prototype.log = GM.log || console.log;

  // Passthrough frontends for new and old usage
  let config = function () {
    return new (config.bind.apply(construct,
      [null].concat(Array.from(arguments))));
  };
  config.prototype.constructor = config;

  // Support old method of initalizing
  config.init = function () {
    GM_config = config.apply(this, arguments);
    GM_config.init = function() {
      GM_configInit(this, arguments);
    };
  };

  // Reusable functions and properties
  // Usable via GM_config.*
  config.create = construct.prototype.create;
  config.isGM = construct.prototype.isGM;
  config.setValue = construct.prototype.setValue;
  config.getValue = construct.prototype.getValue;
  config.stringify = construct.prototype.stringify;
  config.parser = construct.prototype.parser;
  config.log = construct.prototype.log;
  config.remove = construct.prototype.remove;
  config.read = construct.prototype.read.bind(config);
  config.write = construct.prototype.write.bind(config);

  return config;
}(typeof GM === 'object' ? GM : Object.create(null)));
let GM_configStruct = GM_config;

function GM_configField(settings, stored, id, customType, configId) {
  // Store the field's settings
  this.settings = settings;
  this.id = id;
  this.configId = configId;
  this.node = null;
  this.wrapper = null;
  this.save = typeof settings.save == "undefined" ? true : settings.save;

  // Buttons are static and don't have a stored value
  if (settings.type == "button") this.save = false;

  // if a default value wasn't passed through init() then
  //   if the type is custom use its default value
  //   else use default value for type
  // else use the default value passed through init()
  this['default'] = typeof settings['default'] == "undefined" ?
    customType ?
      customType['default']
      : this.defaultValue(settings.type, settings.options)
    : settings['default'];

  // Store the field's value
  this.value = typeof stored == "undefined" ? this['default'] : stored;

  // Setup methods for a custom type
  if (customType) {
    this.toNode = customType.toNode;
    this.toValue = customType.toValue;
    this.reset = customType.reset;
  }
}

GM_configField.prototype = {
  create: GM_config.create,

  defaultValue: function(type, options) {
    let value;

    if (type.indexOf('unsigned ') == 0)
      type = type.substring(9);

    switch (type) {
      case 'radio': case 'select':
        value = options[0];
        break;
      case 'checkbox':
        value = false;
        break;
      case 'int': case 'integer':
      case 'float': case 'number':
        value = 0;
        break;
      default:
        value = '';
    }

    return value;
  },

  toNode: function() {
    let field = this.settings,
        value = this.value,
        options = field.options,
        type = field.type,
        id = this.id,
        configId = this.configId,
        labelPos = field.labelPos,
        create = this.create;

    function addLabel(pos, labelEl, parentNode, beforeEl) {
      if (!beforeEl) beforeEl = parentNode.firstChild;
      switch (pos) {
        case 'right': case 'below':
          if (pos == 'below')
            parentNode.appendChild(create('br', {}));
          parentNode.appendChild(labelEl);
          break;
        default:
          if (pos == 'above')
            parentNode.insertBefore(create('br', {}), beforeEl);
          parentNode.insertBefore(labelEl, beforeEl);
      }
    }

    let retNode = create('div', { className: 'config_var',
          id: configId + '_' + id + '_var',
          title: field.title || '' }),
        firstProp;

    // Retrieve the first prop
    for (let i in field) { firstProp = i; break; }

    let label = field.label && type != "button" ?
      create('label', {
        id: configId + '_' + id + '_field_label',
        for: configId + '_field_' + id,
        className: 'field_label'
      }, field.label) : null;

    let wrap = null;
    switch (type) {
      case 'textarea':
        retNode.appendChild((this.node = create('textarea', {
          innerHTML: value,
          id: configId + '_field_' + id,
          className: 'block',
          cols: (field.cols ? field.cols : 20),
          rows: (field.rows ? field.rows : 2)
        })));
        break;
      case 'radio':
        wrap = create('div', {
          id: configId + '_field_' + id
        });
        this.node = wrap;

        for (let i = 0, len = options.length; i < len; ++i) {
          let radLabel = create('label', {
            className: 'radio_label'
          }, options[i]);

          let rad = wrap.appendChild(create('input', {
            value: options[i],
            type: 'radio',
            name: id,
            checked: options[i] == value
          }));

          let radLabelPos = labelPos &&
            (labelPos == 'left' || labelPos == 'right') ?
            labelPos : firstProp == 'options' ? 'left' : 'right';

          addLabel(radLabelPos, radLabel, wrap, rad);
        }

        retNode.appendChild(wrap);
        break;
      case 'select':
        wrap = create('select', {
          id: configId + '_field_' + id
        });
        this.node = wrap;

        for (let i = 0, len = options.length; i < len; ++i) {
          let option = options[i];
          wrap.appendChild(create('option', {
            value: option,
            selected: option == value
          }, option));
        }

        retNode.appendChild(wrap);
        break;
      default: // fields using input elements
        let props = {
          id: configId + '_field_' + id,
          type: type,
          value: type == 'button' ? field.label : value
        };

        switch (type) {
          case 'checkbox':
            props.checked = value;
            break;
          case 'button':
            props.size = field.size ? field.size : 25;
            if (field.script) field.click = field.script;
            if (field.click) props.onclick = field.click;
            break;
          case 'hidden':
            break;
          default:
            // type = text, int, or float
            props.type = 'text';
            props.size = field.size ? field.size : 25;
        }

        retNode.appendChild((this.node = create('input', props)));
    }

    if (label) {
      // If the label is passed first, insert it before the field
      // else insert it after
      if (!labelPos)
        labelPos = firstProp == "label" || type == "radio" ?
          "left" : "right";

      addLabel(labelPos, label, retNode);
    }

    return retNode;
  },

  toValue: function() {
    let node = this.node,
        field = this.settings,
        type = field.type,
        unsigned = false,
        rval = null;

    if (!node) return rval;

    if (type.indexOf('unsigned ') == 0) {
      type = type.substring(9);
      unsigned = true;
    }

    switch (type) {
      case 'checkbox':
        rval = node.checked;
        break;
      case 'select':
        rval = node[node.selectedIndex].value;
        break;
      case 'radio':
        let radios = node.getElementsByTagName('input');
        for (let i = 0, len = radios.length; i < len; ++i) {
          if (radios[i].checked)
            rval = radios[i].value;
        }
        break;
      case 'button':
        break;
      case 'int': case 'integer':
      case 'float': case 'number':
        let num = Number(node.value);
        let warn = 'Field labeled "' + field.label + '" expects a' +
          (unsigned ? ' positive ' : 'n ') + 'integer value';

        if (isNaN(num) || (type.substr(0, 3) == 'int' &&
            Math.ceil(num) != Math.floor(num)) ||
            (unsigned && num < 0)) {
          alert(warn + '.');
          return null;
        }

        if (!this._checkNumberRange(num, warn))
          return null;
        rval = num;
        break;
      default:
        rval = node.value;
        break;
    }

    return rval; // value read successfully
  },

  reset: function() {
    let node = this.node,
        field = this.settings,
        type = field.type;

    if (!node) return;

    switch (type) {
      case 'checkbox':
        node.checked = this['default'];
        break;
      case 'select':
        for (let i = 0, len = node.options.length; i < len; ++i) {
          if (node.options[i].textContent == this['default'])
            node.selectedIndex = i;
        }
        break;
      case 'radio':
        let radios = node.getElementsByTagName('input');
        for (let i = 0, len = radios.length; i < len; ++i) {
          if (radios[i].value == this['default'])
            radios[i].checked = true;
        }
        break;
      case 'button' :
        break;
      default:
        node.value = this['default'];
        break;
      }
  },

  remove: function() {
    GM_config.remove(this.wrapper);
    this.wrapper = null;
    this.node = null;
  },

  reload: function() {
    let wrapper = this.wrapper;
    if (wrapper) {
      let fieldParent = wrapper.parentNode;
      let newWrapper = this.toNode();
      fieldParent.insertBefore(newWrapper, wrapper);
      GM_config.remove(this.wrapper);
      this.wrapper = newWrapper;
    }
  },

  _checkNumberRange: function(num, warn) {
    let field = this.settings;
    if (typeof field.min == "number" && num < field.min) {
      alert(warn + ' greater than or equal to ' + field.min + '.');
      return null;
    }

    if (typeof field.max == "number" && num > field.max) {
      alert(warn + ' less than or equal to ' + field.max + '.');
      return null;
    }
    return true;
  }
};





/**/







/*! jQuery v1.9.1 | (c) 2005, 2012 jQuery Foundation, Inc. | jquery.org/license
//@ sourceMappingURL=jquery.min.map
*/(function(e,t){var n,r,i=typeof t,o=e.document,a=e.location,s=e.jQuery,u=e.$,l={},c=[],p="1.9.1",f=c.concat,d=c.push,h=c.slice,g=c.indexOf,m=l.toString,y=l.hasOwnProperty,v=p.trim,b=function(e,t){return new b.fn.init(e,t,r)},x=/[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,w=/\S+/g,T=/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,N=/^(?:(<[\w\W]+>)[^>]*|#([\w-]*))$/,C=/^<(\w+)\s*\/?>(?:<\/\1>|)$/,k=/^[\],:{}\s]*$/,E=/(?:^|:|,)(?:\s*\[)+/g,S=/\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g,A=/"[^"\\\r\n]*"|true|false|null|-?(?:\d+\.|)\d+(?:[eE][+-]?\d+|)/g,j=/^-ms-/,D=/-([\da-z])/gi,L=function(e,t){return t.toUpperCase()},H=function(e){(o.addEventListener||"load"===e.type||"complete"===o.readyState)&&(q(),b.ready())},q=function(){o.addEventListener?(o.removeEventListener("DOMContentLoaded",H,!1),e.removeEventListener("load",H,!1)):(o.detachEvent("onreadystatechange",H),e.detachEvent("onload",H))};b.fn=b.prototype={jquery:p,constructor:b,init:function(e,n,r){var i,a;if(!e)return this;if("string"==typeof e){if(i="<"===e.charAt(0)&&">"===e.charAt(e.length-1)&&e.length>=3?[null,e,null]:N.exec(e),!i||!i[1]&&n)return!n||n.jquery?(n||r).find(e):this.constructor(n).find(e);if(i[1]){if(n=n instanceof b?n[0]:n,b.merge(this,b.parseHTML(i[1],n&&n.nodeType?n.ownerDocument||n:o,!0)),C.test(i[1])&&b.isPlainObject(n))for(i in n)b.isFunction(this[i])?this[i](n[i]):this.attr(i,n[i]);return this}if(a=o.getElementById(i[2]),a&&a.parentNode){if(a.id!==i[2])return r.find(e);this.length=1,this[0]=a}return this.context=o,this.selector=e,this}return e.nodeType?(this.context=this[0]=e,this.length=1,this):b.isFunction(e)?r.ready(e):(e.selector!==t&&(this.selector=e.selector,this.context=e.context),b.makeArray(e,this))},selector:"",length:0,size:function(){return this.length},toArray:function(){return h.call(this)},get:function(e){return null==e?this.toArray():0>e?this[this.length+e]:this[e]},pushStack:function(e){var t=b.merge(this.constructor(),e);return t.prevObject=this,t.context=this.context,t},each:function(e,t){return b.each(this,e,t)},ready:function(e){return b.ready.promise().done(e),this},slice:function(){return this.pushStack(h.apply(this,arguments))},first:function(){return this.eq(0)},last:function(){return this.eq(-1)},eq:function(e){var t=this.length,n=+e+(0>e?t:0);return this.pushStack(n>=0&&t>n?[this[n]]:[])},map:function(e){return this.pushStack(b.map(this,function(t,n){return e.call(t,n,t)}))},end:function(){return this.prevObject||this.constructor(null)},push:d,sort:[].sort,splice:[].splice},b.fn.init.prototype=b.fn,b.extend=b.fn.extend=function(){var e,n,r,i,o,a,s=arguments[0]||{},u=1,l=arguments.length,c=!1;for("boolean"==typeof s&&(c=s,s=arguments[1]||{},u=2),"object"==typeof s||b.isFunction(s)||(s={}),l===u&&(s=this,--u);l>u;u++)if(null!=(o=arguments[u]))for(i in o)e=s[i],r=o[i],s!==r&&(c&&r&&(b.isPlainObject(r)||(n=b.isArray(r)))?(n?(n=!1,a=e&&b.isArray(e)?e:[]):a=e&&b.isPlainObject(e)?e:{},s[i]=b.extend(c,a,r)):r!==t&&(s[i]=r));return s},b.extend({noConflict:function(t){return e.$===b&&(e.$=u),t&&e.jQuery===b&&(e.jQuery=s),b},isReady:!1,readyWait:1,holdReady:function(e){e?b.readyWait++:b.ready(!0)},ready:function(e){if(e===!0?!--b.readyWait:!b.isReady){if(!o.body)return setTimeout(b.ready);b.isReady=!0,e!==!0&&--b.readyWait>0||(n.resolveWith(o,[b]),b.fn.trigger&&b(o).trigger("ready").off("ready"))}},isFunction:function(e){return"function"===b.type(e)},isArray:Array.isArray||function(e){return"array"===b.type(e)},isWindow:function(e){return null!=e&&e==e.window},isNumeric:function(e){return!isNaN(parseFloat(e))&&isFinite(e)},type:function(e){return null==e?e+"":"object"==typeof e||"function"==typeof e?l[m.call(e)]||"object":typeof e},isPlainObject:function(e){if(!e||"object"!==b.type(e)||e.nodeType||b.isWindow(e))return!1;try{if(e.constructor&&!y.call(e,"constructor")&&!y.call(e.constructor.prototype,"isPrototypeOf"))return!1}catch(n){return!1}var r;for(r in e);return r===t||y.call(e,r)},isEmptyObject:function(e){var t;for(t in e)return!1;return!0},error:function(e){throw Error(e)},parseHTML:function(e,t,n){if(!e||"string"!=typeof e)return null;"boolean"==typeof t&&(n=t,t=!1),t=t||o;var r=C.exec(e),i=!n&&[];return r?[t.createElement(r[1])]:(r=b.buildFragment([e],t,i),i&&b(i).remove(),b.merge([],r.childNodes))},parseJSON:function(n){return e.JSON&&e.JSON.parse?e.JSON.parse(n):null===n?n:"string"==typeof n&&(n=b.trim(n),n&&k.test(n.replace(S,"@").replace(A,"]").replace(E,"")))?Function("return "+n)():(b.error("Invalid JSON: "+n),t)},parseXML:function(n){var r,i;if(!n||"string"!=typeof n)return null;try{e.DOMParser?(i=new DOMParser,r=i.parseFromString(n,"text/xml")):(r=new ActiveXObject("Microsoft.XMLDOM"),r.async="false",r.loadXML(n))}catch(o){r=t}return r&&r.documentElement&&!r.getElementsByTagName("parsererror").length||b.error("Invalid XML: "+n),r},noop:function(){},globalEval:function(t){t&&b.trim(t)&&(e.execScript||function(t){e.eval.call(e,t)})(t)},camelCase:function(e){return e.replace(j,"ms-").replace(D,L)},nodeName:function(e,t){return e.nodeName&&e.nodeName.toLowerCase()===t.toLowerCase()},each:function(e,t,n){var r,i=0,o=e.length,a=M(e);if(n){if(a){for(;o>i;i++)if(r=t.apply(e[i],n),r===!1)break}else for(i in e)if(r=t.apply(e[i],n),r===!1)break}else if(a){for(;o>i;i++)if(r=t.call(e[i],i,e[i]),r===!1)break}else for(i in e)if(r=t.call(e[i],i,e[i]),r===!1)break;return e},trim:v&&!v.call("\ufeff\u00a0")?function(e){return null==e?"":v.call(e)}:function(e){return null==e?"":(e+"").replace(T,"")},makeArray:function(e,t){var n=t||[];return null!=e&&(M(Object(e))?b.merge(n,"string"==typeof e?[e]:e):d.call(n,e)),n},inArray:function(e,t,n){var r;if(t){if(g)return g.call(t,e,n);for(r=t.length,n=n?0>n?Math.max(0,r+n):n:0;r>n;n++)if(n in t&&t[n]===e)return n}return-1},merge:function(e,n){var r=n.length,i=e.length,o=0;if("number"==typeof r)for(;r>o;o++)e[i++]=n[o];else while(n[o]!==t)e[i++]=n[o++];return e.length=i,e},grep:function(e,t,n){var r,i=[],o=0,a=e.length;for(n=!!n;a>o;o++)r=!!t(e[o],o),n!==r&&i.push(e[o]);return i},map:function(e,t,n){var r,i=0,o=e.length,a=M(e),s=[];if(a)for(;o>i;i++)r=t(e[i],i,n),null!=r&&(s[s.length]=r);else for(i in e)r=t(e[i],i,n),null!=r&&(s[s.length]=r);return f.apply([],s)},guid:1,proxy:function(e,n){var r,i,o;return"string"==typeof n&&(o=e[n],n=e,e=o),b.isFunction(e)?(r=h.call(arguments,2),i=function(){return e.apply(n||this,r.concat(h.call(arguments)))},i.guid=e.guid=e.guid||b.guid++,i):t},access:function(e,n,r,i,o,a,s){var u=0,l=e.length,c=null==r;if("object"===b.type(r)){o=!0;for(u in r)b.access(e,n,u,r[u],!0,a,s)}else if(i!==t&&(o=!0,b.isFunction(i)||(s=!0),c&&(s?(n.call(e,i),n=null):(c=n,n=function(e,t,n){return c.call(b(e),n)})),n))for(;l>u;u++)n(e[u],r,s?i:i.call(e[u],u,n(e[u],r)));return o?e:c?n.call(e):l?n(e[0],r):a},now:function(){return(new Date).getTime()}}),b.ready.promise=function(t){if(!n)if(n=b.Deferred(),"complete"===o.readyState)setTimeout(b.ready);else if(o.addEventListener)o.addEventListener("DOMContentLoaded",H,!1),e.addEventListener("load",H,!1);else{o.attachEvent("onreadystatechange",H),e.attachEvent("onload",H);var r=!1;try{r=null==e.frameElement&&o.documentElement}catch(i){}r&&r.doScroll&&function a(){if(!b.isReady){try{r.doScroll("left")}catch(e){return setTimeout(a,50)}q(),b.ready()}}()}return n.promise(t)},b.each("Boolean Number String Function Array Date RegExp Object Error".split(" "),function(e,t){l["[object "+t+"]"]=t.toLowerCase()});function M(e){var t=e.length,n=b.type(e);return b.isWindow(e)?!1:1===e.nodeType&&t?!0:"array"===n||"function"!==n&&(0===t||"number"==typeof t&&t>0&&t-1 in e)}r=b(o);var _={};function F(e){var t=_[e]={};return b.each(e.match(w)||[],function(e,n){t[n]=!0}),t}b.Callbacks=function(e){e="string"==typeof e?_[e]||F(e):b.extend({},e);var n,r,i,o,a,s,u=[],l=!e.once&&[],c=function(t){for(r=e.memory&&t,i=!0,a=s||0,s=0,o=u.length,n=!0;u&&o>a;a++)if(u[a].apply(t[0],t[1])===!1&&e.stopOnFalse){r=!1;break}n=!1,u&&(l?l.length&&c(l.shift()):r?u=[]:p.disable())},p={add:function(){if(u){var t=u.length;(function i(t){b.each(t,function(t,n){var r=b.type(n);"function"===r?e.unique&&p.has(n)||u.push(n):n&&n.length&&"string"!==r&&i(n)})})(arguments),n?o=u.length:r&&(s=t,c(r))}return this},remove:function(){return u&&b.each(arguments,function(e,t){var r;while((r=b.inArray(t,u,r))>-1)u.splice(r,1),n&&(o>=r&&o--,a>=r&&a--)}),this},has:function(e){return e?b.inArray(e,u)>-1:!(!u||!u.length)},empty:function(){return u=[],this},disable:function(){return u=l=r=t,this},disabled:function(){return!u},lock:function(){return l=t,r||p.disable(),this},locked:function(){return!l},fireWith:function(e,t){return t=t||[],t=[e,t.slice?t.slice():t],!u||i&&!l||(n?l.push(t):c(t)),this},fire:function(){return p.fireWith(this,arguments),this},fired:function(){return!!i}};return p},b.extend({Deferred:function(e){var t=[["resolve","done",b.Callbacks("once memory"),"resolved"],["reject","fail",b.Callbacks("once memory"),"rejected"],["notify","progress",b.Callbacks("memory")]],n="pending",r={state:function(){return n},always:function(){return i.done(arguments).fail(arguments),this},then:function(){var e=arguments;return b.Deferred(function(n){b.each(t,function(t,o){var a=o[0],s=b.isFunction(e[t])&&e[t];i[o[1]](function(){var e=s&&s.apply(this,arguments);e&&b.isFunction(e.promise)?e.promise().done(n.resolve).fail(n.reject).progress(n.notify):n[a+"With"](this===r?n.promise():this,s?[e]:arguments)})}),e=null}).promise()},promise:function(e){return null!=e?b.extend(e,r):r}},i={};return r.pipe=r.then,b.each(t,function(e,o){var a=o[2],s=o[3];r[o[1]]=a.add,s&&a.add(function(){n=s},t[1^e][2].disable,t[2][2].lock),i[o[0]]=function(){return i[o[0]+"With"](this===i?r:this,arguments),this},i[o[0]+"With"]=a.fireWith}),r.promise(i),e&&e.call(i,i),i},when:function(e){var t=0,n=h.call(arguments),r=n.length,i=1!==r||e&&b.isFunction(e.promise)?r:0,o=1===i?e:b.Deferred(),a=function(e,t,n){return function(r){t[e]=this,n[e]=arguments.length>1?h.call(arguments):r,n===s?o.notifyWith(t,n):--i||o.resolveWith(t,n)}},s,u,l;if(r>1)for(s=Array(r),u=Array(r),l=Array(r);r>t;t++)n[t]&&b.isFunction(n[t].promise)?n[t].promise().done(a(t,l,n)).fail(o.reject).progress(a(t,u,s)):--i;return i||o.resolveWith(l,n),o.promise()}}),b.support=function(){var t,n,r,a,s,u,l,c,p,f,d=o.createElement("div");if(d.setAttribute("className","t"),d.innerHTML="  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",n=d.getElementsByTagName("*"),r=d.getElementsByTagName("a")[0],!n||!r||!n.length)return{};s=o.createElement("select"),l=s.appendChild(o.createElement("option")),a=d.getElementsByTagName("input")[0],r.style.cssText="top:1px;float:left;opacity:.5",t={getSetAttribute:"t"!==d.className,leadingWhitespace:3===d.firstChild.nodeType,tbody:!d.getElementsByTagName("tbody").length,htmlSerialize:!!d.getElementsByTagName("link").length,style:/top/.test(r.getAttribute("style")),hrefNormalized:"/a"===r.getAttribute("href"),opacity:/^0.5/.test(r.style.opacity),cssFloat:!!r.style.cssFloat,checkOn:!!a.value,optSelected:l.selected,enctype:!!o.createElement("form").enctype,html5Clone:"<:nav></:nav>"!==o.createElement("nav").cloneNode(!0).outerHTML,boxModel:"CSS1Compat"===o.compatMode,deleteExpando:!0,noCloneEvent:!0,inlineBlockNeedsLayout:!1,shrinkWrapBlocks:!1,reliableMarginRight:!0,boxSizingReliable:!0,pixelPosition:!1},a.checked=!0,t.noCloneChecked=a.cloneNode(!0).checked,s.disabled=!0,t.optDisabled=!l.disabled;try{delete d.test}catch(h){t.deleteExpando=!1}a=o.createElement("input"),a.setAttribute("value",""),t.input=""===a.getAttribute("value"),a.value="t",a.setAttribute("type","radio"),t.radioValue="t"===a.value,a.setAttribute("checked","t"),a.setAttribute("name","t"),u=o.createDocumentFragment(),u.appendChild(a),t.appendChecked=a.checked,t.checkClone=u.cloneNode(!0).cloneNode(!0).lastChild.checked,d.attachEvent&&(d.attachEvent("onclick",function(){t.noCloneEvent=!1}),d.cloneNode(!0).click());for(f in{submit:!0,change:!0,focusin:!0})d.setAttribute(c="on"+f,"t"),t[f+"Bubbles"]=c in e||d.attributes[c].expando===!1;return d.style.backgroundClip="content-box",d.cloneNode(!0).style.backgroundClip="",t.clearCloneStyle="content-box"===d.style.backgroundClip,b(function(){var n,r,a,s="padding:0;margin:0;border:0;display:block;box-sizing:content-box;-moz-box-sizing:content-box;-webkit-box-sizing:content-box;",u=o.getElementsByTagName("body")[0];u&&(n=o.createElement("div"),n.style.cssText="border:0;width:0;height:0;position:absolute;top:0;left:-9999px;margin-top:1px",u.appendChild(n).appendChild(d),d.innerHTML="<table><tr><td></td><td>t</td></tr></table>",a=d.getElementsByTagName("td"),a[0].style.cssText="padding:0;margin:0;border:0;display:none",p=0===a[0].offsetHeight,a[0].style.display="",a[1].style.display="none",t.reliableHiddenOffsets=p&&0===a[0].offsetHeight,d.innerHTML="",d.style.cssText="box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;position:absolute;top:1%;",t.boxSizing=4===d.offsetWidth,t.doesNotIncludeMarginInBodyOffset=1!==u.offsetTop,e.getComputedStyle&&(t.pixelPosition="1%"!==(e.getComputedStyle(d,null)||{}).top,t.boxSizingReliable="4px"===(e.getComputedStyle(d,null)||{width:"4px"}).width,r=d.appendChild(o.createElement("div")),r.style.cssText=d.style.cssText=s,r.style.marginRight=r.style.width="0",d.style.width="1px",t.reliableMarginRight=!parseFloat((e.getComputedStyle(r,null)||{}).marginRight)),typeof d.style.zoom!==i&&(d.innerHTML="",d.style.cssText=s+"width:1px;padding:1px;display:inline;zoom:1",t.inlineBlockNeedsLayout=3===d.offsetWidth,d.style.display="block",d.innerHTML="<div></div>",d.firstChild.style.width="5px",t.shrinkWrapBlocks=3!==d.offsetWidth,t.inlineBlockNeedsLayout&&(u.style.zoom=1)),u.removeChild(n),n=d=a=r=null)}),n=s=u=l=r=a=null,t}();var O=/(?:\{[\s\S]*\}|\[[\s\S]*\])$/,B=/([A-Z])/g;function P(e,n,r,i){if(b.acceptData(e)){var o,a,s=b.expando,u="string"==typeof n,l=e.nodeType,p=l?b.cache:e,f=l?e[s]:e[s]&&s;if(f&&p[f]&&(i||p[f].data)||!u||r!==t)return f||(l?e[s]=f=c.pop()||b.guid++:f=s),p[f]||(p[f]={},l||(p[f].toJSON=b.noop)),("object"==typeof n||"function"==typeof n)&&(i?p[f]=b.extend(p[f],n):p[f].data=b.extend(p[f].data,n)),o=p[f],i||(o.data||(o.data={}),o=o.data),r!==t&&(o[b.camelCase(n)]=r),u?(a=o[n],null==a&&(a=o[b.camelCase(n)])):a=o,a}}function R(e,t,n){if(b.acceptData(e)){var r,i,o,a=e.nodeType,s=a?b.cache:e,u=a?e[b.expando]:b.expando;if(s[u]){if(t&&(o=n?s[u]:s[u].data)){b.isArray(t)?t=t.concat(b.map(t,b.camelCase)):t in o?t=[t]:(t=b.camelCase(t),t=t in o?[t]:t.split(" "));for(r=0,i=t.length;i>r;r++)delete o[t[r]];if(!(n?$:b.isEmptyObject)(o))return}(n||(delete s[u].data,$(s[u])))&&(a?b.cleanData([e],!0):b.support.deleteExpando||s!=s.window?delete s[u]:s[u]=null)}}}b.extend({cache:{},expando:"jQuery"+(p+Math.random()).replace(/\D/g,""),noData:{embed:!0,object:"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000",applet:!0},hasData:function(e){return e=e.nodeType?b.cache[e[b.expando]]:e[b.expando],!!e&&!$(e)},data:function(e,t,n){return P(e,t,n)},removeData:function(e,t){return R(e,t)},_data:function(e,t,n){return P(e,t,n,!0)},_removeData:function(e,t){return R(e,t,!0)},acceptData:function(e){if(e.nodeType&&1!==e.nodeType&&9!==e.nodeType)return!1;var t=e.nodeName&&b.noData[e.nodeName.toLowerCase()];return!t||t!==!0&&e.getAttribute("classid")===t}}),b.fn.extend({data:function(e,n){var r,i,o=this[0],a=0,s=null;if(e===t){if(this.length&&(s=b.data(o),1===o.nodeType&&!b._data(o,"parsedAttrs"))){for(r=o.attributes;r.length>a;a++)i=r[a].name,i.indexOf("data-")||(i=b.camelCase(i.slice(5)),W(o,i,s[i]));b._data(o,"parsedAttrs",!0)}return s}return"object"==typeof e?this.each(function(){b.data(this,e)}):b.access(this,function(n){return n===t?o?W(o,e,b.data(o,e)):null:(this.each(function(){b.data(this,e,n)}),t)},null,n,arguments.length>1,null,!0)},removeData:function(e){return this.each(function(){b.removeData(this,e)})}});function W(e,n,r){if(r===t&&1===e.nodeType){var i="data-"+n.replace(B,"-$1").toLowerCase();if(r=e.getAttribute(i),"string"==typeof r){try{r="true"===r?!0:"false"===r?!1:"null"===r?null:+r+""===r?+r:O.test(r)?b.parseJSON(r):r}catch(o){}b.data(e,n,r)}else r=t}return r}function $(e){var t;for(t in e)if(("data"!==t||!b.isEmptyObject(e[t]))&&"toJSON"!==t)return!1;return!0}b.extend({queue:function(e,n,r){var i;return e?(n=(n||"fx")+"queue",i=b._data(e,n),r&&(!i||b.isArray(r)?i=b._data(e,n,b.makeArray(r)):i.push(r)),i||[]):t},dequeue:function(e,t){t=t||"fx";var n=b.queue(e,t),r=n.length,i=n.shift(),o=b._queueHooks(e,t),a=function(){b.dequeue(e,t)};"inprogress"===i&&(i=n.shift(),r--),o.cur=i,i&&("fx"===t&&n.unshift("inprogress"),delete o.stop,i.call(e,a,o)),!r&&o&&o.empty.fire()},_queueHooks:function(e,t){var n=t+"queueHooks";return b._data(e,n)||b._data(e,n,{empty:b.Callbacks("once memory").add(function(){b._removeData(e,t+"queue"),b._removeData(e,n)})})}}),b.fn.extend({queue:function(e,n){var r=2;return"string"!=typeof e&&(n=e,e="fx",r--),r>arguments.length?b.queue(this[0],e):n===t?this:this.each(function(){var t=b.queue(this,e,n);b._queueHooks(this,e),"fx"===e&&"inprogress"!==t[0]&&b.dequeue(this,e)})},dequeue:function(e){return this.each(function(){b.dequeue(this,e)})},delay:function(e,t){return e=b.fx?b.fx.speeds[e]||e:e,t=t||"fx",this.queue(t,function(t,n){var r=setTimeout(t,e);n.stop=function(){clearTimeout(r)}})},clearQueue:function(e){return this.queue(e||"fx",[])},promise:function(e,n){var r,i=1,o=b.Deferred(),a=this,s=this.length,u=function(){--i||o.resolveWith(a,[a])};"string"!=typeof e&&(n=e,e=t),e=e||"fx";while(s--)r=b._data(a[s],e+"queueHooks"),r&&r.empty&&(i++,r.empty.add(u));return u(),o.promise(n)}});var I,z,X=/[\t\r\n]/g,U=/\r/g,V=/^(?:input|select|textarea|button|object)$/i,Y=/^(?:a|area)$/i,J=/^(?:checked|selected|autofocus|autoplay|async|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped)$/i,G=/^(?:checked|selected)$/i,Q=b.support.getSetAttribute,K=b.support.input;b.fn.extend({attr:function(e,t){return b.access(this,b.attr,e,t,arguments.length>1)},removeAttr:function(e){return this.each(function(){b.removeAttr(this,e)})},prop:function(e,t){return b.access(this,b.prop,e,t,arguments.length>1)},removeProp:function(e){return e=b.propFix[e]||e,this.each(function(){try{this[e]=t,delete this[e]}catch(n){}})},addClass:function(e){var t,n,r,i,o,a=0,s=this.length,u="string"==typeof e&&e;if(b.isFunction(e))return this.each(function(t){b(this).addClass(e.call(this,t,this.className))});if(u)for(t=(e||"").match(w)||[];s>a;a++)if(n=this[a],r=1===n.nodeType&&(n.className?(" "+n.className+" ").replace(X," "):" ")){o=0;while(i=t[o++])0>r.indexOf(" "+i+" ")&&(r+=i+" ");n.className=b.trim(r)}return this},removeClass:function(e){var t,n,r,i,o,a=0,s=this.length,u=0===arguments.length||"string"==typeof e&&e;if(b.isFunction(e))return this.each(function(t){b(this).removeClass(e.call(this,t,this.className))});if(u)for(t=(e||"").match(w)||[];s>a;a++)if(n=this[a],r=1===n.nodeType&&(n.className?(" "+n.className+" ").replace(X," "):"")){o=0;while(i=t[o++])while(r.indexOf(" "+i+" ")>=0)r=r.replace(" "+i+" "," ");n.className=e?b.trim(r):""}return this},toggleClass:function(e,t){var n=typeof e,r="boolean"==typeof t;return b.isFunction(e)?this.each(function(n){b(this).toggleClass(e.call(this,n,this.className,t),t)}):this.each(function(){if("string"===n){var o,a=0,s=b(this),u=t,l=e.match(w)||[];while(o=l[a++])u=r?u:!s.hasClass(o),s[u?"addClass":"removeClass"](o)}else(n===i||"boolean"===n)&&(this.className&&b._data(this,"__className__",this.className),this.className=this.className||e===!1?"":b._data(this,"__className__")||"")})},hasClass:function(e){var t=" "+e+" ",n=0,r=this.length;for(;r>n;n++)if(1===this[n].nodeType&&(" "+this[n].className+" ").replace(X," ").indexOf(t)>=0)return!0;return!1},val:function(e){var n,r,i,o=this[0];{if(arguments.length)return i=b.isFunction(e),this.each(function(n){var o,a=b(this);1===this.nodeType&&(o=i?e.call(this,n,a.val()):e,null==o?o="":"number"==typeof o?o+="":b.isArray(o)&&(o=b.map(o,function(e){return null==e?"":e+""})),r=b.valHooks[this.type]||b.valHooks[this.nodeName.toLowerCase()],r&&"set"in r&&r.set(this,o,"value")!==t||(this.value=o))});if(o)return r=b.valHooks[o.type]||b.valHooks[o.nodeName.toLowerCase()],r&&"get"in r&&(n=r.get(o,"value"))!==t?n:(n=o.value,"string"==typeof n?n.replace(U,""):null==n?"":n)}}}),b.extend({valHooks:{option:{get:function(e){var t=e.attributes.value;return!t||t.specified?e.value:e.text}},select:{get:function(e){var t,n,r=e.options,i=e.selectedIndex,o="select-one"===e.type||0>i,a=o?null:[],s=o?i+1:r.length,u=0>i?s:o?i:0;for(;s>u;u++)if(n=r[u],!(!n.selected&&u!==i||(b.support.optDisabled?n.disabled:null!==n.getAttribute("disabled"))||n.parentNode.disabled&&b.nodeName(n.parentNode,"optgroup"))){if(t=b(n).val(),o)return t;a.push(t)}return a},set:function(e,t){var n=b.makeArray(t);return b(e).find("option").each(function(){this.selected=b.inArray(b(this).val(),n)>=0}),n.length||(e.selectedIndex=-1),n}}},attr:function(e,n,r){var o,a,s,u=e.nodeType;if(e&&3!==u&&8!==u&&2!==u)return typeof e.getAttribute===i?b.prop(e,n,r):(a=1!==u||!b.isXMLDoc(e),a&&(n=n.toLowerCase(),o=b.attrHooks[n]||(J.test(n)?z:I)),r===t?o&&a&&"get"in o&&null!==(s=o.get(e,n))?s:(typeof e.getAttribute!==i&&(s=e.getAttribute(n)),null==s?t:s):null!==r?o&&a&&"set"in o&&(s=o.set(e,r,n))!==t?s:(e.setAttribute(n,r+""),r):(b.removeAttr(e,n),t))},removeAttr:function(e,t){var n,r,i=0,o=t&&t.match(w);if(o&&1===e.nodeType)while(n=o[i++])r=b.propFix[n]||n,J.test(n)?!Q&&G.test(n)?e[b.camelCase("default-"+n)]=e[r]=!1:e[r]=!1:b.attr(e,n,""),e.removeAttribute(Q?n:r)},attrHooks:{type:{set:function(e,t){if(!b.support.radioValue&&"radio"===t&&b.nodeName(e,"input")){var n=e.value;return e.setAttribute("type",t),n&&(e.value=n),t}}}},propFix:{tabindex:"tabIndex",readonly:"readOnly","for":"htmlFor","class":"className",maxlength:"maxLength",cellspacing:"cellSpacing",cellpadding:"cellPadding",rowspan:"rowSpan",colspan:"colSpan",usemap:"useMap",frameborder:"frameBorder",contenteditable:"contentEditable"},prop:function(e,n,r){var i,o,a,s=e.nodeType;if(e&&3!==s&&8!==s&&2!==s)return a=1!==s||!b.isXMLDoc(e),a&&(n=b.propFix[n]||n,o=b.propHooks[n]),r!==t?o&&"set"in o&&(i=o.set(e,r,n))!==t?i:e[n]=r:o&&"get"in o&&null!==(i=o.get(e,n))?i:e[n]},propHooks:{tabIndex:{get:function(e){var n=e.getAttributeNode("tabindex");return n&&n.specified?parseInt(n.value,10):V.test(e.nodeName)||Y.test(e.nodeName)&&e.href?0:t}}}}),z={get:function(e,n){var r=b.prop(e,n),i="boolean"==typeof r&&e.getAttribute(n),o="boolean"==typeof r?K&&Q?null!=i:G.test(n)?e[b.camelCase("default-"+n)]:!!i:e.getAttributeNode(n);return o&&o.value!==!1?n.toLowerCase():t},set:function(e,t,n){return t===!1?b.removeAttr(e,n):K&&Q||!G.test(n)?e.setAttribute(!Q&&b.propFix[n]||n,n):e[b.camelCase("default-"+n)]=e[n]=!0,n}},K&&Q||(b.attrHooks.value={get:function(e,n){var r=e.getAttributeNode(n);return b.nodeName(e,"input")?e.defaultValue:r&&r.specified?r.value:t},set:function(e,n,r){return b.nodeName(e,"input")?(e.defaultValue=n,t):I&&I.set(e,n,r)}}),Q||(I=b.valHooks.button={get:function(e,n){var r=e.getAttributeNode(n);return r&&("id"===n||"name"===n||"coords"===n?""!==r.value:r.specified)?r.value:t},set:function(e,n,r){var i=e.getAttributeNode(r);return i||e.setAttributeNode(i=e.ownerDocument.createAttribute(r)),i.value=n+="","value"===r||n===e.getAttribute(r)?n:t}},b.attrHooks.contenteditable={get:I.get,set:function(e,t,n){I.set(e,""===t?!1:t,n)}},b.each(["width","height"],function(e,n){b.attrHooks[n]=b.extend(b.attrHooks[n],{set:function(e,r){return""===r?(e.setAttribute(n,"auto"),r):t}})})),b.support.hrefNormalized||(b.each(["href","src","width","height"],function(e,n){b.attrHooks[n]=b.extend(b.attrHooks[n],{get:function(e){var r=e.getAttribute(n,2);return null==r?t:r}})}),b.each(["href","src"],function(e,t){b.propHooks[t]={get:function(e){return e.getAttribute(t,4)}}})),b.support.style||(b.attrHooks.style={get:function(e){return e.style.cssText||t},set:function(e,t){return e.style.cssText=t+""}}),b.support.optSelected||(b.propHooks.selected=b.extend(b.propHooks.selected,{get:function(e){var t=e.parentNode;return t&&(t.selectedIndex,t.parentNode&&t.parentNode.selectedIndex),null}})),b.support.enctype||(b.propFix.enctype="encoding"),b.support.checkOn||b.each(["radio","checkbox"],function(){b.valHooks[this]={get:function(e){return null===e.getAttribute("value")?"on":e.value}}}),b.each(["radio","checkbox"],function(){b.valHooks[this]=b.extend(b.valHooks[this],{set:function(e,n){return b.isArray(n)?e.checked=b.inArray(b(e).val(),n)>=0:t}})});var Z=/^(?:input|select|textarea)$/i,et=/^key/,tt=/^(?:mouse|contextmenu)|click/,nt=/^(?:focusinfocus|focusoutblur)$/,rt=/^([^.]*)(?:\.(.+)|)$/;function it(){return!0}function ot(){return!1}b.event={global:{},add:function(e,n,r,o,a){var s,u,l,c,p,f,d,h,g,m,y,v=b._data(e);if(v){r.handler&&(c=r,r=c.handler,a=c.selector),r.guid||(r.guid=b.guid++),(u=v.events)||(u=v.events={}),(f=v.handle)||(f=v.handle=function(e){return typeof b===i||e&&b.event.triggered===e.type?t:b.event.dispatch.apply(f.elem,arguments)},f.elem=e),n=(n||"").match(w)||[""],l=n.length;while(l--)s=rt.exec(n[l])||[],g=y=s[1],m=(s[2]||"").split(".").sort(),p=b.event.special[g]||{},g=(a?p.delegateType:p.bindType)||g,p=b.event.special[g]||{},d=b.extend({type:g,origType:y,data:o,handler:r,guid:r.guid,selector:a,needsContext:a&&b.expr.match.needsContext.test(a),namespace:m.join(".")},c),(h=u[g])||(h=u[g]=[],h.delegateCount=0,p.setup&&p.setup.call(e,o,m,f)!==!1||(e.addEventListener?e.addEventListener(g,f,!1):e.attachEvent&&e.attachEvent("on"+g,f))),p.add&&(p.add.call(e,d),d.handler.guid||(d.handler.guid=r.guid)),a?h.splice(h.delegateCount++,0,d):h.push(d),b.event.global[g]=!0;e=null}},remove:function(e,t,n,r,i){var o,a,s,u,l,c,p,f,d,h,g,m=b.hasData(e)&&b._data(e);if(m&&(c=m.events)){t=(t||"").match(w)||[""],l=t.length;while(l--)if(s=rt.exec(t[l])||[],d=g=s[1],h=(s[2]||"").split(".").sort(),d){p=b.event.special[d]||{},d=(r?p.delegateType:p.bindType)||d,f=c[d]||[],s=s[2]&&RegExp("(^|\\.)"+h.join("\\.(?:.*\\.|)")+"(\\.|$)"),u=o=f.length;while(o--)a=f[o],!i&&g!==a.origType||n&&n.guid!==a.guid||s&&!s.test(a.namespace)||r&&r!==a.selector&&("**"!==r||!a.selector)||(f.splice(o,1),a.selector&&f.delegateCount--,p.remove&&p.remove.call(e,a));u&&!f.length&&(p.teardown&&p.teardown.call(e,h,m.handle)!==!1||b.removeEvent(e,d,m.handle),delete c[d])}else for(d in c)b.event.remove(e,d+t[l],n,r,!0);b.isEmptyObject(c)&&(delete m.handle,b._removeData(e,"events"))}},trigger:function(n,r,i,a){var s,u,l,c,p,f,d,h=[i||o],g=y.call(n,"type")?n.type:n,m=y.call(n,"namespace")?n.namespace.split("."):[];if(l=f=i=i||o,3!==i.nodeType&&8!==i.nodeType&&!nt.test(g+b.event.triggered)&&(g.indexOf(".")>=0&&(m=g.split("."),g=m.shift(),m.sort()),u=0>g.indexOf(":")&&"on"+g,n=n[b.expando]?n:new b.Event(g,"object"==typeof n&&n),n.isTrigger=!0,n.namespace=m.join("."),n.namespace_re=n.namespace?RegExp("(^|\\.)"+m.join("\\.(?:.*\\.|)")+"(\\.|$)"):null,n.result=t,n.target||(n.target=i),r=null==r?[n]:b.makeArray(r,[n]),p=b.event.special[g]||{},a||!p.trigger||p.trigger.apply(i,r)!==!1)){if(!a&&!p.noBubble&&!b.isWindow(i)){for(c=p.delegateType||g,nt.test(c+g)||(l=l.parentNode);l;l=l.parentNode)h.push(l),f=l;f===(i.ownerDocument||o)&&h.push(f.defaultView||f.parentWindow||e)}d=0;while((l=h[d++])&&!n.isPropagationStopped())n.type=d>1?c:p.bindType||g,s=(b._data(l,"events")||{})[n.type]&&b._data(l,"handle"),s&&s.apply(l,r),s=u&&l[u],s&&b.acceptData(l)&&s.apply&&s.apply(l,r)===!1&&n.preventDefault();if(n.type=g,!(a||n.isDefaultPrevented()||p._default&&p._default.apply(i.ownerDocument,r)!==!1||"click"===g&&b.nodeName(i,"a")||!b.acceptData(i)||!u||!i[g]||b.isWindow(i))){f=i[u],f&&(i[u]=null),b.event.triggered=g;try{i[g]()}catch(v){}b.event.triggered=t,f&&(i[u]=f)}return n.result}},dispatch:function(e){e=b.event.fix(e);var n,r,i,o,a,s=[],u=h.call(arguments),l=(b._data(this,"events")||{})[e.type]||[],c=b.event.special[e.type]||{};if(u[0]=e,e.delegateTarget=this,!c.preDispatch||c.preDispatch.call(this,e)!==!1){s=b.event.handlers.call(this,e,l),n=0;while((o=s[n++])&&!e.isPropagationStopped()){e.currentTarget=o.elem,a=0;while((i=o.handlers[a++])&&!e.isImmediatePropagationStopped())(!e.namespace_re||e.namespace_re.test(i.namespace))&&(e.handleObj=i,e.data=i.data,r=((b.event.special[i.origType]||{}).handle||i.handler).apply(o.elem,u),r!==t&&(e.result=r)===!1&&(e.preventDefault(),e.stopPropagation()))}return c.postDispatch&&c.postDispatch.call(this,e),e.result}},handlers:function(e,n){var r,i,o,a,s=[],u=n.delegateCount,l=e.target;if(u&&l.nodeType&&(!e.button||"click"!==e.type))for(;l!=this;l=l.parentNode||this)if(1===l.nodeType&&(l.disabled!==!0||"click"!==e.type)){for(o=[],a=0;u>a;a++)i=n[a],r=i.selector+" ",o[r]===t&&(o[r]=i.needsContext?b(r,this).index(l)>=0:b.find(r,this,null,[l]).length),o[r]&&o.push(i);o.length&&s.push({elem:l,handlers:o})}return n.length>u&&s.push({elem:this,handlers:n.slice(u)}),s},fix:function(e){if(e[b.expando])return e;var t,n,r,i=e.type,a=e,s=this.fixHooks[i];s||(this.fixHooks[i]=s=tt.test(i)?this.mouseHooks:et.test(i)?this.keyHooks:{}),r=s.props?this.props.concat(s.props):this.props,e=new b.Event(a),t=r.length;while(t--)n=r[t],e[n]=a[n];return e.target||(e.target=a.srcElement||o),3===e.target.nodeType&&(e.target=e.target.parentNode),e.metaKey=!!e.metaKey,s.filter?s.filter(e,a):e},props:"altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),fixHooks:{},keyHooks:{props:"char charCode key keyCode".split(" "),filter:function(e,t){return null==e.which&&(e.which=null!=t.charCode?t.charCode:t.keyCode),e}},mouseHooks:{props:"button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),filter:function(e,n){var r,i,a,s=n.button,u=n.fromElement;return null==e.pageX&&null!=n.clientX&&(i=e.target.ownerDocument||o,a=i.documentElement,r=i.body,e.pageX=n.clientX+(a&&a.scrollLeft||r&&r.scrollLeft||0)-(a&&a.clientLeft||r&&r.clientLeft||0),e.pageY=n.clientY+(a&&a.scrollTop||r&&r.scrollTop||0)-(a&&a.clientTop||r&&r.clientTop||0)),!e.relatedTarget&&u&&(e.relatedTarget=u===e.target?n.toElement:u),e.which||s===t||(e.which=1&s?1:2&s?3:4&s?2:0),e}},special:{load:{noBubble:!0},click:{trigger:function(){return b.nodeName(this,"input")&&"checkbox"===this.type&&this.click?(this.click(),!1):t}},focus:{trigger:function(){if(this!==o.activeElement&&this.focus)try{return this.focus(),!1}catch(e){}},delegateType:"focusin"},blur:{trigger:function(){return this===o.activeElement&&this.blur?(this.blur(),!1):t},delegateType:"focusout"},beforeunload:{postDispatch:function(e){e.result!==t&&(e.originalEvent.returnValue=e.result)}}},simulate:function(e,t,n,r){var i=b.extend(new b.Event,n,{type:e,isSimulated:!0,originalEvent:{}});r?b.event.trigger(i,null,t):b.event.dispatch.call(t,i),i.isDefaultPrevented()&&n.preventDefault()}},b.removeEvent=o.removeEventListener?function(e,t,n){e.removeEventListener&&e.removeEventListener(t,n,!1)}:function(e,t,n){var r="on"+t;e.detachEvent&&(typeof e[r]===i&&(e[r]=null),e.detachEvent(r,n))},b.Event=function(e,n){return this instanceof b.Event?(e&&e.type?(this.originalEvent=e,this.type=e.type,this.isDefaultPrevented=e.defaultPrevented||e.returnValue===!1||e.getPreventDefault&&e.getPreventDefault()?it:ot):this.type=e,n&&b.extend(this,n),this.timeStamp=e&&e.timeStamp||b.now(),this[b.expando]=!0,t):new b.Event(e,n)},b.Event.prototype={isDefaultPrevented:ot,isPropagationStopped:ot,isImmediatePropagationStopped:ot,preventDefault:function(){var e=this.originalEvent;this.isDefaultPrevented=it,e&&(e.preventDefault?e.preventDefault():e.returnValue=!1)},stopPropagation:function(){var e=this.originalEvent;this.isPropagationStopped=it,e&&(e.stopPropagation&&e.stopPropagation(),e.cancelBubble=!0)},stopImmediatePropagation:function(){this.isImmediatePropagationStopped=it,this.stopPropagation()}},b.each({mouseenter:"mouseover",mouseleave:"mouseout"},function(e,t){b.event.special[e]={delegateType:t,bindType:t,handle:function(e){var n,r=this,i=e.relatedTarget,o=e.handleObj;
return(!i||i!==r&&!b.contains(r,i))&&(e.type=o.origType,n=o.handler.apply(this,arguments),e.type=t),n}}}),b.support.submitBubbles||(b.event.special.submit={setup:function(){return b.nodeName(this,"form")?!1:(b.event.add(this,"click._submit keypress._submit",function(e){var n=e.target,r=b.nodeName(n,"input")||b.nodeName(n,"button")?n.form:t;r&&!b._data(r,"submitBubbles")&&(b.event.add(r,"submit._submit",function(e){e._submit_bubble=!0}),b._data(r,"submitBubbles",!0))}),t)},postDispatch:function(e){e._submit_bubble&&(delete e._submit_bubble,this.parentNode&&!e.isTrigger&&b.event.simulate("submit",this.parentNode,e,!0))},teardown:function(){return b.nodeName(this,"form")?!1:(b.event.remove(this,"._submit"),t)}}),b.support.changeBubbles||(b.event.special.change={setup:function(){return Z.test(this.nodeName)?(("checkbox"===this.type||"radio"===this.type)&&(b.event.add(this,"propertychange._change",function(e){"checked"===e.originalEvent.propertyName&&(this._just_changed=!0)}),b.event.add(this,"click._change",function(e){this._just_changed&&!e.isTrigger&&(this._just_changed=!1),b.event.simulate("change",this,e,!0)})),!1):(b.event.add(this,"beforeactivate._change",function(e){var t=e.target;Z.test(t.nodeName)&&!b._data(t,"changeBubbles")&&(b.event.add(t,"change._change",function(e){!this.parentNode||e.isSimulated||e.isTrigger||b.event.simulate("change",this.parentNode,e,!0)}),b._data(t,"changeBubbles",!0))}),t)},handle:function(e){var n=e.target;return this!==n||e.isSimulated||e.isTrigger||"radio"!==n.type&&"checkbox"!==n.type?e.handleObj.handler.apply(this,arguments):t},teardown:function(){return b.event.remove(this,"._change"),!Z.test(this.nodeName)}}),b.support.focusinBubbles||b.each({focus:"focusin",blur:"focusout"},function(e,t){var n=0,r=function(e){b.event.simulate(t,e.target,b.event.fix(e),!0)};b.event.special[t]={setup:function(){0===n++&&o.addEventListener(e,r,!0)},teardown:function(){0===--n&&o.removeEventListener(e,r,!0)}}}),b.fn.extend({on:function(e,n,r,i,o){var a,s;if("object"==typeof e){"string"!=typeof n&&(r=r||n,n=t);for(a in e)this.on(a,n,r,e[a],o);return this}if(null==r&&null==i?(i=n,r=n=t):null==i&&("string"==typeof n?(i=r,r=t):(i=r,r=n,n=t)),i===!1)i=ot;else if(!i)return this;return 1===o&&(s=i,i=function(e){return b().off(e),s.apply(this,arguments)},i.guid=s.guid||(s.guid=b.guid++)),this.each(function(){b.event.add(this,e,i,r,n)})},one:function(e,t,n,r){return this.on(e,t,n,r,1)},off:function(e,n,r){var i,o;if(e&&e.preventDefault&&e.handleObj)return i=e.handleObj,b(e.delegateTarget).off(i.namespace?i.origType+"."+i.namespace:i.origType,i.selector,i.handler),this;if("object"==typeof e){for(o in e)this.off(o,n,e[o]);return this}return(n===!1||"function"==typeof n)&&(r=n,n=t),r===!1&&(r=ot),this.each(function(){b.event.remove(this,e,r,n)})},bind:function(e,t,n){return this.on(e,null,t,n)},unbind:function(e,t){return this.off(e,null,t)},delegate:function(e,t,n,r){return this.on(t,e,n,r)},undelegate:function(e,t,n){return 1===arguments.length?this.off(e,"**"):this.off(t,e||"**",n)},trigger:function(e,t){return this.each(function(){b.event.trigger(e,t,this)})},triggerHandler:function(e,n){var r=this[0];return r?b.event.trigger(e,n,r,!0):t}}),function(e,t){var n,r,i,o,a,s,u,l,c,p,f,d,h,g,m,y,v,x="sizzle"+-new Date,w=e.document,T={},N=0,C=0,k=it(),E=it(),S=it(),A=typeof t,j=1<<31,D=[],L=D.pop,H=D.push,q=D.slice,M=D.indexOf||function(e){var t=0,n=this.length;for(;n>t;t++)if(this[t]===e)return t;return-1},_="[\\x20\\t\\r\\n\\f]",F="(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",O=F.replace("w","w#"),B="([*^$|!~]?=)",P="\\["+_+"*("+F+")"+_+"*(?:"+B+_+"*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|("+O+")|)|)"+_+"*\\]",R=":("+F+")(?:\\(((['\"])((?:\\\\.|[^\\\\])*?)\\3|((?:\\\\.|[^\\\\()[\\]]|"+P.replace(3,8)+")*)|.*)\\)|)",W=RegExp("^"+_+"+|((?:^|[^\\\\])(?:\\\\.)*)"+_+"+$","g"),$=RegExp("^"+_+"*,"+_+"*"),I=RegExp("^"+_+"*([\\x20\\t\\r\\n\\f>+~])"+_+"*"),z=RegExp(R),X=RegExp("^"+O+"$"),U={ID:RegExp("^#("+F+")"),CLASS:RegExp("^\\.("+F+")"),NAME:RegExp("^\\[name=['\"]?("+F+")['\"]?\\]"),TAG:RegExp("^("+F.replace("w","w*")+")"),ATTR:RegExp("^"+P),PSEUDO:RegExp("^"+R),CHILD:RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\("+_+"*(even|odd|(([+-]|)(\\d*)n|)"+_+"*(?:([+-]|)"+_+"*(\\d+)|))"+_+"*\\)|)","i"),needsContext:RegExp("^"+_+"*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\("+_+"*((?:-\\d)?\\d*)"+_+"*\\)|)(?=[^-]|$)","i")},V=/[\x20\t\r\n\f]*[+~]/,Y=/^[^{]+\{\s*\[native code/,J=/^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,G=/^(?:input|select|textarea|button)$/i,Q=/^h\d$/i,K=/'|\\/g,Z=/\=[\x20\t\r\n\f]*([^'"\]]*)[\x20\t\r\n\f]*\]/g,et=/\\([\da-fA-F]{1,6}[\x20\t\r\n\f]?|.)/g,tt=function(e,t){var n="0x"+t-65536;return n!==n?t:0>n?String.fromCharCode(n+65536):String.fromCharCode(55296|n>>10,56320|1023&n)};try{q.call(w.documentElement.childNodes,0)[0].nodeType}catch(nt){q=function(e){var t,n=[];while(t=this[e++])n.push(t);return n}}function rt(e){return Y.test(e+"")}function it(){var e,t=[];return e=function(n,r){return t.push(n+=" ")>i.cacheLength&&delete e[t.shift()],e[n]=r}}function ot(e){return e[x]=!0,e}function at(e){var t=p.createElement("div");try{return e(t)}catch(n){return!1}finally{t=null}}function st(e,t,n,r){var i,o,a,s,u,l,f,g,m,v;if((t?t.ownerDocument||t:w)!==p&&c(t),t=t||p,n=n||[],!e||"string"!=typeof e)return n;if(1!==(s=t.nodeType)&&9!==s)return[];if(!d&&!r){if(i=J.exec(e))if(a=i[1]){if(9===s){if(o=t.getElementById(a),!o||!o.parentNode)return n;if(o.id===a)return n.push(o),n}else if(t.ownerDocument&&(o=t.ownerDocument.getElementById(a))&&y(t,o)&&o.id===a)return n.push(o),n}else{if(i[2])return H.apply(n,q.call(t.getElementsByTagName(e),0)),n;if((a=i[3])&&T.getByClassName&&t.getElementsByClassName)return H.apply(n,q.call(t.getElementsByClassName(a),0)),n}if(T.qsa&&!h.test(e)){if(f=!0,g=x,m=t,v=9===s&&e,1===s&&"object"!==t.nodeName.toLowerCase()){l=ft(e),(f=t.getAttribute("id"))?g=f.replace(K,"\\$&"):t.setAttribute("id",g),g="[id='"+g+"'] ",u=l.length;while(u--)l[u]=g+dt(l[u]);m=V.test(e)&&t.parentNode||t,v=l.join(",")}if(v)try{return H.apply(n,q.call(m.querySelectorAll(v),0)),n}catch(b){}finally{f||t.removeAttribute("id")}}}return wt(e.replace(W,"$1"),t,n,r)}a=st.isXML=function(e){var t=e&&(e.ownerDocument||e).documentElement;return t?"HTML"!==t.nodeName:!1},c=st.setDocument=function(e){var n=e?e.ownerDocument||e:w;return n!==p&&9===n.nodeType&&n.documentElement?(p=n,f=n.documentElement,d=a(n),T.tagNameNoComments=at(function(e){return e.appendChild(n.createComment("")),!e.getElementsByTagName("*").length}),T.attributes=at(function(e){e.innerHTML="<select></select>";var t=typeof e.lastChild.getAttribute("multiple");return"boolean"!==t&&"string"!==t}),T.getByClassName=at(function(e){return e.innerHTML="<div class='hidden e'></div><div class='hidden'></div>",e.getElementsByClassName&&e.getElementsByClassName("e").length?(e.lastChild.className="e",2===e.getElementsByClassName("e").length):!1}),T.getByName=at(function(e){e.id=x+0,e.innerHTML="<a name='"+x+"'></a><div name='"+x+"'></div>",f.insertBefore(e,f.firstChild);var t=n.getElementsByName&&n.getElementsByName(x).length===2+n.getElementsByName(x+0).length;return T.getIdNotName=!n.getElementById(x),f.removeChild(e),t}),i.attrHandle=at(function(e){return e.innerHTML="<a href='#'></a>",e.firstChild&&typeof e.firstChild.getAttribute!==A&&"#"===e.firstChild.getAttribute("href")})?{}:{href:function(e){return e.getAttribute("href",2)},type:function(e){return e.getAttribute("type")}},T.getIdNotName?(i.find.ID=function(e,t){if(typeof t.getElementById!==A&&!d){var n=t.getElementById(e);return n&&n.parentNode?[n]:[]}},i.filter.ID=function(e){var t=e.replace(et,tt);return function(e){return e.getAttribute("id")===t}}):(i.find.ID=function(e,n){if(typeof n.getElementById!==A&&!d){var r=n.getElementById(e);return r?r.id===e||typeof r.getAttributeNode!==A&&r.getAttributeNode("id").value===e?[r]:t:[]}},i.filter.ID=function(e){var t=e.replace(et,tt);return function(e){var n=typeof e.getAttributeNode!==A&&e.getAttributeNode("id");return n&&n.value===t}}),i.find.TAG=T.tagNameNoComments?function(e,n){return typeof n.getElementsByTagName!==A?n.getElementsByTagName(e):t}:function(e,t){var n,r=[],i=0,o=t.getElementsByTagName(e);if("*"===e){while(n=o[i++])1===n.nodeType&&r.push(n);return r}return o},i.find.NAME=T.getByName&&function(e,n){return typeof n.getElementsByName!==A?n.getElementsByName(name):t},i.find.CLASS=T.getByClassName&&function(e,n){return typeof n.getElementsByClassName===A||d?t:n.getElementsByClassName(e)},g=[],h=[":focus"],(T.qsa=rt(n.querySelectorAll))&&(at(function(e){e.innerHTML="<select><option selected=''></option></select>",e.querySelectorAll("[selected]").length||h.push("\\["+_+"*(?:checked|disabled|ismap|multiple|readonly|selected|value)"),e.querySelectorAll(":checked").length||h.push(":checked")}),at(function(e){e.innerHTML="<input type='hidden' i=''/>",e.querySelectorAll("[i^='']").length&&h.push("[*^$]="+_+"*(?:\"\"|'')"),e.querySelectorAll(":enabled").length||h.push(":enabled",":disabled"),e.querySelectorAll("*,:x"),h.push(",.*:")})),(T.matchesSelector=rt(m=f.matchesSelector||f.mozMatchesSelector||f.webkitMatchesSelector||f.oMatchesSelector||f.msMatchesSelector))&&at(function(e){T.disconnectedMatch=m.call(e,"div"),m.call(e,"[s!='']:x"),g.push("!=",R)}),h=RegExp(h.join("|")),g=RegExp(g.join("|")),y=rt(f.contains)||f.compareDocumentPosition?function(e,t){var n=9===e.nodeType?e.documentElement:e,r=t&&t.parentNode;return e===r||!(!r||1!==r.nodeType||!(n.contains?n.contains(r):e.compareDocumentPosition&&16&e.compareDocumentPosition(r)))}:function(e,t){if(t)while(t=t.parentNode)if(t===e)return!0;return!1},v=f.compareDocumentPosition?function(e,t){var r;return e===t?(u=!0,0):(r=t.compareDocumentPosition&&e.compareDocumentPosition&&e.compareDocumentPosition(t))?1&r||e.parentNode&&11===e.parentNode.nodeType?e===n||y(w,e)?-1:t===n||y(w,t)?1:0:4&r?-1:1:e.compareDocumentPosition?-1:1}:function(e,t){var r,i=0,o=e.parentNode,a=t.parentNode,s=[e],l=[t];if(e===t)return u=!0,0;if(!o||!a)return e===n?-1:t===n?1:o?-1:a?1:0;if(o===a)return ut(e,t);r=e;while(r=r.parentNode)s.unshift(r);r=t;while(r=r.parentNode)l.unshift(r);while(s[i]===l[i])i++;return i?ut(s[i],l[i]):s[i]===w?-1:l[i]===w?1:0},u=!1,[0,0].sort(v),T.detectDuplicates=u,p):p},st.matches=function(e,t){return st(e,null,null,t)},st.matchesSelector=function(e,t){if((e.ownerDocument||e)!==p&&c(e),t=t.replace(Z,"='$1']"),!(!T.matchesSelector||d||g&&g.test(t)||h.test(t)))try{var n=m.call(e,t);if(n||T.disconnectedMatch||e.document&&11!==e.document.nodeType)return n}catch(r){}return st(t,p,null,[e]).length>0},st.contains=function(e,t){return(e.ownerDocument||e)!==p&&c(e),y(e,t)},st.attr=function(e,t){var n;return(e.ownerDocument||e)!==p&&c(e),d||(t=t.toLowerCase()),(n=i.attrHandle[t])?n(e):d||T.attributes?e.getAttribute(t):((n=e.getAttributeNode(t))||e.getAttribute(t))&&e[t]===!0?t:n&&n.specified?n.value:null},st.error=function(e){throw Error("Syntax error, unrecognized expression: "+e)},st.uniqueSort=function(e){var t,n=[],r=1,i=0;if(u=!T.detectDuplicates,e.sort(v),u){for(;t=e[r];r++)t===e[r-1]&&(i=n.push(r));while(i--)e.splice(n[i],1)}return e};function ut(e,t){var n=t&&e,r=n&&(~t.sourceIndex||j)-(~e.sourceIndex||j);if(r)return r;if(n)while(n=n.nextSibling)if(n===t)return-1;return e?1:-1}function lt(e){return function(t){var n=t.nodeName.toLowerCase();return"input"===n&&t.type===e}}function ct(e){return function(t){var n=t.nodeName.toLowerCase();return("input"===n||"button"===n)&&t.type===e}}function pt(e){return ot(function(t){return t=+t,ot(function(n,r){var i,o=e([],n.length,t),a=o.length;while(a--)n[i=o[a]]&&(n[i]=!(r[i]=n[i]))})})}o=st.getText=function(e){var t,n="",r=0,i=e.nodeType;if(i){if(1===i||9===i||11===i){if("string"==typeof e.textContent)return e.textContent;for(e=e.firstChild;e;e=e.nextSibling)n+=o(e)}else if(3===i||4===i)return e.nodeValue}else for(;t=e[r];r++)n+=o(t);return n},i=st.selectors={cacheLength:50,createPseudo:ot,match:U,find:{},relative:{">":{dir:"parentNode",first:!0}," ":{dir:"parentNode"},"+":{dir:"previousSibling",first:!0},"~":{dir:"previousSibling"}},preFilter:{ATTR:function(e){return e[1]=e[1].replace(et,tt),e[3]=(e[4]||e[5]||"").replace(et,tt),"~="===e[2]&&(e[3]=" "+e[3]+" "),e.slice(0,4)},CHILD:function(e){return e[1]=e[1].toLowerCase(),"nth"===e[1].slice(0,3)?(e[3]||st.error(e[0]),e[4]=+(e[4]?e[5]+(e[6]||1):2*("even"===e[3]||"odd"===e[3])),e[5]=+(e[7]+e[8]||"odd"===e[3])):e[3]&&st.error(e[0]),e},PSEUDO:function(e){var t,n=!e[5]&&e[2];return U.CHILD.test(e[0])?null:(e[4]?e[2]=e[4]:n&&z.test(n)&&(t=ft(n,!0))&&(t=n.indexOf(")",n.length-t)-n.length)&&(e[0]=e[0].slice(0,t),e[2]=n.slice(0,t)),e.slice(0,3))}},filter:{TAG:function(e){return"*"===e?function(){return!0}:(e=e.replace(et,tt).toLowerCase(),function(t){return t.nodeName&&t.nodeName.toLowerCase()===e})},CLASS:function(e){var t=k[e+" "];return t||(t=RegExp("(^|"+_+")"+e+"("+_+"|$)"))&&k(e,function(e){return t.test(e.className||typeof e.getAttribute!==A&&e.getAttribute("class")||"")})},ATTR:function(e,t,n){return function(r){var i=st.attr(r,e);return null==i?"!="===t:t?(i+="","="===t?i===n:"!="===t?i!==n:"^="===t?n&&0===i.indexOf(n):"*="===t?n&&i.indexOf(n)>-1:"$="===t?n&&i.slice(-n.length)===n:"~="===t?(" "+i+" ").indexOf(n)>-1:"|="===t?i===n||i.slice(0,n.length+1)===n+"-":!1):!0}},CHILD:function(e,t,n,r,i){var o="nth"!==e.slice(0,3),a="last"!==e.slice(-4),s="of-type"===t;return 1===r&&0===i?function(e){return!!e.parentNode}:function(t,n,u){var l,c,p,f,d,h,g=o!==a?"nextSibling":"previousSibling",m=t.parentNode,y=s&&t.nodeName.toLowerCase(),v=!u&&!s;if(m){if(o){while(g){p=t;while(p=p[g])if(s?p.nodeName.toLowerCase()===y:1===p.nodeType)return!1;h=g="only"===e&&!h&&"nextSibling"}return!0}if(h=[a?m.firstChild:m.lastChild],a&&v){c=m[x]||(m[x]={}),l=c[e]||[],d=l[0]===N&&l[1],f=l[0]===N&&l[2],p=d&&m.childNodes[d];while(p=++d&&p&&p[g]||(f=d=0)||h.pop())if(1===p.nodeType&&++f&&p===t){c[e]=[N,d,f];break}}else if(v&&(l=(t[x]||(t[x]={}))[e])&&l[0]===N)f=l[1];else while(p=++d&&p&&p[g]||(f=d=0)||h.pop())if((s?p.nodeName.toLowerCase()===y:1===p.nodeType)&&++f&&(v&&((p[x]||(p[x]={}))[e]=[N,f]),p===t))break;return f-=i,f===r||0===f%r&&f/r>=0}}},PSEUDO:function(e,t){var n,r=i.pseudos[e]||i.setFilters[e.toLowerCase()]||st.error("unsupported pseudo: "+e);return r[x]?r(t):r.length>1?(n=[e,e,"",t],i.setFilters.hasOwnProperty(e.toLowerCase())?ot(function(e,n){var i,o=r(e,t),a=o.length;while(a--)i=M.call(e,o[a]),e[i]=!(n[i]=o[a])}):function(e){return r(e,0,n)}):r}},pseudos:{not:ot(function(e){var t=[],n=[],r=s(e.replace(W,"$1"));return r[x]?ot(function(e,t,n,i){var o,a=r(e,null,i,[]),s=e.length;while(s--)(o=a[s])&&(e[s]=!(t[s]=o))}):function(e,i,o){return t[0]=e,r(t,null,o,n),!n.pop()}}),has:ot(function(e){return function(t){return st(e,t).length>0}}),contains:ot(function(e){return function(t){return(t.textContent||t.innerText||o(t)).indexOf(e)>-1}}),lang:ot(function(e){return X.test(e||"")||st.error("unsupported lang: "+e),e=e.replace(et,tt).toLowerCase(),function(t){var n;do if(n=d?t.getAttribute("xml:lang")||t.getAttribute("lang"):t.lang)return n=n.toLowerCase(),n===e||0===n.indexOf(e+"-");while((t=t.parentNode)&&1===t.nodeType);return!1}}),target:function(t){var n=e.location&&e.location.hash;return n&&n.slice(1)===t.id},root:function(e){return e===f},focus:function(e){return e===p.activeElement&&(!p.hasFocus||p.hasFocus())&&!!(e.type||e.href||~e.tabIndex)},enabled:function(e){return e.disabled===!1},disabled:function(e){return e.disabled===!0},checked:function(e){var t=e.nodeName.toLowerCase();return"input"===t&&!!e.checked||"option"===t&&!!e.selected},selected:function(e){return e.parentNode&&e.parentNode.selectedIndex,e.selected===!0},empty:function(e){for(e=e.firstChild;e;e=e.nextSibling)if(e.nodeName>"@"||3===e.nodeType||4===e.nodeType)return!1;return!0},parent:function(e){return!i.pseudos.empty(e)},header:function(e){return Q.test(e.nodeName)},input:function(e){return G.test(e.nodeName)},button:function(e){var t=e.nodeName.toLowerCase();return"input"===t&&"button"===e.type||"button"===t},text:function(e){var t;return"input"===e.nodeName.toLowerCase()&&"text"===e.type&&(null==(t=e.getAttribute("type"))||t.toLowerCase()===e.type)},first:pt(function(){return[0]}),last:pt(function(e,t){return[t-1]}),eq:pt(function(e,t,n){return[0>n?n+t:n]}),even:pt(function(e,t){var n=0;for(;t>n;n+=2)e.push(n);return e}),odd:pt(function(e,t){var n=1;for(;t>n;n+=2)e.push(n);return e}),lt:pt(function(e,t,n){var r=0>n?n+t:n;for(;--r>=0;)e.push(r);return e}),gt:pt(function(e,t,n){var r=0>n?n+t:n;for(;t>++r;)e.push(r);return e})}};for(n in{radio:!0,checkbox:!0,file:!0,password:!0,image:!0})i.pseudos[n]=lt(n);for(n in{submit:!0,reset:!0})i.pseudos[n]=ct(n);function ft(e,t){var n,r,o,a,s,u,l,c=E[e+" "];if(c)return t?0:c.slice(0);s=e,u=[],l=i.preFilter;while(s){(!n||(r=$.exec(s)))&&(r&&(s=s.slice(r[0].length)||s),u.push(o=[])),n=!1,(r=I.exec(s))&&(n=r.shift(),o.push({value:n,type:r[0].replace(W," ")}),s=s.slice(n.length));for(a in i.filter)!(r=U[a].exec(s))||l[a]&&!(r=l[a](r))||(n=r.shift(),o.push({value:n,type:a,matches:r}),s=s.slice(n.length));if(!n)break}return t?s.length:s?st.error(e):E(e,u).slice(0)}function dt(e){var t=0,n=e.length,r="";for(;n>t;t++)r+=e[t].value;return r}function ht(e,t,n){var i=t.dir,o=n&&"parentNode"===i,a=C++;return t.first?function(t,n,r){while(t=t[i])if(1===t.nodeType||o)return e(t,n,r)}:function(t,n,s){var u,l,c,p=N+" "+a;if(s){while(t=t[i])if((1===t.nodeType||o)&&e(t,n,s))return!0}else while(t=t[i])if(1===t.nodeType||o)if(c=t[x]||(t[x]={}),(l=c[i])&&l[0]===p){if((u=l[1])===!0||u===r)return u===!0}else if(l=c[i]=[p],l[1]=e(t,n,s)||r,l[1]===!0)return!0}}function gt(e){return e.length>1?function(t,n,r){var i=e.length;while(i--)if(!e[i](t,n,r))return!1;return!0}:e[0]}function mt(e,t,n,r,i){var o,a=[],s=0,u=e.length,l=null!=t;for(;u>s;s++)(o=e[s])&&(!n||n(o,r,i))&&(a.push(o),l&&t.push(s));return a}function yt(e,t,n,r,i,o){return r&&!r[x]&&(r=yt(r)),i&&!i[x]&&(i=yt(i,o)),ot(function(o,a,s,u){var l,c,p,f=[],d=[],h=a.length,g=o||xt(t||"*",s.nodeType?[s]:s,[]),m=!e||!o&&t?g:mt(g,f,e,s,u),y=n?i||(o?e:h||r)?[]:a:m;if(n&&n(m,y,s,u),r){l=mt(y,d),r(l,[],s,u),c=l.length;while(c--)(p=l[c])&&(y[d[c]]=!(m[d[c]]=p))}if(o){if(i||e){if(i){l=[],c=y.length;while(c--)(p=y[c])&&l.push(m[c]=p);i(null,y=[],l,u)}c=y.length;while(c--)(p=y[c])&&(l=i?M.call(o,p):f[c])>-1&&(o[l]=!(a[l]=p))}}else y=mt(y===a?y.splice(h,y.length):y),i?i(null,a,y,u):H.apply(a,y)})}function vt(e){var t,n,r,o=e.length,a=i.relative[e[0].type],s=a||i.relative[" "],u=a?1:0,c=ht(function(e){return e===t},s,!0),p=ht(function(e){return M.call(t,e)>-1},s,!0),f=[function(e,n,r){return!a&&(r||n!==l)||((t=n).nodeType?c(e,n,r):p(e,n,r))}];for(;o>u;u++)if(n=i.relative[e[u].type])f=[ht(gt(f),n)];else{if(n=i.filter[e[u].type].apply(null,e[u].matches),n[x]){for(r=++u;o>r;r++)if(i.relative[e[r].type])break;return yt(u>1&&gt(f),u>1&&dt(e.slice(0,u-1)).replace(W,"$1"),n,r>u&&vt(e.slice(u,r)),o>r&&vt(e=e.slice(r)),o>r&&dt(e))}f.push(n)}return gt(f)}function bt(e,t){var n=0,o=t.length>0,a=e.length>0,s=function(s,u,c,f,d){var h,g,m,y=[],v=0,b="0",x=s&&[],w=null!=d,T=l,C=s||a&&i.find.TAG("*",d&&u.parentNode||u),k=N+=null==T?1:Math.random()||.1;for(w&&(l=u!==p&&u,r=n);null!=(h=C[b]);b++){if(a&&h){g=0;while(m=e[g++])if(m(h,u,c)){f.push(h);break}w&&(N=k,r=++n)}o&&((h=!m&&h)&&v--,s&&x.push(h))}if(v+=b,o&&b!==v){g=0;while(m=t[g++])m(x,y,u,c);if(s){if(v>0)while(b--)x[b]||y[b]||(y[b]=L.call(f));y=mt(y)}H.apply(f,y),w&&!s&&y.length>0&&v+t.length>1&&st.uniqueSort(f)}return w&&(N=k,l=T),x};return o?ot(s):s}s=st.compile=function(e,t){var n,r=[],i=[],o=S[e+" "];if(!o){t||(t=ft(e)),n=t.length;while(n--)o=vt(t[n]),o[x]?r.push(o):i.push(o);o=S(e,bt(i,r))}return o};function xt(e,t,n){var r=0,i=t.length;for(;i>r;r++)st(e,t[r],n);return n}function wt(e,t,n,r){var o,a,u,l,c,p=ft(e);if(!r&&1===p.length){if(a=p[0]=p[0].slice(0),a.length>2&&"ID"===(u=a[0]).type&&9===t.nodeType&&!d&&i.relative[a[1].type]){if(t=i.find.ID(u.matches[0].replace(et,tt),t)[0],!t)return n;e=e.slice(a.shift().value.length)}o=U.needsContext.test(e)?0:a.length;while(o--){if(u=a[o],i.relative[l=u.type])break;if((c=i.find[l])&&(r=c(u.matches[0].replace(et,tt),V.test(a[0].type)&&t.parentNode||t))){if(a.splice(o,1),e=r.length&&dt(a),!e)return H.apply(n,q.call(r,0)),n;break}}}return s(e,p)(r,t,d,n,V.test(e)),n}i.pseudos.nth=i.pseudos.eq;function Tt(){}i.filters=Tt.prototype=i.pseudos,i.setFilters=new Tt,c(),st.attr=b.attr,b.find=st,b.expr=st.selectors,b.expr[":"]=b.expr.pseudos,b.unique=st.uniqueSort,b.text=st.getText,b.isXMLDoc=st.isXML,b.contains=st.contains}(e);var at=/Until$/,st=/^(?:parents|prev(?:Until|All))/,ut=/^.[^:#\[\.,]*$/,lt=b.expr.match.needsContext,ct={children:!0,contents:!0,next:!0,prev:!0};b.fn.extend({find:function(e){var t,n,r,i=this.length;if("string"!=typeof e)return r=this,this.pushStack(b(e).filter(function(){for(t=0;i>t;t++)if(b.contains(r[t],this))return!0}));for(n=[],t=0;i>t;t++)b.find(e,this[t],n);return n=this.pushStack(i>1?b.unique(n):n),n.selector=(this.selector?this.selector+" ":"")+e,n},has:function(e){var t,n=b(e,this),r=n.length;return this.filter(function(){for(t=0;r>t;t++)if(b.contains(this,n[t]))return!0})},not:function(e){return this.pushStack(ft(this,e,!1))},filter:function(e){return this.pushStack(ft(this,e,!0))},is:function(e){return!!e&&("string"==typeof e?lt.test(e)?b(e,this.context).index(this[0])>=0:b.filter(e,this).length>0:this.filter(e).length>0)},closest:function(e,t){var n,r=0,i=this.length,o=[],a=lt.test(e)||"string"!=typeof e?b(e,t||this.context):0;for(;i>r;r++){n=this[r];while(n&&n.ownerDocument&&n!==t&&11!==n.nodeType){if(a?a.index(n)>-1:b.find.matchesSelector(n,e)){o.push(n);break}n=n.parentNode}}return this.pushStack(o.length>1?b.unique(o):o)},index:function(e){return e?"string"==typeof e?b.inArray(this[0],b(e)):b.inArray(e.jquery?e[0]:e,this):this[0]&&this[0].parentNode?this.first().prevAll().length:-1},add:function(e,t){var n="string"==typeof e?b(e,t):b.makeArray(e&&e.nodeType?[e]:e),r=b.merge(this.get(),n);return this.pushStack(b.unique(r))},addBack:function(e){return this.add(null==e?this.prevObject:this.prevObject.filter(e))}}),b.fn.andSelf=b.fn.addBack;function pt(e,t){do e=e[t];while(e&&1!==e.nodeType);return e}b.each({parent:function(e){var t=e.parentNode;return t&&11!==t.nodeType?t:null},parents:function(e){return b.dir(e,"parentNode")},parentsUntil:function(e,t,n){return b.dir(e,"parentNode",n)},next:function(e){return pt(e,"nextSibling")},prev:function(e){return pt(e,"previousSibling")},nextAll:function(e){return b.dir(e,"nextSibling")},prevAll:function(e){return b.dir(e,"previousSibling")},nextUntil:function(e,t,n){return b.dir(e,"nextSibling",n)},prevUntil:function(e,t,n){return b.dir(e,"previousSibling",n)},siblings:function(e){return b.sibling((e.parentNode||{}).firstChild,e)},children:function(e){return b.sibling(e.firstChild)},contents:function(e){return b.nodeName(e,"iframe")?e.contentDocument||e.contentWindow.document:b.merge([],e.childNodes)}},function(e,t){b.fn[e]=function(n,r){var i=b.map(this,t,n);return at.test(e)||(r=n),r&&"string"==typeof r&&(i=b.filter(r,i)),i=this.length>1&&!ct[e]?b.unique(i):i,this.length>1&&st.test(e)&&(i=i.reverse()),this.pushStack(i)}}),b.extend({filter:function(e,t,n){return n&&(e=":not("+e+")"),1===t.length?b.find.matchesSelector(t[0],e)?[t[0]]:[]:b.find.matches(e,t)},dir:function(e,n,r){var i=[],o=e[n];while(o&&9!==o.nodeType&&(r===t||1!==o.nodeType||!b(o).is(r)))1===o.nodeType&&i.push(o),o=o[n];return i},sibling:function(e,t){var n=[];for(;e;e=e.nextSibling)1===e.nodeType&&e!==t&&n.push(e);return n}});function ft(e,t,n){if(t=t||0,b.isFunction(t))return b.grep(e,function(e,r){var i=!!t.call(e,r,e);return i===n});if(t.nodeType)return b.grep(e,function(e){return e===t===n});if("string"==typeof t){var r=b.grep(e,function(e){return 1===e.nodeType});if(ut.test(t))return b.filter(t,r,!n);t=b.filter(t,r)}return b.grep(e,function(e){return b.inArray(e,t)>=0===n})}function dt(e){var t=ht.split("|"),n=e.createDocumentFragment();if(n.createElement)while(t.length)n.createElement(t.pop());return n}var ht="abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",gt=/ jQuery\d+="(?:null|\d+)"/g,mt=RegExp("<(?:"+ht+")[\\s/>]","i"),yt=/^\s+/,vt=/<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,bt=/<([\w:]+)/,xt=/<tbody/i,wt=/<|&#?\w+;/,Tt=/<(?:script|style|link)/i,Nt=/^(?:checkbox|radio)$/i,Ct=/checked\s*(?:[^=]|=\s*.checked.)/i,kt=/^$|\/(?:java|ecma)script/i,Et=/^true\/(.*)/,St=/^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,At={option:[1,"<select multiple='multiple'>","</select>"],legend:[1,"<fieldset>","</fieldset>"],area:[1,"<map>","</map>"],param:[1,"<object>","</object>"],thead:[1,"<table>","</table>"],tr:[2,"<table><tbody>","</tbody></table>"],col:[2,"<table><tbody></tbody><colgroup>","</colgroup></table>"],td:[3,"<table><tbody><tr>","</tr></tbody></table>"],_default:b.support.htmlSerialize?[0,"",""]:[1,"X<div>","</div>"]},jt=dt(o),Dt=jt.appendChild(o.createElement("div"));At.optgroup=At.option,At.tbody=At.tfoot=At.colgroup=At.caption=At.thead,At.th=At.td,b.fn.extend({text:function(e){return b.access(this,function(e){return e===t?b.text(this):this.empty().append((this[0]&&this[0].ownerDocument||o).createTextNode(e))},null,e,arguments.length)},wrapAll:function(e){if(b.isFunction(e))return this.each(function(t){b(this).wrapAll(e.call(this,t))});if(this[0]){var t=b(e,this[0].ownerDocument).eq(0).clone(!0);this[0].parentNode&&t.insertBefore(this[0]),t.map(function(){var e=this;while(e.firstChild&&1===e.firstChild.nodeType)e=e.firstChild;return e}).append(this)}return this},wrapInner:function(e){return b.isFunction(e)?this.each(function(t){b(this).wrapInner(e.call(this,t))}):this.each(function(){var t=b(this),n=t.contents();n.length?n.wrapAll(e):t.append(e)})},wrap:function(e){var t=b.isFunction(e);return this.each(function(n){b(this).wrapAll(t?e.call(this,n):e)})},unwrap:function(){return this.parent().each(function(){b.nodeName(this,"body")||b(this).replaceWith(this.childNodes)}).end()},append:function(){return this.domManip(arguments,!0,function(e){(1===this.nodeType||11===this.nodeType||9===this.nodeType)&&this.appendChild(e)})},prepend:function(){return this.domManip(arguments,!0,function(e){(1===this.nodeType||11===this.nodeType||9===this.nodeType)&&this.insertBefore(e,this.firstChild)})},before:function(){return this.domManip(arguments,!1,function(e){this.parentNode&&this.parentNode.insertBefore(e,this)})},after:function(){return this.domManip(arguments,!1,function(e){this.parentNode&&this.parentNode.insertBefore(e,this.nextSibling)})},remove:function(e,t){var n,r=0;for(;null!=(n=this[r]);r++)(!e||b.filter(e,[n]).length>0)&&(t||1!==n.nodeType||b.cleanData(Ot(n)),n.parentNode&&(t&&b.contains(n.ownerDocument,n)&&Mt(Ot(n,"script")),n.parentNode.removeChild(n)));return this},empty:function(){var e,t=0;for(;null!=(e=this[t]);t++){1===e.nodeType&&b.cleanData(Ot(e,!1));while(e.firstChild)e.removeChild(e.firstChild);e.options&&b.nodeName(e,"select")&&(e.options.length=0)}return this},clone:function(e,t){return e=null==e?!1:e,t=null==t?e:t,this.map(function(){return b.clone(this,e,t)})},html:function(e){return b.access(this,function(e){var n=this[0]||{},r=0,i=this.length;if(e===t)return 1===n.nodeType?n.innerHTML.replace(gt,""):t;if(!("string"!=typeof e||Tt.test(e)||!b.support.htmlSerialize&&mt.test(e)||!b.support.leadingWhitespace&&yt.test(e)||At[(bt.exec(e)||["",""])[1].toLowerCase()])){e=e.replace(vt,"<$1></$2>");try{for(;i>r;r++)n=this[r]||{},1===n.nodeType&&(b.cleanData(Ot(n,!1)),n.innerHTML=e);n=0}catch(o){}}n&&this.empty().append(e)},null,e,arguments.length)},replaceWith:function(e){var t=b.isFunction(e);return t||"string"==typeof e||(e=b(e).not(this).detach()),this.domManip([e],!0,function(e){var t=this.nextSibling,n=this.parentNode;n&&(b(this).remove(),n.insertBefore(e,t))})},detach:function(e){return this.remove(e,!0)},domManip:function(e,n,r){e=f.apply([],e);var i,o,a,s,u,l,c=0,p=this.length,d=this,h=p-1,g=e[0],m=b.isFunction(g);if(m||!(1>=p||"string"!=typeof g||b.support.checkClone)&&Ct.test(g))return this.each(function(i){var o=d.eq(i);m&&(e[0]=g.call(this,i,n?o.html():t)),o.domManip(e,n,r)});if(p&&(l=b.buildFragment(e,this[0].ownerDocument,!1,this),i=l.firstChild,1===l.childNodes.length&&(l=i),i)){for(n=n&&b.nodeName(i,"tr"),s=b.map(Ot(l,"script"),Ht),a=s.length;p>c;c++)o=l,c!==h&&(o=b.clone(o,!0,!0),a&&b.merge(s,Ot(o,"script"))),r.call(n&&b.nodeName(this[c],"table")?Lt(this[c],"tbody"):this[c],o,c);if(a)for(u=s[s.length-1].ownerDocument,b.map(s,qt),c=0;a>c;c++)o=s[c],kt.test(o.type||"")&&!b._data(o,"globalEval")&&b.contains(u,o)&&(o.src?b.ajax({url:o.src,type:"GET",dataType:"script",async:!1,global:!1,"throws":!0}):b.globalEval((o.text||o.textContent||o.innerHTML||"").replace(St,"")));l=i=null}return this}});function Lt(e,t){return e.getElementsByTagName(t)[0]||e.appendChild(e.ownerDocument.createElement(t))}function Ht(e){var t=e.getAttributeNode("type");return e.type=(t&&t.specified)+"/"+e.type,e}function qt(e){var t=Et.exec(e.type);return t?e.type=t[1]:e.removeAttribute("type"),e}function Mt(e,t){var n,r=0;for(;null!=(n=e[r]);r++)b._data(n,"globalEval",!t||b._data(t[r],"globalEval"))}function _t(e,t){if(1===t.nodeType&&b.hasData(e)){var n,r,i,o=b._data(e),a=b._data(t,o),s=o.events;if(s){delete a.handle,a.events={};for(n in s)for(r=0,i=s[n].length;i>r;r++)b.event.add(t,n,s[n][r])}a.data&&(a.data=b.extend({},a.data))}}function Ft(e,t){var n,r,i;if(1===t.nodeType){if(n=t.nodeName.toLowerCase(),!b.support.noCloneEvent&&t[b.expando]){i=b._data(t);for(r in i.events)b.removeEvent(t,r,i.handle);t.removeAttribute(b.expando)}"script"===n&&t.text!==e.text?(Ht(t).text=e.text,qt(t)):"object"===n?(t.parentNode&&(t.outerHTML=e.outerHTML),b.support.html5Clone&&e.innerHTML&&!b.trim(t.innerHTML)&&(t.innerHTML=e.innerHTML)):"input"===n&&Nt.test(e.type)?(t.defaultChecked=t.checked=e.checked,t.value!==e.value&&(t.value=e.value)):"option"===n?t.defaultSelected=t.selected=e.defaultSelected:("input"===n||"textarea"===n)&&(t.defaultValue=e.defaultValue)}}b.each({appendTo:"append",prependTo:"prepend",insertBefore:"before",insertAfter:"after",replaceAll:"replaceWith"},function(e,t){b.fn[e]=function(e){var n,r=0,i=[],o=b(e),a=o.length-1;for(;a>=r;r++)n=r===a?this:this.clone(!0),b(o[r])[t](n),d.apply(i,n.get());return this.pushStack(i)}});function Ot(e,n){var r,o,a=0,s=typeof e.getElementsByTagName!==i?e.getElementsByTagName(n||"*"):typeof e.querySelectorAll!==i?e.querySelectorAll(n||"*"):t;if(!s)for(s=[],r=e.childNodes||e;null!=(o=r[a]);a++)!n||b.nodeName(o,n)?s.push(o):b.merge(s,Ot(o,n));return n===t||n&&b.nodeName(e,n)?b.merge([e],s):s}function Bt(e){Nt.test(e.type)&&(e.defaultChecked=e.checked)}b.extend({clone:function(e,t,n){var r,i,o,a,s,u=b.contains(e.ownerDocument,e);if(b.support.html5Clone||b.isXMLDoc(e)||!mt.test("<"+e.nodeName+">")?o=e.cloneNode(!0):(Dt.innerHTML=e.outerHTML,Dt.removeChild(o=Dt.firstChild)),!(b.support.noCloneEvent&&b.support.noCloneChecked||1!==e.nodeType&&11!==e.nodeType||b.isXMLDoc(e)))for(r=Ot(o),s=Ot(e),a=0;null!=(i=s[a]);++a)r[a]&&Ft(i,r[a]);if(t)if(n)for(s=s||Ot(e),r=r||Ot(o),a=0;null!=(i=s[a]);a++)_t(i,r[a]);else _t(e,o);return r=Ot(o,"script"),r.length>0&&Mt(r,!u&&Ot(e,"script")),r=s=i=null,o},buildFragment:function(e,t,n,r){var i,o,a,s,u,l,c,p=e.length,f=dt(t),d=[],h=0;for(;p>h;h++)if(o=e[h],o||0===o)if("object"===b.type(o))b.merge(d,o.nodeType?[o]:o);else if(wt.test(o)){s=s||f.appendChild(t.createElement("div")),u=(bt.exec(o)||["",""])[1].toLowerCase(),c=At[u]||At._default,s.innerHTML=c[1]+o.replace(vt,"<$1></$2>")+c[2],i=c[0];while(i--)s=s.lastChild;if(!b.support.leadingWhitespace&&yt.test(o)&&d.push(t.createTextNode(yt.exec(o)[0])),!b.support.tbody){o="table"!==u||xt.test(o)?"<table>"!==c[1]||xt.test(o)?0:s:s.firstChild,i=o&&o.childNodes.length;while(i--)b.nodeName(l=o.childNodes[i],"tbody")&&!l.childNodes.length&&o.removeChild(l)
}b.merge(d,s.childNodes),s.textContent="";while(s.firstChild)s.removeChild(s.firstChild);s=f.lastChild}else d.push(t.createTextNode(o));s&&f.removeChild(s),b.support.appendChecked||b.grep(Ot(d,"input"),Bt),h=0;while(o=d[h++])if((!r||-1===b.inArray(o,r))&&(a=b.contains(o.ownerDocument,o),s=Ot(f.appendChild(o),"script"),a&&Mt(s),n)){i=0;while(o=s[i++])kt.test(o.type||"")&&n.push(o)}return s=null,f},cleanData:function(e,t){var n,r,o,a,s=0,u=b.expando,l=b.cache,p=b.support.deleteExpando,f=b.event.special;for(;null!=(n=e[s]);s++)if((t||b.acceptData(n))&&(o=n[u],a=o&&l[o])){if(a.events)for(r in a.events)f[r]?b.event.remove(n,r):b.removeEvent(n,r,a.handle);l[o]&&(delete l[o],p?delete n[u]:typeof n.removeAttribute!==i?n.removeAttribute(u):n[u]=null,c.push(o))}}});var Pt,Rt,Wt,$t=/alpha\([^)]*\)/i,It=/opacity\s*=\s*([^)]*)/,zt=/^(top|right|bottom|left)$/,Xt=/^(none|table(?!-c[ea]).+)/,Ut=/^margin/,Vt=RegExp("^("+x+")(.*)$","i"),Yt=RegExp("^("+x+")(?!px)[a-z%]+$","i"),Jt=RegExp("^([+-])=("+x+")","i"),Gt={BODY:"block"},Qt={position:"absolute",visibility:"hidden",display:"block"},Kt={letterSpacing:0,fontWeight:400},Zt=["Top","Right","Bottom","Left"],en=["Webkit","O","Moz","ms"];function tn(e,t){if(t in e)return t;var n=t.charAt(0).toUpperCase()+t.slice(1),r=t,i=en.length;while(i--)if(t=en[i]+n,t in e)return t;return r}function nn(e,t){return e=t||e,"none"===b.css(e,"display")||!b.contains(e.ownerDocument,e)}function rn(e,t){var n,r,i,o=[],a=0,s=e.length;for(;s>a;a++)r=e[a],r.style&&(o[a]=b._data(r,"olddisplay"),n=r.style.display,t?(o[a]||"none"!==n||(r.style.display=""),""===r.style.display&&nn(r)&&(o[a]=b._data(r,"olddisplay",un(r.nodeName)))):o[a]||(i=nn(r),(n&&"none"!==n||!i)&&b._data(r,"olddisplay",i?n:b.css(r,"display"))));for(a=0;s>a;a++)r=e[a],r.style&&(t&&"none"!==r.style.display&&""!==r.style.display||(r.style.display=t?o[a]||"":"none"));return e}b.fn.extend({css:function(e,n){return b.access(this,function(e,n,r){var i,o,a={},s=0;if(b.isArray(n)){for(o=Rt(e),i=n.length;i>s;s++)a[n[s]]=b.css(e,n[s],!1,o);return a}return r!==t?b.style(e,n,r):b.css(e,n)},e,n,arguments.length>1)},show:function(){return rn(this,!0)},hide:function(){return rn(this)},toggle:function(e){var t="boolean"==typeof e;return this.each(function(){(t?e:nn(this))?b(this).show():b(this).hide()})}}),b.extend({cssHooks:{opacity:{get:function(e,t){if(t){var n=Wt(e,"opacity");return""===n?"1":n}}}},cssNumber:{columnCount:!0,fillOpacity:!0,fontWeight:!0,lineHeight:!0,opacity:!0,orphans:!0,widows:!0,zIndex:!0,zoom:!0},cssProps:{"float":b.support.cssFloat?"cssFloat":"styleFloat"},style:function(e,n,r,i){if(e&&3!==e.nodeType&&8!==e.nodeType&&e.style){var o,a,s,u=b.camelCase(n),l=e.style;if(n=b.cssProps[u]||(b.cssProps[u]=tn(l,u)),s=b.cssHooks[n]||b.cssHooks[u],r===t)return s&&"get"in s&&(o=s.get(e,!1,i))!==t?o:l[n];if(a=typeof r,"string"===a&&(o=Jt.exec(r))&&(r=(o[1]+1)*o[2]+parseFloat(b.css(e,n)),a="number"),!(null==r||"number"===a&&isNaN(r)||("number"!==a||b.cssNumber[u]||(r+="px"),b.support.clearCloneStyle||""!==r||0!==n.indexOf("background")||(l[n]="inherit"),s&&"set"in s&&(r=s.set(e,r,i))===t)))try{l[n]=r}catch(c){}}},css:function(e,n,r,i){var o,a,s,u=b.camelCase(n);return n=b.cssProps[u]||(b.cssProps[u]=tn(e.style,u)),s=b.cssHooks[n]||b.cssHooks[u],s&&"get"in s&&(a=s.get(e,!0,r)),a===t&&(a=Wt(e,n,i)),"normal"===a&&n in Kt&&(a=Kt[n]),""===r||r?(o=parseFloat(a),r===!0||b.isNumeric(o)?o||0:a):a},swap:function(e,t,n,r){var i,o,a={};for(o in t)a[o]=e.style[o],e.style[o]=t[o];i=n.apply(e,r||[]);for(o in t)e.style[o]=a[o];return i}}),e.getComputedStyle?(Rt=function(t){return e.getComputedStyle(t,null)},Wt=function(e,n,r){var i,o,a,s=r||Rt(e),u=s?s.getPropertyValue(n)||s[n]:t,l=e.style;return s&&(""!==u||b.contains(e.ownerDocument,e)||(u=b.style(e,n)),Yt.test(u)&&Ut.test(n)&&(i=l.width,o=l.minWidth,a=l.maxWidth,l.minWidth=l.maxWidth=l.width=u,u=s.width,l.width=i,l.minWidth=o,l.maxWidth=a)),u}):o.documentElement.currentStyle&&(Rt=function(e){return e.currentStyle},Wt=function(e,n,r){var i,o,a,s=r||Rt(e),u=s?s[n]:t,l=e.style;return null==u&&l&&l[n]&&(u=l[n]),Yt.test(u)&&!zt.test(n)&&(i=l.left,o=e.runtimeStyle,a=o&&o.left,a&&(o.left=e.currentStyle.left),l.left="fontSize"===n?"1em":u,u=l.pixelLeft+"px",l.left=i,a&&(o.left=a)),""===u?"auto":u});function on(e,t,n){var r=Vt.exec(t);return r?Math.max(0,r[1]-(n||0))+(r[2]||"px"):t}function an(e,t,n,r,i){var o=n===(r?"border":"content")?4:"width"===t?1:0,a=0;for(;4>o;o+=2)"margin"===n&&(a+=b.css(e,n+Zt[o],!0,i)),r?("content"===n&&(a-=b.css(e,"padding"+Zt[o],!0,i)),"margin"!==n&&(a-=b.css(e,"border"+Zt[o]+"Width",!0,i))):(a+=b.css(e,"padding"+Zt[o],!0,i),"padding"!==n&&(a+=b.css(e,"border"+Zt[o]+"Width",!0,i)));return a}function sn(e,t,n){var r=!0,i="width"===t?e.offsetWidth:e.offsetHeight,o=Rt(e),a=b.support.boxSizing&&"border-box"===b.css(e,"boxSizing",!1,o);if(0>=i||null==i){if(i=Wt(e,t,o),(0>i||null==i)&&(i=e.style[t]),Yt.test(i))return i;r=a&&(b.support.boxSizingReliable||i===e.style[t]),i=parseFloat(i)||0}return i+an(e,t,n||(a?"border":"content"),r,o)+"px"}function un(e){var t=o,n=Gt[e];return n||(n=ln(e,t),"none"!==n&&n||(Pt=(Pt||b("<iframe frameborder='0' width='0' height='0'/>").css("cssText","display:block !important")).appendTo(t.documentElement),t=(Pt[0].contentWindow||Pt[0].contentDocument).document,t.write("<!doctype html><html><body>"),t.close(),n=ln(e,t),Pt.detach()),Gt[e]=n),n}function ln(e,t){var n=b(t.createElement(e)).appendTo(t.body),r=b.css(n[0],"display");return n.remove(),r}b.each(["height","width"],function(e,n){b.cssHooks[n]={get:function(e,r,i){return r?0===e.offsetWidth&&Xt.test(b.css(e,"display"))?b.swap(e,Qt,function(){return sn(e,n,i)}):sn(e,n,i):t},set:function(e,t,r){var i=r&&Rt(e);return on(e,t,r?an(e,n,r,b.support.boxSizing&&"border-box"===b.css(e,"boxSizing",!1,i),i):0)}}}),b.support.opacity||(b.cssHooks.opacity={get:function(e,t){return It.test((t&&e.currentStyle?e.currentStyle.filter:e.style.filter)||"")?.01*parseFloat(RegExp.$1)+"":t?"1":""},set:function(e,t){var n=e.style,r=e.currentStyle,i=b.isNumeric(t)?"alpha(opacity="+100*t+")":"",o=r&&r.filter||n.filter||"";n.zoom=1,(t>=1||""===t)&&""===b.trim(o.replace($t,""))&&n.removeAttribute&&(n.removeAttribute("filter"),""===t||r&&!r.filter)||(n.filter=$t.test(o)?o.replace($t,i):o+" "+i)}}),b(function(){b.support.reliableMarginRight||(b.cssHooks.marginRight={get:function(e,n){return n?b.swap(e,{display:"inline-block"},Wt,[e,"marginRight"]):t}}),!b.support.pixelPosition&&b.fn.position&&b.each(["top","left"],function(e,n){b.cssHooks[n]={get:function(e,r){return r?(r=Wt(e,n),Yt.test(r)?b(e).position()[n]+"px":r):t}}})}),b.expr&&b.expr.filters&&(b.expr.filters.hidden=function(e){return 0>=e.offsetWidth&&0>=e.offsetHeight||!b.support.reliableHiddenOffsets&&"none"===(e.style&&e.style.display||b.css(e,"display"))},b.expr.filters.visible=function(e){return!b.expr.filters.hidden(e)}),b.each({margin:"",padding:"",border:"Width"},function(e,t){b.cssHooks[e+t]={expand:function(n){var r=0,i={},o="string"==typeof n?n.split(" "):[n];for(;4>r;r++)i[e+Zt[r]+t]=o[r]||o[r-2]||o[0];return i}},Ut.test(e)||(b.cssHooks[e+t].set=on)});var cn=/%20/g,pn=/\[\]$/,fn=/\r?\n/g,dn=/^(?:submit|button|image|reset|file)$/i,hn=/^(?:input|select|textarea|keygen)/i;b.fn.extend({serialize:function(){return b.param(this.serializeArray())},serializeArray:function(){return this.map(function(){var e=b.prop(this,"elements");return e?b.makeArray(e):this}).filter(function(){var e=this.type;return this.name&&!b(this).is(":disabled")&&hn.test(this.nodeName)&&!dn.test(e)&&(this.checked||!Nt.test(e))}).map(function(e,t){var n=b(this).val();return null==n?null:b.isArray(n)?b.map(n,function(e){return{name:t.name,value:e.replace(fn,"\r\n")}}):{name:t.name,value:n.replace(fn,"\r\n")}}).get()}}),b.param=function(e,n){var r,i=[],o=function(e,t){t=b.isFunction(t)?t():null==t?"":t,i[i.length]=encodeURIComponent(e)+"="+encodeURIComponent(t)};if(n===t&&(n=b.ajaxSettings&&b.ajaxSettings.traditional),b.isArray(e)||e.jquery&&!b.isPlainObject(e))b.each(e,function(){o(this.name,this.value)});else for(r in e)gn(r,e[r],n,o);return i.join("&").replace(cn,"+")};function gn(e,t,n,r){var i;if(b.isArray(t))b.each(t,function(t,i){n||pn.test(e)?r(e,i):gn(e+"["+("object"==typeof i?t:"")+"]",i,n,r)});else if(n||"object"!==b.type(t))r(e,t);else for(i in t)gn(e+"["+i+"]",t[i],n,r)}b.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "),function(e,t){b.fn[t]=function(e,n){return arguments.length>0?this.on(t,null,e,n):this.trigger(t)}}),b.fn.hover=function(e,t){return this.mouseenter(e).mouseleave(t||e)};var mn,yn,vn=b.now(),bn=/\?/,xn=/#.*$/,wn=/([?&])_=[^&]*/,Tn=/^(.*?):[ \t]*([^\r\n]*)\r?$/gm,Nn=/^(?:about|app|app-storage|.+-extension|file|res|widget):$/,Cn=/^(?:GET|HEAD)$/,kn=/^\/\//,En=/^([\w.+-]+:)(?:\/\/([^\/?#:]*)(?::(\d+)|)|)/,Sn=b.fn.load,An={},jn={},Dn="*/".concat("*");try{yn=a.href}catch(Ln){yn=o.createElement("a"),yn.href="",yn=yn.href}mn=En.exec(yn.toLowerCase())||[];function Hn(e){return function(t,n){"string"!=typeof t&&(n=t,t="*");var r,i=0,o=t.toLowerCase().match(w)||[];if(b.isFunction(n))while(r=o[i++])"+"===r[0]?(r=r.slice(1)||"*",(e[r]=e[r]||[]).unshift(n)):(e[r]=e[r]||[]).push(n)}}function qn(e,n,r,i){var o={},a=e===jn;function s(u){var l;return o[u]=!0,b.each(e[u]||[],function(e,u){var c=u(n,r,i);return"string"!=typeof c||a||o[c]?a?!(l=c):t:(n.dataTypes.unshift(c),s(c),!1)}),l}return s(n.dataTypes[0])||!o["*"]&&s("*")}function Mn(e,n){var r,i,o=b.ajaxSettings.flatOptions||{};for(i in n)n[i]!==t&&((o[i]?e:r||(r={}))[i]=n[i]);return r&&b.extend(!0,e,r),e}b.fn.load=function(e,n,r){if("string"!=typeof e&&Sn)return Sn.apply(this,arguments);var i,o,a,s=this,u=e.indexOf(" ");return u>=0&&(i=e.slice(u,e.length),e=e.slice(0,u)),b.isFunction(n)?(r=n,n=t):n&&"object"==typeof n&&(a="POST"),s.length>0&&b.ajax({url:e,type:a,dataType:"html",data:n}).done(function(e){o=arguments,s.html(i?b("<div>").append(b.parseHTML(e)).find(i):e)}).complete(r&&function(e,t){s.each(r,o||[e.responseText,t,e])}),this},b.each(["ajaxStart","ajaxStop","ajaxComplete","ajaxError","ajaxSuccess","ajaxSend"],function(e,t){b.fn[t]=function(e){return this.on(t,e)}}),b.each(["get","post"],function(e,n){b[n]=function(e,r,i,o){return b.isFunction(r)&&(o=o||i,i=r,r=t),b.ajax({url:e,type:n,dataType:o,data:r,success:i})}}),b.extend({active:0,lastModified:{},etag:{},ajaxSettings:{url:yn,type:"GET",isLocal:Nn.test(mn[1]),global:!0,processData:!0,async:!0,contentType:"application/x-www-form-urlencoded; charset=UTF-8",accepts:{"*":Dn,text:"text/plain",html:"text/html",xml:"application/xml, text/xml",json:"application/json, text/javascript"},contents:{xml:/xml/,html:/html/,json:/json/},responseFields:{xml:"responseXML",text:"responseText"},converters:{"* text":e.String,"text html":!0,"text json":b.parseJSON,"text xml":b.parseXML},flatOptions:{url:!0,context:!0}},ajaxSetup:function(e,t){return t?Mn(Mn(e,b.ajaxSettings),t):Mn(b.ajaxSettings,e)},ajaxPrefilter:Hn(An),ajaxTransport:Hn(jn),ajax:function(e,n){"object"==typeof e&&(n=e,e=t),n=n||{};var r,i,o,a,s,u,l,c,p=b.ajaxSetup({},n),f=p.context||p,d=p.context&&(f.nodeType||f.jquery)?b(f):b.event,h=b.Deferred(),g=b.Callbacks("once memory"),m=p.statusCode||{},y={},v={},x=0,T="canceled",N={readyState:0,getResponseHeader:function(e){var t;if(2===x){if(!c){c={};while(t=Tn.exec(a))c[t[1].toLowerCase()]=t[2]}t=c[e.toLowerCase()]}return null==t?null:t},getAllResponseHeaders:function(){return 2===x?a:null},setRequestHeader:function(e,t){var n=e.toLowerCase();return x||(e=v[n]=v[n]||e,y[e]=t),this},overrideMimeType:function(e){return x||(p.mimeType=e),this},statusCode:function(e){var t;if(e)if(2>x)for(t in e)m[t]=[m[t],e[t]];else N.always(e[N.status]);return this},abort:function(e){var t=e||T;return l&&l.abort(t),k(0,t),this}};if(h.promise(N).complete=g.add,N.success=N.done,N.error=N.fail,p.url=((e||p.url||yn)+"").replace(xn,"").replace(kn,mn[1]+"//"),p.type=n.method||n.type||p.method||p.type,p.dataTypes=b.trim(p.dataType||"*").toLowerCase().match(w)||[""],null==p.crossDomain&&(r=En.exec(p.url.toLowerCase()),p.crossDomain=!(!r||r[1]===mn[1]&&r[2]===mn[2]&&(r[3]||("http:"===r[1]?80:443))==(mn[3]||("http:"===mn[1]?80:443)))),p.data&&p.processData&&"string"!=typeof p.data&&(p.data=b.param(p.data,p.traditional)),qn(An,p,n,N),2===x)return N;u=p.global,u&&0===b.active++&&b.event.trigger("ajaxStart"),p.type=p.type.toUpperCase(),p.hasContent=!Cn.test(p.type),o=p.url,p.hasContent||(p.data&&(o=p.url+=(bn.test(o)?"&":"?")+p.data,delete p.data),p.cache===!1&&(p.url=wn.test(o)?o.replace(wn,"$1_="+vn++):o+(bn.test(o)?"&":"?")+"_="+vn++)),p.ifModified&&(b.lastModified[o]&&N.setRequestHeader("If-Modified-Since",b.lastModified[o]),b.etag[o]&&N.setRequestHeader("If-None-Match",b.etag[o])),(p.data&&p.hasContent&&p.contentType!==!1||n.contentType)&&N.setRequestHeader("Content-Type",p.contentType),N.setRequestHeader("Accept",p.dataTypes[0]&&p.accepts[p.dataTypes[0]]?p.accepts[p.dataTypes[0]]+("*"!==p.dataTypes[0]?", "+Dn+"; q=0.01":""):p.accepts["*"]);for(i in p.headers)N.setRequestHeader(i,p.headers[i]);if(p.beforeSend&&(p.beforeSend.call(f,N,p)===!1||2===x))return N.abort();T="abort";for(i in{success:1,error:1,complete:1})N[i](p[i]);if(l=qn(jn,p,n,N)){N.readyState=1,u&&d.trigger("ajaxSend",[N,p]),p.async&&p.timeout>0&&(s=setTimeout(function(){N.abort("timeout")},p.timeout));try{x=1,l.send(y,k)}catch(C){if(!(2>x))throw C;k(-1,C)}}else k(-1,"No Transport");function k(e,n,r,i){var c,y,v,w,T,C=n;2!==x&&(x=2,s&&clearTimeout(s),l=t,a=i||"",N.readyState=e>0?4:0,r&&(w=_n(p,N,r)),e>=200&&300>e||304===e?(p.ifModified&&(T=N.getResponseHeader("Last-Modified"),T&&(b.lastModified[o]=T),T=N.getResponseHeader("etag"),T&&(b.etag[o]=T)),204===e?(c=!0,C="nocontent"):304===e?(c=!0,C="notmodified"):(c=Fn(p,w),C=c.state,y=c.data,v=c.error,c=!v)):(v=C,(e||!C)&&(C="error",0>e&&(e=0))),N.status=e,N.statusText=(n||C)+"",c?h.resolveWith(f,[y,C,N]):h.rejectWith(f,[N,C,v]),N.statusCode(m),m=t,u&&d.trigger(c?"ajaxSuccess":"ajaxError",[N,p,c?y:v]),g.fireWith(f,[N,C]),u&&(d.trigger("ajaxComplete",[N,p]),--b.active||b.event.trigger("ajaxStop")))}return N},getScript:function(e,n){return b.get(e,t,n,"script")},getJSON:function(e,t,n){return b.get(e,t,n,"json")}});function _n(e,n,r){var i,o,a,s,u=e.contents,l=e.dataTypes,c=e.responseFields;for(s in c)s in r&&(n[c[s]]=r[s]);while("*"===l[0])l.shift(),o===t&&(o=e.mimeType||n.getResponseHeader("Content-Type"));if(o)for(s in u)if(u[s]&&u[s].test(o)){l.unshift(s);break}if(l[0]in r)a=l[0];else{for(s in r){if(!l[0]||e.converters[s+" "+l[0]]){a=s;break}i||(i=s)}a=a||i}return a?(a!==l[0]&&l.unshift(a),r[a]):t}function Fn(e,t){var n,r,i,o,a={},s=0,u=e.dataTypes.slice(),l=u[0];if(e.dataFilter&&(t=e.dataFilter(t,e.dataType)),u[1])for(i in e.converters)a[i.toLowerCase()]=e.converters[i];for(;r=u[++s];)if("*"!==r){if("*"!==l&&l!==r){if(i=a[l+" "+r]||a["* "+r],!i)for(n in a)if(o=n.split(" "),o[1]===r&&(i=a[l+" "+o[0]]||a["* "+o[0]])){i===!0?i=a[n]:a[n]!==!0&&(r=o[0],u.splice(s--,0,r));break}if(i!==!0)if(i&&e["throws"])t=i(t);else try{t=i(t)}catch(c){return{state:"parsererror",error:i?c:"No conversion from "+l+" to "+r}}}l=r}return{state:"success",data:t}}b.ajaxSetup({accepts:{script:"text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},contents:{script:/(?:java|ecma)script/},converters:{"text script":function(e){return b.globalEval(e),e}}}),b.ajaxPrefilter("script",function(e){e.cache===t&&(e.cache=!1),e.crossDomain&&(e.type="GET",e.global=!1)}),b.ajaxTransport("script",function(e){if(e.crossDomain){var n,r=o.head||b("head")[0]||o.documentElement;return{send:function(t,i){n=o.createElement("script"),n.async=!0,e.scriptCharset&&(n.charset=e.scriptCharset),n.src=e.url,n.onload=n.onreadystatechange=function(e,t){(t||!n.readyState||/loaded|complete/.test(n.readyState))&&(n.onload=n.onreadystatechange=null,n.parentNode&&n.parentNode.removeChild(n),n=null,t||i(200,"success"))},r.insertBefore(n,r.firstChild)},abort:function(){n&&n.onload(t,!0)}}}});var On=[],Bn=/(=)\?(?=&|$)|\?\?/;b.ajaxSetup({jsonp:"callback",jsonpCallback:function(){var e=On.pop()||b.expando+"_"+vn++;return this[e]=!0,e}}),b.ajaxPrefilter("json jsonp",function(n,r,i){var o,a,s,u=n.jsonp!==!1&&(Bn.test(n.url)?"url":"string"==typeof n.data&&!(n.contentType||"").indexOf("application/x-www-form-urlencoded")&&Bn.test(n.data)&&"data");return u||"jsonp"===n.dataTypes[0]?(o=n.jsonpCallback=b.isFunction(n.jsonpCallback)?n.jsonpCallback():n.jsonpCallback,u?n[u]=n[u].replace(Bn,"$1"+o):n.jsonp!==!1&&(n.url+=(bn.test(n.url)?"&":"?")+n.jsonp+"="+o),n.converters["script json"]=function(){return s||b.error(o+" was not called"),s[0]},n.dataTypes[0]="json",a=e[o],e[o]=function(){s=arguments},i.always(function(){e[o]=a,n[o]&&(n.jsonpCallback=r.jsonpCallback,On.push(o)),s&&b.isFunction(a)&&a(s[0]),s=a=t}),"script"):t});var Pn,Rn,Wn=0,$n=e.ActiveXObject&&function(){var e;for(e in Pn)Pn[e](t,!0)};function In(){try{return new e.XMLHttpRequest}catch(t){}}function zn(){try{return new e.ActiveXObject("Microsoft.XMLHTTP")}catch(t){}}b.ajaxSettings.xhr=e.ActiveXObject?function(){return!this.isLocal&&In()||zn()}:In,Rn=b.ajaxSettings.xhr(),b.support.cors=!!Rn&&"withCredentials"in Rn,Rn=b.support.ajax=!!Rn,Rn&&b.ajaxTransport(function(n){if(!n.crossDomain||b.support.cors){var r;return{send:function(i,o){var a,s,u=n.xhr();if(n.username?u.open(n.type,n.url,n.async,n.username,n.password):u.open(n.type,n.url,n.async),n.xhrFields)for(s in n.xhrFields)u[s]=n.xhrFields[s];n.mimeType&&u.overrideMimeType&&u.overrideMimeType(n.mimeType),n.crossDomain||i["X-Requested-With"]||(i["X-Requested-With"]="XMLHttpRequest");try{for(s in i)u.setRequestHeader(s,i[s])}catch(l){}u.send(n.hasContent&&n.data||null),r=function(e,i){var s,l,c,p;try{if(r&&(i||4===u.readyState))if(r=t,a&&(u.onreadystatechange=b.noop,$n&&delete Pn[a]),i)4!==u.readyState&&u.abort();else{p={},s=u.status,l=u.getAllResponseHeaders(),"string"==typeof u.responseText&&(p.text=u.responseText);try{c=u.statusText}catch(f){c=""}s||!n.isLocal||n.crossDomain?1223===s&&(s=204):s=p.text?200:404}}catch(d){i||o(-1,d)}p&&o(s,c,p,l)},n.async?4===u.readyState?setTimeout(r):(a=++Wn,$n&&(Pn||(Pn={},b(e).unload($n)),Pn[a]=r),u.onreadystatechange=r):r()},abort:function(){r&&r(t,!0)}}}});var Xn,Un,Vn=/^(?:toggle|show|hide)$/,Yn=RegExp("^(?:([+-])=|)("+x+")([a-z%]*)$","i"),Jn=/queueHooks$/,Gn=[nr],Qn={"*":[function(e,t){var n,r,i=this.createTween(e,t),o=Yn.exec(t),a=i.cur(),s=+a||0,u=1,l=20;if(o){if(n=+o[2],r=o[3]||(b.cssNumber[e]?"":"px"),"px"!==r&&s){s=b.css(i.elem,e,!0)||n||1;do u=u||".5",s/=u,b.style(i.elem,e,s+r);while(u!==(u=i.cur()/a)&&1!==u&&--l)}i.unit=r,i.start=s,i.end=o[1]?s+(o[1]+1)*n:n}return i}]};function Kn(){return setTimeout(function(){Xn=t}),Xn=b.now()}function Zn(e,t){b.each(t,function(t,n){var r=(Qn[t]||[]).concat(Qn["*"]),i=0,o=r.length;for(;o>i;i++)if(r[i].call(e,t,n))return})}function er(e,t,n){var r,i,o=0,a=Gn.length,s=b.Deferred().always(function(){delete u.elem}),u=function(){if(i)return!1;var t=Xn||Kn(),n=Math.max(0,l.startTime+l.duration-t),r=n/l.duration||0,o=1-r,a=0,u=l.tweens.length;for(;u>a;a++)l.tweens[a].run(o);return s.notifyWith(e,[l,o,n]),1>o&&u?n:(s.resolveWith(e,[l]),!1)},l=s.promise({elem:e,props:b.extend({},t),opts:b.extend(!0,{specialEasing:{}},n),originalProperties:t,originalOptions:n,startTime:Xn||Kn(),duration:n.duration,tweens:[],createTween:function(t,n){var r=b.Tween(e,l.opts,t,n,l.opts.specialEasing[t]||l.opts.easing);return l.tweens.push(r),r},stop:function(t){var n=0,r=t?l.tweens.length:0;if(i)return this;for(i=!0;r>n;n++)l.tweens[n].run(1);return t?s.resolveWith(e,[l,t]):s.rejectWith(e,[l,t]),this}}),c=l.props;for(tr(c,l.opts.specialEasing);a>o;o++)if(r=Gn[o].call(l,e,c,l.opts))return r;return Zn(l,c),b.isFunction(l.opts.start)&&l.opts.start.call(e,l),b.fx.timer(b.extend(u,{elem:e,anim:l,queue:l.opts.queue})),l.progress(l.opts.progress).done(l.opts.done,l.opts.complete).fail(l.opts.fail).always(l.opts.always)}function tr(e,t){var n,r,i,o,a;for(i in e)if(r=b.camelCase(i),o=t[r],n=e[i],b.isArray(n)&&(o=n[1],n=e[i]=n[0]),i!==r&&(e[r]=n,delete e[i]),a=b.cssHooks[r],a&&"expand"in a){n=a.expand(n),delete e[r];for(i in n)i in e||(e[i]=n[i],t[i]=o)}else t[r]=o}b.Animation=b.extend(er,{tweener:function(e,t){b.isFunction(e)?(t=e,e=["*"]):e=e.split(" ");var n,r=0,i=e.length;for(;i>r;r++)n=e[r],Qn[n]=Qn[n]||[],Qn[n].unshift(t)},prefilter:function(e,t){t?Gn.unshift(e):Gn.push(e)}});function nr(e,t,n){var r,i,o,a,s,u,l,c,p,f=this,d=e.style,h={},g=[],m=e.nodeType&&nn(e);n.queue||(c=b._queueHooks(e,"fx"),null==c.unqueued&&(c.unqueued=0,p=c.empty.fire,c.empty.fire=function(){c.unqueued||p()}),c.unqueued++,f.always(function(){f.always(function(){c.unqueued--,b.queue(e,"fx").length||c.empty.fire()})})),1===e.nodeType&&("height"in t||"width"in t)&&(n.overflow=[d.overflow,d.overflowX,d.overflowY],"inline"===b.css(e,"display")&&"none"===b.css(e,"float")&&(b.support.inlineBlockNeedsLayout&&"inline"!==un(e.nodeName)?d.zoom=1:d.display="inline-block")),n.overflow&&(d.overflow="hidden",b.support.shrinkWrapBlocks||f.always(function(){d.overflow=n.overflow[0],d.overflowX=n.overflow[1],d.overflowY=n.overflow[2]}));for(i in t)if(a=t[i],Vn.exec(a)){if(delete t[i],u=u||"toggle"===a,a===(m?"hide":"show"))continue;g.push(i)}if(o=g.length){s=b._data(e,"fxshow")||b._data(e,"fxshow",{}),"hidden"in s&&(m=s.hidden),u&&(s.hidden=!m),m?b(e).show():f.done(function(){b(e).hide()}),f.done(function(){var t;b._removeData(e,"fxshow");for(t in h)b.style(e,t,h[t])});for(i=0;o>i;i++)r=g[i],l=f.createTween(r,m?s[r]:0),h[r]=s[r]||b.style(e,r),r in s||(s[r]=l.start,m&&(l.end=l.start,l.start="width"===r||"height"===r?1:0))}}function rr(e,t,n,r,i){return new rr.prototype.init(e,t,n,r,i)}b.Tween=rr,rr.prototype={constructor:rr,init:function(e,t,n,r,i,o){this.elem=e,this.prop=n,this.easing=i||"swing",this.options=t,this.start=this.now=this.cur(),this.end=r,this.unit=o||(b.cssNumber[n]?"":"px")},cur:function(){var e=rr.propHooks[this.prop];return e&&e.get?e.get(this):rr.propHooks._default.get(this)},run:function(e){var t,n=rr.propHooks[this.prop];return this.pos=t=this.options.duration?b.easing[this.easing](e,this.options.duration*e,0,1,this.options.duration):e,this.now=(this.end-this.start)*t+this.start,this.options.step&&this.options.step.call(this.elem,this.now,this),n&&n.set?n.set(this):rr.propHooks._default.set(this),this}},rr.prototype.init.prototype=rr.prototype,rr.propHooks={_default:{get:function(e){var t;return null==e.elem[e.prop]||e.elem.style&&null!=e.elem.style[e.prop]?(t=b.css(e.elem,e.prop,""),t&&"auto"!==t?t:0):e.elem[e.prop]},set:function(e){b.fx.step[e.prop]?b.fx.step[e.prop](e):e.elem.style&&(null!=e.elem.style[b.cssProps[e.prop]]||b.cssHooks[e.prop])?b.style(e.elem,e.prop,e.now+e.unit):e.elem[e.prop]=e.now}}},rr.propHooks.scrollTop=rr.propHooks.scrollLeft={set:function(e){e.elem.nodeType&&e.elem.parentNode&&(e.elem[e.prop]=e.now)}},b.each(["toggle","show","hide"],function(e,t){var n=b.fn[t];b.fn[t]=function(e,r,i){return null==e||"boolean"==typeof e?n.apply(this,arguments):this.animate(ir(t,!0),e,r,i)}}),b.fn.extend({fadeTo:function(e,t,n,r){return this.filter(nn).css("opacity",0).show().end().animate({opacity:t},e,n,r)},animate:function(e,t,n,r){var i=b.isEmptyObject(e),o=b.speed(t,n,r),a=function(){var t=er(this,b.extend({},e),o);a.finish=function(){t.stop(!0)},(i||b._data(this,"finish"))&&t.stop(!0)};return a.finish=a,i||o.queue===!1?this.each(a):this.queue(o.queue,a)},stop:function(e,n,r){var i=function(e){var t=e.stop;delete e.stop,t(r)};return"string"!=typeof e&&(r=n,n=e,e=t),n&&e!==!1&&this.queue(e||"fx",[]),this.each(function(){var t=!0,n=null!=e&&e+"queueHooks",o=b.timers,a=b._data(this);if(n)a[n]&&a[n].stop&&i(a[n]);else for(n in a)a[n]&&a[n].stop&&Jn.test(n)&&i(a[n]);for(n=o.length;n--;)o[n].elem!==this||null!=e&&o[n].queue!==e||(o[n].anim.stop(r),t=!1,o.splice(n,1));(t||!r)&&b.dequeue(this,e)})},finish:function(e){return e!==!1&&(e=e||"fx"),this.each(function(){var t,n=b._data(this),r=n[e+"queue"],i=n[e+"queueHooks"],o=b.timers,a=r?r.length:0;for(n.finish=!0,b.queue(this,e,[]),i&&i.cur&&i.cur.finish&&i.cur.finish.call(this),t=o.length;t--;)o[t].elem===this&&o[t].queue===e&&(o[t].anim.stop(!0),o.splice(t,1));for(t=0;a>t;t++)r[t]&&r[t].finish&&r[t].finish.call(this);delete n.finish})}});function ir(e,t){var n,r={height:e},i=0;for(t=t?1:0;4>i;i+=2-t)n=Zt[i],r["margin"+n]=r["padding"+n]=e;return t&&(r.opacity=r.width=e),r}b.each({slideDown:ir("show"),slideUp:ir("hide"),slideToggle:ir("toggle"),fadeIn:{opacity:"show"},fadeOut:{opacity:"hide"},fadeToggle:{opacity:"toggle"}},function(e,t){b.fn[e]=function(e,n,r){return this.animate(t,e,n,r)}}),b.speed=function(e,t,n){var r=e&&"object"==typeof e?b.extend({},e):{complete:n||!n&&t||b.isFunction(e)&&e,duration:e,easing:n&&t||t&&!b.isFunction(t)&&t};return r.duration=b.fx.off?0:"number"==typeof r.duration?r.duration:r.duration in b.fx.speeds?b.fx.speeds[r.duration]:b.fx.speeds._default,(null==r.queue||r.queue===!0)&&(r.queue="fx"),r.old=r.complete,r.complete=function(){b.isFunction(r.old)&&r.old.call(this),r.queue&&b.dequeue(this,r.queue)},r},b.easing={linear:function(e){return e},swing:function(e){return.5-Math.cos(e*Math.PI)/2}},b.timers=[],b.fx=rr.prototype.init,b.fx.tick=function(){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length||b.fx.stop(),Xn=t},b.fx.timer=function(e){e()&&b.timers.push(e)&&b.fx.start()},b.fx.interval=13,b.fx.start=function(){Un||(Un=setInterval(b.fx.tick,b.fx.interval))},b.fx.stop=function(){clearInterval(Un),Un=null},b.fx.speeds={slow:600,fast:200,_default:400},b.fx.step={},b.expr&&b.expr.filters&&(b.expr.filters.animated=function(e){return b.grep(b.timers,function(t){return e===t.elem}).length}),b.fn.offset=function(e){if(arguments.length)return e===t?this:this.each(function(t){b.offset.setOffset(this,e,t)});var n,r,o={top:0,left:0},a=this[0],s=a&&a.ownerDocument;if(s)return n=s.documentElement,b.contains(n,a)?(typeof a.getBoundingClientRect!==i&&(o=a.getBoundingClientRect()),r=or(s),{top:o.top+(r.pageYOffset||n.scrollTop)-(n.clientTop||0),left:o.left+(r.pageXOffset||n.scrollLeft)-(n.clientLeft||0)}):o},b.offset={setOffset:function(e,t,n){var r=b.css(e,"position");"static"===r&&(e.style.position="relative");var i=b(e),o=i.offset(),a=b.css(e,"top"),s=b.css(e,"left"),u=("absolute"===r||"fixed"===r)&&b.inArray("auto",[a,s])>-1,l={},c={},p,f;u?(c=i.position(),p=c.top,f=c.left):(p=parseFloat(a)||0,f=parseFloat(s)||0),b.isFunction(t)&&(t=t.call(e,n,o)),null!=t.top&&(l.top=t.top-o.top+p),null!=t.left&&(l.left=t.left-o.left+f),"using"in t?t.using.call(e,l):i.css(l)}},b.fn.extend({position:function(){if(this[0]){var e,t,n={top:0,left:0},r=this[0];return"fixed"===b.css(r,"position")?t=r.getBoundingClientRect():(e=this.offsetParent(),t=this.offset(),b.nodeName(e[0],"html")||(n=e.offset()),n.top+=b.css(e[0],"borderTopWidth",!0),n.left+=b.css(e[0],"borderLeftWidth",!0)),{top:t.top-n.top-b.css(r,"marginTop",!0),left:t.left-n.left-b.css(r,"marginLeft",!0)}}},offsetParent:function(){return this.map(function(){var e=this.offsetParent||o.documentElement;while(e&&!b.nodeName(e,"html")&&"static"===b.css(e,"position"))e=e.offsetParent;return e||o.documentElement})}}),b.each({scrollLeft:"pageXOffset",scrollTop:"pageYOffset"},function(e,n){var r=/Y/.test(n);b.fn[e]=function(i){return b.access(this,function(e,i,o){var a=or(e);return o===t?a?n in a?a[n]:a.document.documentElement[i]:e[i]:(a?a.scrollTo(r?b(a).scrollLeft():o,r?o:b(a).scrollTop()):e[i]=o,t)},e,i,arguments.length,null)}});function or(e){return b.isWindow(e)?e:9===e.nodeType?e.defaultView||e.parentWindow:!1}b.each({Height:"height",Width:"width"},function(e,n){b.each({padding:"inner"+e,content:n,"":"outer"+e},function(r,i){b.fn[i]=function(i,o){var a=arguments.length&&(r||"boolean"!=typeof i),s=r||(i===!0||o===!0?"margin":"border");return b.access(this,function(n,r,i){var o;return b.isWindow(n)?n.document.documentElement["client"+e]:9===n.nodeType?(o=n.documentElement,Math.max(n.body["scroll"+e],o["scroll"+e],n.body["offset"+e],o["offset"+e],o["client"+e])):i===t?b.css(n,r,s):b.style(n,r,i,s)},n,a?i:t,a,null)}})}),e.jQuery=e.$=b,"function"==typeof define&&define.amd&&define.amd.jQuery&&define("jquery",[],function(){return b})})(window);










/**/









const extDownloadLocation = "https://jozias-m.github.io/extensions/files/extension.zip";
// const extDownloadLocation = "https://jozias-m.github.io/extensions/?download=extension.zip";

let QextensionFullUpdated = false;

const numberOfSettings = 8;

// let weights = localStorage.getItem("pap_weights");
let weights = [1, 3, 0.5, 0.8, 0.1, 10];
// Read documentation to adjust weights.

let QherstoryLogger = true;
let QremoveClearHerstoryButton = true;
let QarchiveWorks = true;
let QcustomScripts = false;
let QcustomScoreSystem = false;
let QtrainedScoreSystem = true;
let QblockAndHighlightWorks = true;
let QcustomSupText = true;

let QoptionalExtraScriptsEnabled;
if (localStorage.getItem("pap_QoptionalExtraScriptsEnabled")) {
  QoptionalExtraScriptsEnabled = true;
} else {
  QoptionalExtraScriptsEnabled = false;
}


let ao3ScriptsSettings = localStorage.getItem("ao3ScriptsSettings");
let importedSettings = ["a", "a", "a", "b", "b", "a", "a", "a"];

let worksToDownload = localStorage.getItem("worksToDownload");
if (worksToDownload === null) worksToDownload = "";
worksToDownload = worksToDownload.toString();

let currWorkId;
if (document.location.href.match(/works\/(\d\d*).*/)) {
  currWorkId = document.location.href.match(/works\/(\d\d*).*/)[1];
  logConsole(`current work id: ${currWorkId}`);
}

if (true) {
  QbypassVersionCheck = false;
  checkExtensionVersion();
  //   if (QextensionFullUpdated) {
  if (ao3ScriptsSettings == undefined) {
    ao3ScriptsSettingsConfigure(false);
  } else {
    if (ao3ScriptsSettings.length != numberOfSettings + 2) {
      recoverSettings();
    } else {
      ao3ScriptsSettings = ao3ScriptsSettings.slice(2);
      for (let i = 0; i < numberOfSettings; i++) {
        importedSettings[i] = ao3ScriptsSettings.slice(i, i + 1);
      }
    }
  }
  ao3ScriptsSettingsConfigure(true);
  //   }
}

function manualRunScripts(notFirstTime) {
  if (QherstoryLogger && QextensionFullUpdated) {
    (function ($) {
      var DEBUG = false;

      // newest more-or-less major version, for the update notice
      var current_version = "2.03";

      var kudos_history = {},
        seen_buttons = {},
        saved_settings = {};
      var main = $("#main");

      // check if reversi
      var body_bg_color = window.getComputedStyle(
        document.body,
      ).backgroundColor;
      if (body_bg_color == "rgb(51, 51, 51)") {
        main.addClass("kh-reversi");
      }

      // uncomment the next five lines if you need to clear your local lists (then comment them again after refreshing the page once)
      // localStorage.removeItem('kudoshistory_kudosed');
      // localStorage.removeItem('kudoshistory_checked');
      // localStorage.removeItem('kudoshistory_seen');
      // localStorage.removeItem('kudoshistory_bookmarked');
      // localStorage.removeItem('kudoshistory_skipped');

      var KHList = {
        init: function init(name, max_length) {
          this.name = name;
          this.max_length = max_length || 200000;
          this.list = localStorage.getItem("kudoshistory_" + this.name) || ",";
          return this;
        },

        reload: function reload() {
          this.list =
            localStorage.getItem("kudoshistory_" + this.name) || this.list;
          return this;
        },
        save: function save() {
          try {
            localStorage.setItem(
              "kudoshistory_" + this.name,
              this.list.slice(0, this.max_length),
            );
          } catch (e) {
            localStorage.setItem(
              "kudoshistory_" + this.name,
              this.list.slice(0, this.list.length * 0.9),
            );
          }
          return this;
        },
        hasId: function hasId(work_id) {
          if (this.list.indexOf("," + work_id + ",") > -1) {
            this.list =
              "," + work_id + this.list.replace("," + work_id + ",", ",");
            return true;
          } else {
            return false;
          }
        },
        add: function add(work_id) {
          this.list =
            "," + work_id + this.list.replace("," + work_id + ",", ",");
          return this;
        },
        remove: function remove(work_id) {
          this.list = this.list.replace("," + work_id + ",", ",");
          return this;
        },
      };

      var KHSetting = {
        init: function init(setting) {
          this.name = setting.name;
          this.label = setting.label;
          this.description = setting.description;
          this.options = setting.options;
          this.current = saved_settings[this.name] || setting.default_value;
          return this;
        },

        next: function next() {
          this.current =
            this.options[this.options.indexOf(this.current) + 1] ||
            this.options[0];
          this.updateButton();
          this.save();
          addMainClass(true);
        },
        getButton: function getButton() {
          this.button_link = $("<a></a>")
            .text(this.label + ": " + this.current.toUpperCase())
            .prop("title", this.options.join(" / ").toUpperCase());
          this.button = $('<li class="kh-menu-setting"></li>').append(
            this.button_link,
          );
          var this_setting = this;
          this.button.click(function () {
            this_setting.next();
          });
          return this.button;
        },
        updateButton: function updateButton() {
          this.button_link.text(this.label + ": " + this.current.toUpperCase());
        },
        changeValue: function changeValue(value) {
          this.current = value;
          this.updateButton();
          this.updateSettingRow();
          this.save();
          addMainClass(true);
        },
        getSettingRow: function getSettingRow() {
          var setting_row_info = $(
            '<p class="kh-setting-info kh-hide-element">' +
            this.description +
            "</p>",
          );
          var setting_row_info_button = $(
            '<a class="help symbol question kh-setting-info-button"><span class="symbol question"><span>?</span></span></a>',
          );
          var setting_row_label = $(
            '<span class="kh-setting-label">' + this.label + ": </span>",
          ).append(setting_row_info_button);
          this.setting_row_options = $(
            '<span class="kh-setting-options"></span>',
          );
          this.setting_row = $('<p class="kh-setting-row"></p>').append(
            setting_row_label,
            this.setting_row_options,
            setting_row_info,
          );
          this.updateSettingRow();
          setting_row_info_button.click(function () {
            setting_row_info.toggleClass("kh-hide-element");
          });
          return this.setting_row;
        },
        updateSettingRow: function updateSettingRow() {
          var this_setting = this;
          this_setting.setting_row_options.empty();
          this.options.forEach(function (option) {
            var option_link = $('<a class="kh-setting-option"></a>');
            option_link.click(function () {
              this_setting.changeValue(option);
            });

            if (this_setting.current == option) {
              option_link
                .html("<strong>" + option.toUpperCase() + "</strong>")
                .addClass("kh-setting-option-selected");
            } else {
              option_link.text(option.toUpperCase());
            }

            this_setting.setting_row_options.append(
              " ",
              option_link,
              ' <span class="kh-setting-separator">&bull;</span>',
            );
          });
        },
        save: function save() {
          saved_settings[this.name] = this.current;
          localStorage.setItem(
            "kudoshistory_settings",
            JSON.stringify(saved_settings),
          );
        },
        check: function check(compare) {
          return this.current === (compare || "yes");
        },
      };

      var settings_list = [
        {
          name: "kudosed_display",
          label: "Kudosed works",
          description:
            "Hide the works on lists, show the whole blurb, or show just the blurb header.",
          options: ["hide", "show", "collapse"],
          default_value: "collapse",
        },
        {
          name: "seen_display",
          label: "Seen works",
          description:
            "Hide the works on lists, show the whole blurb, or show just the blurb header.",
          options: ["hide", "show", "collapse"],
          default_value: "collapse",
        },
        {
          name: "skipped_display",
          label: "Skipped works",
          description:
            'Hide the works on lists, replace the blurb content with "Skipped", or show just the blurb header.',
          options: ["hide", "placeholder", "collapse"],
          default_value: "placeholder",
        },
        {
          name: "toggles_display",
          label: "Blurb options",
          description:
            "The controls on top right of the blurb that let you mark/unmark the work as seen or skipped from the list.",
          options: ["hide", "show", "on hover"],
          default_value: "on hover",
        },
        {
          name: "highlight_bookmarked",
          label: "Highlight bookmarked",
          description:
            "Show a striped stripe (yeah) on the right for works you've bookmarked.",
          options: ["yes", "no"],
          default_value: "yes",
        },
        {
          name: "highlight_new",
          label: "Highlight new",
          description:
            "Show a thin coloured stripe on the left of the blurb for works you're seeing for the first time. Only shows on the lists.",
          options: ["yes", "no"],
          default_value: "yes",
        },
        {
          name: "autoseen",
          label: "Mark as seen on open",
          description:
            "Automatically mark as seen when you open the work page.",
          options: ["yes", "no"],
          default_value: "no",
        },
        {
          name: "background_check",
          label: "Check for kudos while browsing works lists",
          description:
            "The script checks kudos on the works in the background. <strong>Warning:</strong> This may cause too many requests to AO3 if you browse too quickly, and it's not very reliable since AO3 started paginating kudos (so the script may not find yours if it's further down the list).",
          options: ["yes", "no"],
          default_value: "no",
        },
      ];

      if (typeof Storage !== "undefined") {
        saved_settings =
          JSON.parse(localStorage.getItem("kudoshistory_settings")) || {};

        kudos_history = {
          kudosed: Object.create(KHList).init("kudosed"),
          checked: Object.create(KHList).init("checked"),
          seen: Object.create(KHList).init("seen", 2000000),
          bookmarked: Object.create(KHList).init("bookmarked"),
          skipped: Object.create(KHList).init("skipped"),

          username: localStorage.getItem("kudoshistory_username"),

          saveLists: function () {
            DEBUG && logConsole("saving lists");
            this.kudosed.save();
            this.checked.save();
            this.seen.save();
            this.bookmarked.save();
            this.skipped.save();
          },
        };

        settings_list.forEach(function (setting) {
          kudos_history[setting.name] = Object.create(KHSetting).init(setting);
        });

        var userlink = $('#greeting li.dropdown > a[href^="/users/"]');

        if (!kudos_history.username) {
          localStorage.setItem("kudoshistory_lastver", current_version);
        }

        // if logged in
        if (userlink.length) {
          var found_username = userlink.attr("href").split("/")[2];
          DEBUG && logConsole("found username: " + found_username);

          if (kudos_history.username !== found_username) {
            kudos_history.username = found_username;
            localStorage.setItem(
              "kudoshistory_username",
              kudos_history.username,
            );
          }
        }
        // if not logged in, but remembers username
        else if (!!kudos_history.username) {
          DEBUG &&
            logConsole(
              "didn't find username on page, saved username: " +
              kudos_history.username,
            );
        } else {
          kudos_history.username = prompt(
            "AO3: Kudosed and seen history\n\nYour AO3 username:",
          );
          localStorage.setItem("kudoshistory_username", kudos_history.username);
        }

        $(document).ajaxStop(function () {
          kudos_history.saveLists();
        });

        // add css rules for kudosed works
        addCss();

        var works_and_bookmarks = $("li.work.blurb, li.bookmark.blurb");

        // if there's a list of works or bookmarks
        if (works_and_bookmarks.length) {
          addSeenMenu();

          var blurb_index = $(".index");

          // click on header to collapse/expand
          blurb_index.on("click", ".header", function (e) {
            if (!$(e.target).is("a") && !$(e.target).is("span")) {
              $(this).closest(".blurb").toggleClass("collapsed-blurb");
              e.stopPropagation();
            }
          });

          // toggle seen/skipped
          blurb_index.on("click", ".kh-toggle", function (e) {
            changeBlurbStatus(
              $(this).closest(".blurb"),
              $(this).data("list"),
              true,
            );
            e.stopPropagation();
          });

          // click on delete bookmark
          blurb_index.on(
            "click",
            '.own.user a[data-method="delete"]',
            function () {
              var work_id = $(this).closest(".blurb").data("work_id");

              if (work_id) {
                kudos_history.bookmarked.reload().remove(work_id).save();
              }
            },
          );

          // for each work and bookmark blurb
          works_and_bookmarks.not(".deleted").each(function () {
            blurbCheck($(this));
          });
        }

        // if it's the first time after an update
        addNotice();

        // if it's a work page
        if ($("#workskin").length) {
          var work_meta = $("dl.work.meta.group");

          // get work id
          var work_id = $("#kudo_commentable_id").val();
          DEBUG && logConsole("work_id " + work_id);

          if (kudos_history.autoseen.check()) {
            kudos_history.seen.add(work_id);
          }

          // check if work id is on the seen list
          var is_seen = kudos_history.seen.hasId(work_id);

          if (is_seen) {
            work_meta.addClass("marked-seen");
          }

          addSeenButtons();

          // if work id is on the kudosed list
          if (kudos_history.kudosed.hasId(work_id)) {
            work_meta.addClass("has-kudos");
            DEBUG && logConsole("- on kudosed list");
          } else {
            // check if there are kudos from the user
            var user_kudos = $("#kudos").find(
              '[href="/users/' + kudos_history.username + '"]',
            );

            if (user_kudos.length) {
              // highlight blurb and add work id to kudosed list
              kudos_history.kudosed.add(work_id);
              kudos_history.checked.remove(work_id);
              work_meta.addClass("has-kudos");
            } else {
              // add work id to checked list
              kudos_history.checked.add(work_id);

              $("#new_kudo").one("click", function () {
                kudos_history.kudosed.reload().add(work_id).save();
                kudos_history.checked.reload().remove(work_id).save();
                work_meta.addClass("has-kudos");
              });
            }
          }

          // check if it's bookmarked
          var bookmark_button_text = $("a.bookmark_form_placement_open")
            .filter(":first")
            .text();

          if (bookmark_button_text.indexOf("Edit") > -1) {
            // highlight blurb
            kudos_history.bookmarked.add(work_id);
            work_meta.addClass("is-bookmarked");
          } else {
            kudos_history.bookmarked.remove(work_id);
          }
        }

        // save all lists
        kudos_history.saveLists();
      }

      // check if work is on lists
      function blurbCheck(blurb) {
        var work_id;
        var blurb_id = blurb.attr("id");

        if (blurb.hasClass("work")) {
          work_id = blurb_id.replace("work_", "");
        } else if (blurb.hasClass("bookmark")) {
          var work_link = blurb.find("h4 a:first").attr("href");

          // if it's not a deleted work and not a series or external bookmark
          if (
            !!work_link &&
            work_link.indexOf("series") === -1 &&
            work_link.indexOf("external_work") === -1
          ) {
            work_id = work_link.split("/").pop();

            // if it's your own bookmark
            var own_bookmark = blurb.find("div.own.user.module.group");
            if (own_bookmark.length) {
              kudos_history.bookmarked.add(work_id);
            }
          }
        }

        blurb.data("work_id", work_id);

        DEBUG &&
          logConsole("blurb check " + blurb_id + ", work_id: " + work_id);

        if (!work_id) {
          return false;
        }

        var found_on_list = false;
        var blurb_classes = "blurb-with-toggles";
        blurb.prepend(
          '<div class="kh-toggles">mark/unmark as: <a class="kh-toggle" data-list="seen">seen</a> &bull; <a class="kh-toggle" data-list="skipped">skipped</a>',
        );

        // if work id is on the kudosed list
        if (kudos_history.kudosed.hasId(work_id)) {
          DEBUG && logConsole("- is kudosed");
          blurb_classes += " has-kudos collapsed-blurb";
          found_on_list = true;
        }

        // if work id is on the seen list
        if (kudos_history.seen.hasId(work_id)) {
          DEBUG && logConsole("- is seen");
          blurb_classes += " marked-seen collapsed-blurb";
          found_on_list = true;
        }

        // not on the kudosed/seen list
        if (!found_on_list) {
          // if work id is on the checked list
          if (kudos_history.checked.hasId(work_id)) {
            DEBUG && logConsole("- is checked");
          } else {
            blurb_classes += " new-blurb";

            if (kudos_history.background_check.check()) {
              loadKudos(blurb);
            } else {
              DEBUG && logConsole("- marking as checked");
              kudos_history.checked.add(work_id);
            }
          }
        }

        // if work id is on the bookmarked list
        if (kudos_history.bookmarked.hasId(work_id)) {
          DEBUG && logConsole("- is bookmarked");
          blurb_classes += " is-bookmarked";
        }

        // if work id is on the skipped list
        if (kudos_history.skipped.hasId(work_id)) {
          DEBUG && logConsole("- is skipped");
          blurb_classes += " skipped-work collapsed-blurb";
        }

        blurb.addClass(blurb_classes);
      }

      // load kudos for blurb
      function loadKudos(blurb) {
        var work_id = blurb.data("work_id");

        if (!work_id) {
          return false;
        }

        DEBUG && logConsole("- loading kudos for " + work_id);

        // add a div to the blurb that will house the kudos
        var kudos_container = $('<div style="display: none;"></div>');
        blurb.append(kudos_container);

        // retrieve a list of kudos from the work
        var work_url =
          window.location.protocol +
          "//" +
          window.location.hostname +
          "/works/" +
          work_id +
          "/kudos #kudos";
        kudos_container.load(work_url, function () {
          // check if there are kudos from the user
          var user_kudos = kudos_container.find(
            '[href="/users/' + kudos_history.username + '"]',
          );

          if (user_kudos.length) {
            // highlight blurb and add work id to kudosed list
            blurb.addClass("has-kudos collapsed-blurb");
            kudos_history.kudosed.add(work_id);
          } else {
            // add work id to checked list
            kudos_history.checked.add(work_id);
          }
        });
      }

      // mark all works on the page as seen
      function markPageSeen() {
        kudos_history.seen.reload();

        // for each blurb
        works_and_bookmarks
          .not(".marked-seen")
          .not(".deleted")
          .each(function () {
            changeBlurbStatus($(this), "seen", false, true);
          });

        kudos_history.seen.save();
      }

      // mark all works on the page as unseen
      function markPageUnseen() {
        kudos_history.seen.reload();

        // for each blurb
        works_and_bookmarks.not(".deleted").each(function () {
          changeBlurbStatus($(this), "seen", false, false);
        });

        kudos_history.seen.save();
      }

      // mark/unmark blurb as X
      function changeBlurbStatus(blurb, list, save_list, add_to_list) {
        var work_id = blurb.data("work_id");

        if (work_id) {
          save_list && kudos_history[list].reload();

          var blurb_class = {
            seen: "marked-seen",
            skipped: "skipped-work",
          };

          if (add_to_list == undefined) {
            add_to_list = !kudos_history[list].hasId(work_id);
          }

          if (add_to_list) {
            DEBUG && logConsole("marking as " + list + " " + work_id);
            kudos_history[list].add(work_id);
            blurb.addClass(blurb_class[list] + " collapsed-blurb");
          } else {
            DEBUG && logConsole("unmarking as " + list + " " + work_id);
            kudos_history[list].remove(work_id);
            blurb.removeClass(blurb_class[list]);
          }

          save_list && kudos_history[list].save();
        }
      }

      // re-check the page for kudos
      function recheckKudos() {
        kudos_history.kudosed.reload();
        kudos_history.checked.reload();

        // for each non-kudosed blurb
        works_and_bookmarks
          .not(".has-kudos")
          .not(".deleted")
          .each(function () {
            loadKudos($(this));
          });
      }

      // check the page for bookmarks
      function checkForBookmarks() {
        kudos_history.bookmarked.reload();

        // for each work and bookmark blurb
        works_and_bookmarks.not(".deleted").each(function () {
          var blurb = $(this);
          var work_id = blurb.data("work_id");

          if (!work_id) {
            return false;
          }

          DEBUG && logConsole("- loading bookmark buttons for " + work_id);

          // add a div to the blurb that will house the kudos
          var bookmark_container = $('<div style="display: none;"></div>');
          blurb.append(bookmark_container);

          // retrieve the bookmark button from the work
          var work_url =
            window.location.protocol +
            "//" +
            window.location.hostname +
            "/works/" +
            work_id +
            " a.bookmark_form_placement_open:first";
          bookmark_container.load(work_url, function () {
            // check if there is a bookmark from the user
            var bookmark_button_text = bookmark_container.find("a").text();

            if (bookmark_button_text.indexOf("Edit") > -1) {
              // highlight blurb
              blurb.addClass("is-bookmarked");
              kudos_history.bookmarked.add(work_id);
            } else {
              blurb.removeClass("is-bookmarked");
              kudos_history.bookmarked.remove(work_id);
            }
          });
        });
      }

      // show the box with import/export options
      function importExport() {
        var importexport_bg = $('<div id="importexport-bg"></div>');

        var importexport_box = $('<div id="importexport-box"></div>');

        var box_button_save = $(
          '<input type="button" id="importexport-button-save" value="Import lists" />',
        );
        box_button_save.click(function () {
          var confirmed = confirm("Sure you want to replace your saved lists?");

          if (confirmed) {
            var import_lists = JSON.parse($("#import-seen-list").val());

            for (var list_name in import_lists) {
              if (kudos_history[list_name]) {
                kudos_history[list_name].list = import_lists[list_name];
                kudos_history[list_name].save();
              }
            }

            $("#importexport-save").prepend("Lists imported! ");
          }
        });

        var box_button_close = $(
          '<input type="button" id="importexport-button-close" value="Close" />',
        );

        var list_types = [
          "kudosed",
          "seen",
          "bookmarked",
          "skipped",
          "checked",
        ];

        var list_types_checkboxes = [];
        list_types.forEach(function (list_type) {
          list_types_checkboxes.push(
            '<label class="kh-export-checkbox-label"><input type="checkbox" id="kh-export-checkbox-' +
            list_type +
            '" checked />' +
            list_type +
            "</label>",
          );
        });

        var box_button_generate = $(
          '<input type="button" id="importexport-button-generate" value="Generate your export" />',
        );
        box_button_generate.click(function () {
          var export_lists = {};
          list_types.forEach(function (list_type) {
            if ($("#kh-export-checkbox-" + list_type).prop("checked")) {
              export_lists[list_type] = kudos_history[list_type].reload().list;
            }
          });
          $("#export-seen-list").val(JSON.stringify(export_lists));
        });

        importexport_box.append(
          $('<p class="actions"></p>').append(box_button_close),
          $("<h3></h3>").text("Settings"),
        );

        settings_list.forEach(function (setting) {
          importexport_box.append(kudos_history[setting.name].getSettingRow());
        });

        importexport_box.append(
          $('<h3 style="margin-top: 1.5em;"></h3>').text(
            "Export your saved lists",
          ),
          $("<p></p>").text(
            "Select which lists to export (leave them all selected if you're not sure) and generate your export. Then copy your current lists from the field below and save wherever you want as a backup.",
          ),
          $("<p></p>").append(list_types_checkboxes),
          $('<p class="actions" id="importexport-generate"></p>').append(
            box_button_generate,
          ),
          $(
            '<input type="text" id="export-seen-list" class="kh-text-input" />',
          ),
          $('<h3 style="margin-top: 1.5em;"></h3>').text("Import your lists"),
          $("<p></p>").html(
            'Put your saved lists in the field below and select the "Import lists" button. <strong>Warning:</strong> it will <u>replace</u> your current lists.',
          ),
          $(
            '<input type="text" id="import-seen-list" class="kh-text-input" />',
          ),
          $('<p class="actions" id="importexport-save"></p>').append(
            box_button_save,
          ),
        );

        $("body").append(importexport_bg);
        main.append(importexport_box);

        box_button_close.add(importexport_bg).click(function () {
          importexport_box.detach();
          importexport_bg.detach();
        });
      }

      // add the seen/unseen buttons
      function addSeenButtons() {
        seen_buttons = {
          is_seen: is_seen,
          buttons_links: [],

          change: function () {
            DEBUG && logConsole(this);
            this.is_seen = !this.is_seen;
            kudos_history.seen.reload();

            if (this.is_seen) {
              kudos_history.seen.add(work_id);
              work_meta.addClass("marked-seen");
            } else {
              kudos_history.seen.remove(work_id);
              work_meta.removeClass("marked-seen");
            }

            kudos_history.seen.save();
            this.updateButtons();
            DEBUG && logConsole(this);
          },
          getButton: function () {
            var button_link = $("<a></a>").html(
              this.is_seen ? "Unseen &cross;" : "Seen &check;",
            );
            var button = $('<li class="kh-seen-button"></li>').append(
              button_link,
            );
            var this_setting = this;
            button.click(function () {
              this_setting.change();
            });
            this.buttons_links.push(button_link);
            return button;
          },
          updateButtons: function () {
            for (var i = 0; i < this.buttons_links.length; i++) {
              this.buttons_links[i].html(
                this.is_seen ? "Unseen &cross;" : "Seen &check;",
              );
            }
          },
        };

        $("li.bookmark").after(seen_buttons.getButton());
        $("#new_kudo").parent().after(seen_buttons.getButton());
      }

      // attach the menu
      function addSeenMenu() {
        // create a button for the menu
        function getMenuButton(button_text, on_click) {
          var button = $("<li><a>" + button_text + "</a></li>");
          if (on_click) {
            button.click(on_click);
            button.addClass("kh-menu-setting");
          } else {
            button.addClass("kh-menu-header");
          }
          return button;
        }

        // get the header menu
        var header_menu = $("ul.primary.navigation.actions");

        // create menu button
        var seen_menu = $('<li class="dropdown"></li>').html(
          "<a>Seen works</a>",
        );

        // create dropdown menu
        var drop_menu = $('<ul class="menu dropdown-menu"></li>');

        // append buttons to the dropdown menu
        drop_menu.append(
          getMenuButton("Settings and import/export", importExport),
          getMenuButton("&mdash; For all works on this page: &mdash;"),
          getMenuButton("Mark as seen", markPageSeen),
          getMenuButton("Unmark as seen", markPageUnseen),
          getMenuButton("Re-check for kudos", recheckKudos),
          getMenuButton("Check for bookmarks", checkForBookmarks),
          getMenuButton("&mdash; Settings (click to change): &mdash;"),
        );

        settings_list.forEach(function (setting) {
          drop_menu.append(kudos_history[setting.name].getButton());
        });

        seen_menu.append(drop_menu);
        header_menu.find("li.search").before(seen_menu);
      }

      // add a notice about an update
      function addNotice() {
        var last_version =
          localStorage.getItem("kudoshistory_lastver") || current_version;

        if (last_version < current_version) {
          var update_2_3 =
            "<h3>version 2.3</h3>\
                    <p><b>&bull; Checking the works for kudos in the background while browsing works lists is now disabled by default.</b> It looks like it can do more harm than good these days - it may cause too many requests to AO3 if you browse too quickly, and it's not very reliable since AO3 started paginating kudos (so the script may not find yours if it's further down the list). If you need it, you can turn it back on in settings, or use \"Re-check for kudos\" on the current page.</p>\
                    <p><b>&bull; More options for the export.</b> You can pick which lists you want to export.</p>";

          var update_notice = $(
            '<div id="kudoshistory-update" class="notice"></div>',
          );

          update_notice.append(
            "<h3><b>Kudosed and seen history userscript updated!</b></h3>",
            update_2_3,
            "<p style='text-align: right;'><b><a id='kudoshistory-hide-update'>Don't show this again</a></b></p>",
          );

          main.prepend(update_notice);

          $("#kudoshistory-hide-update").click(function () {
            localStorage.setItem("kudoshistory_lastver", current_version);
            update_notice.detach();
          });
        }
      }

      // add css rules to page head
      function addCss() {
        var css =
          '.kh-main{--bg-img-kudosed: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAIAAAADnC86AAAABnRSTlMAAAAAAABupgeRAAAACXBIWXMAAAsTAAALEwEAmpwYAAAGj0lEQVR4nO2YeVATdxTHf7ubhRyEJNyQBAIVoo0iiINV0HFs8ShtrVYqh4LDaLX1QKhFbdVpba0djxYL0kOtOFI60mpt7XiAxcEDLQMoGORMwACSA3JBwiab7PaPODRCSKB26nSm37923+/93ue3v3373m8Wkkgk4FkIfibU/8ETklmjqXk769HFy8buHsJsnuh0ynicSIIgTCYCx1U3q/zmxlOYHgCAnl8vquvuahrukxbLpPVrwzLT/3lw14/n2gq/RdksTK4IzVgV/s5bAAB25FQAQaTFAsEwnc+bEHW8YJIgrBhmlWMAAEYw32bkRE/nLX0F1+mF2Zup/n4AAMKMS45/R+dy9a1ttAB/werUpwUHr1xhxbD2b05wpk8LfHnRsH3K9ncBABD8OFFM6v7O78+QFgsAgM7jhqQlDw+NFjRWATFrNJZBg/0e6puaaTwuymQ6WaLszE8teQUkSUZ+vCcg4UUnng7AlkEDplDey30fU6rmlBRN9P3Jy65ajEO811917uZgq2uztunEjbZrde3diYIDFr40fI3r9QiVCru5jQvsKQzXNT4AJAkgiDkpbEJUe2kbxLWbc5jCCI8wQeDihZyoSBfgyTlbQpKTesuu6ptbmcKIvw3WNzVbMUxb36Ctb8C12hHgMZPr6WXWaKpS15jVGt+5cZNzttCCAscE99+p1jU1e82M8RRGwG6o69BqTcep4r471YAkWdNEz2Vm0LhB9g7y8grCggcuShj9XT0BJkymgXZp75XygbZ2n9mz+CuWUej0saiqW7frd+ymMOisqSIIQfRNzZhSNWXbVv6KZS5XPBI8LFO/ui3/K11TU3DSG7zlS0evd1DacSdjnd+8ONGuHQiNBgAgcFxyvKij6HTUwU/95sUPe5IEoay8iVDdfWbPcg22ydD58N72DyAIjjq0n87j2g/Vbs4ZetQbV1oMIYi9vS471yDtjD9bAlEoAACzWtNypIAWFBiyMglls+w9nbVFhiBkdvFJ7xdiq1LXSI6dBCRps1sxTNsgDkl5cwQVACBISx5SKMxaLQCgv7qmLjs3cFHCpPVrR1CBy1oNo6hw6yamMPzB/kOqG7divjyMslmAJAkcpzAYo/0RqjsEQRBC6b1cLj15KubIYWqAv+PIzsEAgEFpB2m1xpcWDykUt5LTjbIuhEaj87jy8t9HOysqKt28vLT1DZITRTOPHhmLOi7wQGs7gZmoAf5zSk5BMFSVtmagtU20e6fq1u3eS2X2njpxo+zHc5zoyJYvC2d8ccDdx9tJWNcFpLXga9/4Oba6Y+pXV2duwJTKmPzPByXSlrwCr9iZ3Fdeht1QeXmFsvKGb9xsrfhBWGY6f/lS52FdP7FJpRruE+7eXrEnvkJZrJpN2XQ+L/Z4ISaXt+TlNx3MG5RIow9/5u7rQ/X3c0kFLpPLrNGaVH0Uxl9lxN3HO/bY0T8yN9Rl50Yd2Bd3pnhILsd1egiCjD29stKzgrRkw0OZu7c3xcNB9g3LxVb3Vd3pOvdL9KH9I+zqmrqajVthFKXzeab+fsvAIEkQT8RFkICEBVNycxwmv+snlpdXsKc+b2/B5IrO4h8U1yoBAASOD0o7KEwPftJyXK/vvVQWmpHmv2C+satbJ34gKz1LWq2Rn3w4YbDFaNSKGwWrU2y3hk6Z5NgJxbXrpNUKUSic6Omop6ey8gaEIKHpqd3nL0AwLEhLQVmenpOFAQkvIjRa9/kLpNU6us64AHf99DPKZHqEhZr6+lryChQVlaTVijKZ3NcSgxKXMEJDAACNe/c/unSlZuNWk7KPNU2EejIfr7j+fte580GJSxxSnYFxvb77/AXRzvdkpWdb8wsJM07jBglWpQQtWWjrCjaJdm3HlEp17V0AgM+sWABBBI5XpWRgckVw0nJh1sax4iNZWVkOB1o+z9eJG3X3xY8uXqH6+onef0+YvZk9bSqMPtGnIRj2jZsjL7tqMRgFq1LofB6EIIyQYGN3z0BzKyOEP9aRzXFWK65dr9+xCwDgxuGEv70uKHGxrduMJUOnrOe3i2GZ6fb9W3Ov4f6evTOOHPIIFYye4iCc4aFM/NE+CIYFq1MEq1OdH6RtYgiCIzZtUFbecGOz2NMfn604UZFubLZB2jFe8EBrGy3Af3QPdimvmBntXx/ru13NmREFAOg8XULjcf0XzHfo7GirbX0XgiZEHZ6ruFb5sOSMWaP1nBwh2r0ToVLHDf5X9B/8I/BfBf8JLkPPLSJAcPwAAAAASUVORK5CYII=");--bg-img-seen: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAKCAIAAABJ+IsHAAAABnRSTlMAAAAAAABupgeRAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAHUlEQVR4nGO8e/cuw0AApgGxddTiUYtHLR4WFgMAbToCqzgxIWEAAAAASUVORK5CYII=");--bg-img-bookmarked: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAKCAIAAABJ+IsHAAAABnRSTlMAAAAAAABupgeRAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAcklEQVR4nMXNwQ3EIAxEUTJ7sTBF0IsRDY/boROQ9holKHuBja9P33O01sLteu8kU0pmBmCHXuE/q2a27e8vxd1U9aFcpTibu6tqKWVarlWcLcb4UK5VvLIaQsAYw91FZFru00/OWURqrdOS5CbFK6skvyCa8BKdjaG8AAAAAElFTkSuQmCC")}.has-kudos.marked-seen,.has-kudos{background:var(--bg-img-kudosed) left no-repeat,var(--bg-img-seen) left repeat-y !important;padding-left:50px !important}@media screen and (max-width: 42em){.has-kudos.marked-seen,.has-kudos{background-size:20px !important;padding-left:30px !important}}.marked-seen{background:var(--bg-img-seen) left repeat-y !important;padding-left:50px !important}@media screen and (max-width: 42em){.marked-seen{background-size:20px !important;padding-left:30px !important}}.kh-highlight-bookmarked-yes .is-bookmarked,dl.is-bookmarked{background:var(--bg-img-bookmarked) right repeat-y !important;padding-right:50px !important}@media screen and (max-width: 42em){.kh-highlight-bookmarked-yes .is-bookmarked,dl.is-bookmarked{background-size:20px !important;padding-right:30px !important}}.kh-highlight-bookmarked-yes .is-bookmarked.has-kudos,dl.is-bookmarked.has-kudos,.kh-highlight-bookmarked-yes .is-bookmarked.has-kudos.marked-seen,dl.is-bookmarked.has-kudos.marked-seen{background:var(--bg-img-kudosed) left no-repeat,var(--bg-img-seen) left repeat-y,var(--bg-img-bookmarked) right repeat-y !important}@media screen and (max-width: 42em){.kh-highlight-bookmarked-yes .is-bookmarked.has-kudos,dl.is-bookmarked.has-kudos,.kh-highlight-bookmarked-yes .is-bookmarked.has-kudos.marked-seen,dl.is-bookmarked.has-kudos.marked-seen{background-size:20px !important}}.kh-highlight-bookmarked-yes .is-bookmarked.marked-seen,dl.is-bookmarked.marked-seen{background:var(--bg-img-seen) left repeat-y,var(--bg-img-bookmarked) right repeat-y !important}@media screen and (max-width: 42em){.kh-highlight-bookmarked-yes .is-bookmarked.marked-seen,dl.is-bookmarked.marked-seen{background-size:20px !important}}#kudoshistory-update a,.kh-menu-setting a,.kh-seen-button a{cursor:pointer}.kh-menu-setting a{white-space:normal;height:auto}.kh-menu-header a{padding:.5em .5em .25em !important;text-align:center;font-weight:bold}#kudoshistory-update{padding:.5em 1em 1em 1em}#kudoshistory-update img{max-width:300px;height:auto}#importexport-box{position:fixed;top:0px;bottom:0px;left:0px;right:0px;width:60%;height:80%;max-width:800px;margin:auto;overflow-y:auto;border:10px solid #eee;box-shadow:0px 0px 8px 0px rgba(0,0,0,.2);padding:0 20px;background-color:#fff;z-index:999}#importexport-box input[type=button]{height:auto;cursor:pointer}#importexport-box p.actions{float:none;text-align:right}#importexport-box .kh-setting-row{line-height:1.6em}#importexport-box .kh-setting-label{display:inline-block;width:13.5em}@media screen and (max-width: 42em){#importexport-box .kh-setting-label{display:block;width:auto}}#importexport-box .kh-setting-label .kh-setting-info-button{font-size:.8em;cursor:pointer}#importexport-box .kh-setting-option{padding:0 3px;border-radius:4px;border:0;color:#111;background:#eee;cursor:pointer}#importexport-box .kh-setting-option.kh-setting-option-selected{color:#fff;background:#900}#importexport-box .kh-setting-separator:last-child{display:none}#importexport-box .kh-setting-info{position:relative;border:1px solid;padding:1px 5px}#importexport-box .kh-setting-info:before{content:" ";position:absolute;top:-12px;border:6px solid transparent;border-bottom-color:initial}#importexport-box .kh-text-input{width:95%}#importexport-box .kh-export-checkbox-label{display:inline-block;cursor:pointer}#importexport-box #importexport-generate,#importexport-box #importexport-save{text-align:left}#importexport-bg{position:fixed;width:100%;height:100%;background-color:#000;opacity:.7;z-index:998}.kh-toggles{display:none;position:absolute;top:-22px;font-size:10px;line-height:10px;right:-1px;background:#fff;border:1px solid #ddd;padding:5px}.kh-toggles a{cursor:pointer}.kh-reversi #importexport-box{background-color:#333;border-color:#222}.kh-reversi #importexport-box .kh-setting-option-selected{background:#5998d6}.kh-reversi .kh-toggles{background:#333;border-color:#555}.kh-hide-element{display:none}.kh-highlight-bookmarked-yes .bookmark.is-bookmarked p.status{padding-right:40px}@media screen and (max-width: 42em){.kh-highlight-bookmarked-yes .bookmark.is-bookmarked p.status{padding-right:20px}}.kh-skipped-display-collapse .collapsed-blurb.skipped-work h6.landmark.heading,.kh-seen-display-collapse .collapsed-blurb.marked-seen h6.landmark.heading,.kh-kudosed-display-collapse .collapsed-blurb.has-kudos h6.landmark.heading,.kh-skipped-display-collapse .collapsed-blurb.skipped-work>ul,.kh-seen-display-collapse .collapsed-blurb.marked-seen>ul,.kh-kudosed-display-collapse .collapsed-blurb.has-kudos>ul,.kh-skipped-display-collapse .collapsed-blurb.skipped-work blockquote.userstuff.summary,.kh-seen-display-collapse .collapsed-blurb.marked-seen blockquote.userstuff.summary,.kh-kudosed-display-collapse .collapsed-blurb.has-kudos blockquote.userstuff.summary,.kh-skipped-display-collapse .collapsed-blurb.skipped-work dl.stats,.kh-seen-display-collapse .collapsed-blurb.marked-seen dl.stats,.kh-kudosed-display-collapse .collapsed-blurb.has-kudos dl.stats,.kh-skipped-display-collapse .collapsed-blurb.skipped-work .header .fandoms.heading,.kh-seen-display-collapse .collapsed-blurb.marked-seen .header .fandoms.heading,.kh-kudosed-display-collapse .collapsed-blurb.has-kudos .header .fandoms.heading{display:none !important}.kh-skipped-display-collapse .collapsed-blurb.skipped-work .required-tags,.kh-seen-display-collapse .collapsed-blurb.marked-seen .required-tags,.kh-kudosed-display-collapse .collapsed-blurb.has-kudos .required-tags,.kh-skipped-display-collapse .collapsed-blurb.skipped-work .mystery .icon,.kh-seen-display-collapse .collapsed-blurb.marked-seen .mystery .icon,.kh-kudosed-display-collapse .collapsed-blurb.has-kudos .mystery .icon{opacity:.6;transform:scale(0.4);transform-origin:top left}.kh-skipped-display-collapse .collapsed-blurb.skipped-work .header,.kh-seen-display-collapse .collapsed-blurb.marked-seen .header,.kh-kudosed-display-collapse .collapsed-blurb.has-kudos .header{min-height:22px;cursor:zoom-in}.kh-skipped-display-collapse .collapsed-blurb.skipped-work .header .heading,.kh-seen-display-collapse .collapsed-blurb.marked-seen .header .heading,.kh-kudosed-display-collapse .collapsed-blurb.has-kudos .header .heading{margin-left:32px}.kh-skipped-display-collapse .skipped-work:not(.collapsed-blurb) .header,.kh-seen-display-collapse .marked-seen:not(.collapsed-blurb) .header,.kh-kudosed-display-collapse .has-kudos:not(.collapsed-blurb) .header{cursor:zoom-out}.kh-kudosed-display-hide:not(.bookmarks-show) li.has-kudos{display:none !important}.kh-seen-display-hide:not(.bookmarks-show) li.marked-seen{display:none !important}.kh-skipped-display-hide .skipped-work{display:none}.kh-skipped-display-placeholder .skipped-work>*{display:none}.kh-skipped-display-placeholder .skipped-work:before{content:"Skipped"}.kh-highlight-new-yes li.new-blurb{border-left:5px solid #900}.kh-highlight-new-yes.kh-reversi#main li.new-blurb{border-left-color:#5998d6}.kh-toggles-display-on-hover li.blurb-with-toggles:hover>.kh-toggles{display:block}.kh-toggles-display-show li.blurb-with-toggles{margin-top:31px}.kh-toggles-display-show li.blurb-with-toggles .kh-toggles{display:block}';

        var style = $('<style type="text/css"></style>').appendTo($("head"));
        style.html(css);

        addMainClass();
      }

      function addMainClass(update) {
        var classes_to_remove = ["kh-main"];
        var classes_to_add = ["kh-main"];

        settings_list.forEach(function (setting) {
          var setting_class_name = setting.name.replace("_", "-");
          classes_to_add.push(
            "kh-" +
            setting_class_name +
            "-" +
            kudos_history[setting.name].current.replace(" ", "-"),
          );

          if (update) {
            setting.options.forEach(function (option) {
              classes_to_remove.push(
                "kh-" + setting_class_name + "-" + option.replace(" ", "-"),
              );
            });
          }
        });

        if (update) {
          main.removeClass(classes_to_remove.join(" "));
        }

        main.addClass(classes_to_add.join(" "));
      }
    })(jQuery);
  }

  if (QremoveClearHerstoryButton && QextensionFullUpdated) {
    if (document.location.href.match(/users\/.*\/readings.*$/)) {
      const ulItems = document
        .getElementById("main")
        .getElementsByTagName("ul")[0];

      const lisItems = ulItems.getElementsByTagName("li");

      Array.from(lisItems)
        .slice(2)
        .forEach((li) => li.remove());
    }
  }

  if (QarchiveWorks && QextensionFullUpdated) {
    if (document.location.href.match(/works\/\d\d*.*$/)) {
      const actionsList = document.querySelector('ul.work.navigation.actions');
      if (!actionsList) {
        logConsole("Error:", "Actions list not found", true);
      }

      const li = document.createElement('li');
      li.className = 'pap-archive';

      const downloadButton = document.createElement('button');
      downloadButton.textContent = 'Archive';
      downloadButton.setAttribute("onclick", "downloadWork('html')");

      li.appendChild(downloadButton, false);

      actionsList.appendChild(li);
    }
  }
  if (false) {      // script disabled
    if (notFirstTime) {
      if (QcustomScoreSystem && QextensionFullUpdated) {
        // setScoreRatingWeight(1, 3, 0.5, 0.8, 0.1, 2);
        // Read documentation to adjust weights.

        olIndexForPage = 0;
        url = document.location.href;
        let QrunScript = true;
        let QrunScriptAlt = false;
        switch (true) {
          case url.match(/\/works\/search.*/) != null:
            olIndexForPage = 1;
            break;
          case url.match(/\/tags\/.*/) != null:
            olIndexForPage = 1;
            break;
          case url.match(/\/users\/.*/) != null:
            olIndexForPage = 0;
            break;
          case url.match(/\/works\/\d*/) != null:
            QrunScript = false;
            QrunScriptAlt = true;
            break;
          default:
            QrunScript = false;
            break;
        }

        function runScript() {
          let main = document.getElementById("main");
          let workList = main.getElementsByTagName("ol")[olIndexForPage];
          workList = workList.getElementsByClassName("work");
          // kudos
          // bookmarks
          // comments
          // hits
          // engamgment
          function runScore() {
            for (let i = 0; i < workList.length; i++) {
              let tmpStatsA = [];
              let tmpStatsB = [];
              let tmpStatsAB = [];
              let tmpStatsC = [];

              const work = workList[i];
              let stats = work.getElementsByClassName("stats")[0];
              stats = stats.getElementsByTagName("div");

              tmpStatsA = [];
              tmpStatsB = [];
              for (let j = 0; j < stats.length; j++) {
                let stat = stats[j];
                stat = stat.getElementsByTagName("dd");

                tmpStatsA[j] = stat[0].className;
                tmpStatsB[j] = stat[0].innerText;
              }

              tmpStatsAB[0] = tmpStatsA;
              tmpStatsAB[1] = tmpStatsB;
              tmpStatsC[i] = tmpStatsAB;

              let words = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("words")];
              let chapters = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("chapters")];
              let comments = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("comments")];
              let kudos = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("kudos")];
              let bookmarks = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("bookmarks")];
              let hits = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("hits")];

              if (words == null) { words = "0"; }
              if (chapters == null) { chapters = "0"; }
              if (comments == null) { comments = "0"; }
              if (kudos == null) { kudos = "0"; }
              if (bookmarks == null) { bookmarks = "0"; }
              if (hits == null) { hits = "0"; }

              words = Number(words.replaceAll(" ", ""));
              comments = Number(comments.replaceAll(" ", ""));
              kudos = Number(kudos.replaceAll(" ", ""));
              bookmarks = Number(bookmarks.replaceAll(" ", ""));
              hits = Number(hits.replaceAll(" ", ""));

              chapters = chapters.split("/");
              if (chapters[1] == "?") chapters[1] == "1"

              let wordsPChapter = words / chapters[0];
              let commentsPChapter = comments / chapters[0];
              let commentsPKudos = ((comments / kudos) * 10);   // 1 - 10
              let bookmarksPKudos = ((bookmarks / kudos) * 10); // 1 - 10
              let kudosPH = ((kudos / hits) * 100) - 3;           // 1 - 10
              let engagmentCBKpH = ((comments * 1) + (bookmarks * 1) + (kudos * 1)) / (hits / 100); // 0 -> 0 -> 10 - 100
              let smallOrNewFicBoost = smallOrNewFicBoostCalc(hits, engagmentCBKpH); // 1 - 10
              hits = hitsCurveCalculator(hits);               // 1 - 10

              score = 0;
              score += kudosPH * weights[0];
              score += bookmarksPKudos * weights[1];
              score += commentsPKudos * weights[2];
              score += hits * weights[3];
              score += engagmentCBKpH * weights[4];
              score += smallOrNewFicBoost * weights[5];

              if (score == NaN) { score = kudosPH * 10; }
              if (score == NaN) { score = 3; }

              score = Math.floor(score);

              scoreDiv = document.getElementById(`ao3S_insretedScore${i}`);
              scoreDiv.innerHTML = "";
              scoreDiv.className = "'ao3S";
              scoreDiv.id = `ao3S_insretedScore${i}`;

              dt = document.createElement("dt");
              dt.className = "'Score";
              dt.innerText = "'Score";
              scoreDiv.appendChild(dt);

              dd = document.createElement("dd");
              dd.className = "'Score";
              dd.innerText = score;
              scoreDiv.appendChild(dd);

              workList[i].getElementsByTagName("dl")[0].appendChild(scoreDiv)
            }
          }

          function hitsCurveCalculator(input) {
            switch (true) {
              case input < 101:
                input = 0;
                break;

              case 100 < input < 201:
                input = 1;
                break;

              case 200 < input < 301:
                input = 2;
                break;

              case 300 < input < 401:
                input = 3;
                break;

              case 400 < input < 451:
                input = 4;
                break;

              case 450 < input < 501:
                input = 5;
                break;

              case 500 < input < 751:
                input = 6;
                break;

              case 750 < input < 1501:
                input = 7;
                break;

              case 1500 < input < 2251:
                input = 8;
                break;

              case 2250 < input < 5001:
                input = 9;
                break;

              default:
                input = 5;
                break;
            }
            input++;

            return input;
          }
          function smallOrNewFicBoostCalc(hits, engagmentCBKpH) {
            boost = 0;
            boost += (500 - hits);
            boost += (20 - engagmentCBKpH * weights[4]);
            if (boost < -5) boost = -5;
            if (boost > 520) boost = 520;

            boost = boost + 5;
            boost = boost / 52;

            return boost;
          }
          runScore();
        }

        if (QrunScript) {
          runScript();
          // logConsole('script running');
        } else {
          if (QrunScriptAlt) {
            // runScriptAlt();
            // logConsole("script not avaaliable yet for running on work page");
          } else {
            // logConsole("not running");
          }
        }
      }
    } else {
      if (QcustomScoreSystem && QextensionFullUpdated) {
        // setScoreRatingWeight(1, 3, 0.5, 0.8, 0.1, 2);
        // Read documentation to adjust weights.

        olIndexForPage = 0;
        url = document.location.href;
        let QrunScript = true;
        let QrunScriptAlt = false;
        switch (true) {
          case url.match(/\/works.search.*/) != null:
            olIndexForPage = 1;
            break;
          case url.match(/\/tags\/.*/) != null:
            olIndexForPage = 1;
            break;
          case url.match(/\/users\/.*/) != null:
            olIndexForPage = 0;
            break;
          case url.match(/\/works\/\d*/) != null:
            QrunScript = false;
            QrunScriptAlt = true;
            break;
          default:
            QrunScript = false;
            break;
        }

        function runScript() {
          let main = document.getElementById("main");
          let workList = main.getElementsByTagName("ol")[olIndexForPage];
          workList = workList.getElementsByClassName("work");
          // kudos
          // bookmarks
          // comments
          // hits
          // engamgment
          function runScore() {
            for (let i = 0; i < workList.length; i++) {
              let tmpStatsA = [];
              let tmpStatsB = [];
              let tmpStatsAB = [];
              let tmpStatsC = [];

              const work = workList[i];
              let stats = work.getElementsByClassName("stats")[0];
              stats = stats.getElementsByTagName("div");

              tmpStatsA = [];
              tmpStatsB = [];
              for (let j = 0; j < stats.length; j++) {
                let stat = stats[j];
                stat = stat.getElementsByTagName("dd");

                tmpStatsA[j] = stat[0].className;
                tmpStatsB[j] = stat[0].innerText;
              }

              tmpStatsAB[0] = tmpStatsA;
              tmpStatsAB[1] = tmpStatsB;
              tmpStatsC[i] = tmpStatsAB;

              let words = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("words")];
              let chapters = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("chapters")];
              let comments = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("comments")];
              let kudos = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("kudos")];
              let bookmarks = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("bookmarks")];
              let hits = tmpStatsC[i][1][tmpStatsC[i][0].indexOf("hits")];

              if (words == null) words = "0"
              if (chapters == null) chapters = "0"
              if (comments == null) comments = "0"
              if (kudos == null) kudos = "0"
              if (bookmarks == null) bookmarks = "0"
              if (hits == null) hits = "0"

              words = Number(words.replaceAll(" ", ""));
              comments = Number(comments.replaceAll(" ", ""));
              kudos = Number(kudos.replaceAll(" ", ""));
              bookmarks = Number(bookmarks.replaceAll(" ", ""));
              hits = Number(hits.replaceAll(" ", ""));

              chapters = chapters.split("/");
              if (chapters[1] == "?") chapters[1] == "1"

              let wordsPChapter = words / chapters[0];
              let commentsPChapter = comments / chapters[0];
              let commentsPKudos = ((comments / kudos) * 10);   // 1 - 10
              let bookmarksPKudos = ((bookmarks / kudos) * 10); // 1 - 10
              let kudosPH = ((kudos / hits) * 100) - 3;           // 1 - 10
              let engagmentCBKpH = ((comments * 1) + (bookmarks * 1) + (kudos * 1)) / (hits / 100); // 0 -> 0 -> 10 - 100
              let smallOrNewFicBoost = smallOrNewFicBoostCalc(hits, engagmentCBKpH); // 1 - 10
              hits = hitsCurveCalculator(hits);               // 1 - 10

              score = 0;
              score += kudosPH * weights[0];
              score += bookmarksPKudos * weights[1];
              score += commentsPKudos * weights[2];
              score += hits * weights[3];
              score += engagmentCBKpH * weights[4];
              score += smallOrNewFicBoost * weights[5];

              if (score == NaN) score = kudosPH * 10;
              if (score == NaN) score = 3;

              score = Math.floor(score);

              scoreDiv = document.createElement("div");
              scoreDiv.className = "'ao3S";
              scoreDiv.id = `ao3S_insretedScore${i}`;

              dt = document.createElement("dt");
              dt.className = "'Score";
              dt.innerText = "'Score";
              scoreDiv.appendChild(dt);

              dd = document.createElement("dd");
              dd.className = "'Score";
              dd.innerText = score;
              scoreDiv.appendChild(dd);

              workList[i].getElementsByTagName("dl")[0].appendChild(scoreDiv)
            }
          }

          function hitsCurveCalculator(input) {
            switch (true) {
              case input < 101:
                input = 0;
                break;

              case 100 < input < 201:
                input = 1;
                break;

              case 200 < input < 301:
                input = 2;
                break;

              case 300 < input < 401:
                input = 3;
                break;

              case 400 < input < 451:
                input = 4;
                break;

              case 450 < input < 501:
                input = 5;
                break;

              case 500 < input < 751:
                input = 6;
                break;

              case 750 < input < 1501:
                input = 7;
                break;

              case 1500 < input < 2251:
                input = 8;
                break;

              case 2250 < input < 5001:
                input = 9;
                break;

              default:
                input = 5;
                break;
            }
            input++;

            return input;
          }
          function smallOrNewFicBoostCalc(hits, engagmentCBKpH) {
            boost = 0;
            boost += (500 - hits);
            boost += (20 - engagmentCBKpH * weights[4]);
            if (boost < -5) boost = -5;
            if (boost > 520) boost = 520;

            boost = boost + 5;
            boost = boost / 52;

            return boost;
          }
          runScore();
        }
        runScript();
        if (QrunScript) {
          runScript();
          // logConsole('script running');
        } else {
          if (QrunScriptAlt) {
            // runScriptAlt();
            // logConsole("script not avaaliable yet for running on work page");
          } else {
            // logConsole("not running");
          }
        }
      }
    }
  }
  if (QtrainedScoreSystem && QextensionFullUpdated) {
    function ao3Qscore_ByC89sd_v2_35() {
      // ==UserScript==
      // @name        AO3 Qscore
      // @description Autosorting 'Quality' Indicator trained on 11k+ works. Very generous with small fics, rewards engagement over popularity (bookmarks-collections/kudos instead of hits) with a 0-100 score spread. Sort & position toggles included.
      // @version     2.35
      // @author      C89sd
      // @namespace   https://greasyfork.org/users/1376767
      // @match       https://archiveofourown.org/*
      // @grant       GM_addStyle
      // @noframes
      // ==/UserScript==
      'use strict';

      // ======================== CONFIGURATION ========================

      const SORT_USER_PAGE = true;

      /*
      # Scoring:
      There are 3 metrics pairs: (bookmarks, collections, comments)/kudos.
      Each pair has a trained regression model validated above a certain `min`.
      Each metric is tested against min, and if it passes, it is scored by the model; otherwise it gets dimmed to 0.
      The final score is derived by mixing all valid scores using a blend of MAX() and AVERAGE().
       
      - MAX     Keeps the best score, rewards works at the top of any single metric.
                Gives 100 scores if any of the metrics are 100.
      - AVERAGE Rewards works with the most high scores, and most valid metrics (3>2>1).
                Missing scores bring down the final score by blending in a 0.
                Only gives 100 scores if all three metrics are 100.
       
      Lowering `min` to be more generous with small works and show more scores
      would corrupt the top scores by making the models generate outside of their range.
       
      To solve this, I added `bmin`. If all the metrics are invalid (<min), the score
      is recomputed with the lower `>bmin` threshold. These scores are dimmed and placed at the bottom.
      Scores that fail this test as well get a dimmed 0.
      Since these scores are less accurate, they use a separate `BMIN_ALPHA` factor to smooth them more.
       
        If you do not care about being generous with small works, you can set 'ENABLE_BMIN=false',
      and raise the `dim_below` thresholds to fold more final scores in the dimmed section,
      or raise `min` but this will use the worse `bmin` to score those in the dimmed section.
        OR, if you want to adjust the separate BMIN_ALPHA for dimmed scores,
      you can keep `min=dim_below` and raise `bmin` and `min` directly .
      */

      // Add indicators showing the individual scores with z_scale applied (bookmarks, collections, comments).
      // Border color: yellow=bmin_valid, red=invalid.
      const DEBUG = false;
      // const DEBUG = true;

      // Blending factor between MAX and AVERAGE `finalScore = A*MAX+(1-A)*AVG`. 1=MAX, 0=AVERAGE
      const ALPHA = 0.99;
      const BMIN_ALPHA = 0.75;
      const ENABLE_BMIN = true;

      // Weight of missing scores in the Average formula.
      // Example: (ALPHA=0.7, zero_weight=0.3, avg_weight=1): 2 valid + 1 invalid (−3 pts); 1 valid + 2 invalid (−10 pts);
      const AVG_ZERO_WEIGHT = 0.3;

      // `min`        Metrics below this value are invalid and will not contribute to the final ALPHA blended score.
      // `bmin`       Bottom min. If ENABLE_BMIN=true, invalid final scores are *rescored* with `bmin` and `BMIN_ALPHA`, dimmed and sorted at the end.
      //
      // `dim_below`  Dim final scores if all metrics are below this second threshold.
      //              This is a convenience to hide smaller works without touching min.
      //              `dim_below=0` is disabled and default to `min`: the only dimmed scores are from the range [bmin,min[.
      // `avg_weight` Weight of a score in the weighted AVERAGE score.
      // `z_scale`    Scales the positive z-scores, resulting in fewer 100s for that metric.
      //              To halve the number of 100 scores: const Halve100 = 0.9176338854906885;
      //                                                 const Halve99  = 0.892167842806324;
      const THRESHOLDS = {
        'kudos': { bmin: 5, min: 8, /**/ dim_below: 0 }, // Gates all others.
        //
        'bookmarks': { bmin: 1, min: 3, /**/ dim_below: 0, avg_weight: 1.0, z_scale: 1.0 },
        'collections': { bmin: 1, min: 2, /**/ dim_below: 0, avg_weight: 1.0, z_scale: 1.0 },
        'comments': { bmin: Infinity, min: Infinity, /**/ dim_below: 0, avg_weight: 1.0, z_scale: 1.0 }, // bmin: 3, min: 3
        //
        'chapters': { bmin: 1, min: 2, /**/ dim_below: 0 }
      };
      // Replace {.dim_below=0 by .min}
      Object.values(THRESHOLDS).forEach(obj => obj.dim_below === 0 && (obj.dim_below = obj.min));
      // Note on 'chapters':
      //    ('comments','kudos') is actually ('comment_per_chapter','kudos_per_chapter').
      //    which is why this metric is gated on 'chapters' as well.

      // ======================== MODEL & CONSTANTS ========================

      let MODEL = { "Z_95": 1.0364333894937898, "regressions": [{ "x_metric": "bookmarks", "y_metric": "kudos", "x_grid": [0.0, 0.3323, 0.6646, 0.997, 1.3293, 1.6616, 1.9939, 2.3263, 2.6586, 2.9909, 3.3232, 3.6556, 3.9879, 4.3202, 4.6525, 4.9849, 5.3172, 5.6495, 5.9818, 6.3142, 6.6465, 6.9788, 7.3111, 7.6435, 7.9758, 8.3081, 8.6404, 8.9728, 9.3051, 9.6374, 9.9697, 10.3021, 10.6344, 10.9667, 11.299, 11.6314, 11.9637, 12.296, 12.6283, 12.9607], "q05_curve_y": [2.1722, 2.3297, 2.4859, 2.6704, 2.9142, 3.2016, 3.5162, 3.8411, 4.1655, 4.4864, 4.8014, 5.1093, 5.4097, 5.7043, 5.9953, 6.2845, 6.5734, 6.863, 7.1536, 7.4456, 7.7394, 8.036, 8.337, 8.6442, 8.9592, 9.2832, 9.6137, 9.9459, 10.2753, 10.5945, 10.894, 11.1935, 11.493, 11.7925, 12.092, 12.3915, 12.691, 12.9905, 13.29, 13.5895], "q50_curve_y": [2.6252, 2.8076, 2.99, 3.1987, 3.4591, 3.7542, 4.0665, 4.3786, 4.6822, 4.9785, 5.2694, 5.5568, 5.8423, 6.1263, 6.4088, 6.6897, 6.9693, 7.2481, 7.5271, 7.8075, 8.0904, 8.3768, 8.6675, 8.9631, 9.2643, 9.5715, 9.883, 10.1953, 10.5046, 10.8076, 11.1071, 11.4066, 11.7061, 12.0056, 12.3051, 12.6046, 12.9041, 13.2036, 13.5031, 13.8026], "q95_curve_y": [3.2949, 3.4494, 3.6051, 3.7878, 4.0228, 4.2933, 4.5821, 4.8722, 5.1554, 5.4336, 5.7092, 5.9846, 6.2616, 6.5397, 6.8183, 7.0964, 7.3736, 7.6496, 7.925, 8.2006, 8.4768, 8.7546, 9.0347, 9.3182, 9.606, 9.899, 10.1957, 10.493, 10.7875, 11.0783, 11.3778, 11.6773, 11.9768, 12.2763, 12.5758, 12.8753, 13.1748, 13.4743, 13.7738, 14.0733], "mu": 0.010967210394413519, "sigma": 1.0618674385105822 }, { "x_metric": "collections", "y_metric": "kudos", "x_grid": [0.0, 0.1849, 0.3698, 0.5547, 0.7395, 0.9244, 1.1093, 1.2942, 1.4791, 1.664, 1.8489, 2.0338, 2.2186, 2.4035, 2.5884, 2.7733, 2.9582, 3.1431, 3.328, 3.5128, 3.6977, 3.8826, 4.0675, 4.2524, 4.4373, 4.6222, 4.8071, 4.9919, 5.1768, 5.3617, 5.5466, 5.7315, 5.9164, 6.1013, 6.2861, 6.471, 6.6559, 6.8408, 7.0257, 7.2106], "q05_curve_y": [1.414, 2.2679, 3.0662, 3.8165, 4.5249, 5.1912, 5.8014, 6.3417, 6.8012, 7.1803, 7.486, 7.7255, 7.9099, 8.0571, 8.1842, 8.3065, 8.4306, 8.5581, 8.6903, 8.8278, 8.9698, 9.1149, 9.2619, 9.4096, 9.5572, 9.7011, 9.8291, 9.957, 10.0849, 10.2129, 10.3408, 10.4688, 10.5967, 10.7246, 10.8526, 10.9805, 11.1085, 11.2364, 11.3644, 11.4923], "q50_curve_y": [4.6143, 5.0468, 5.4793, 5.9118, 6.344, 6.7656, 7.1615, 7.5184, 7.8241, 8.0778, 8.2846, 8.4498, 8.5805, 8.6882, 8.7847, 8.8811, 8.9822, 9.0886, 9.2013, 9.3202, 9.4438, 9.5706, 9.6989, 9.8278, 9.9566, 10.0849, 10.2128, 10.3408, 10.4687, 10.5966, 10.7246, 10.8525, 10.9805, 11.1084, 11.2363, 11.3643, 11.4922, 11.6202, 11.7481, 11.8761], "q95_curve_y": [7.5724, 7.5553, 7.6064, 7.7156, 7.8738, 8.0693, 8.2843, 8.4997, 8.6981, 8.872, 9.021, 9.1463, 9.2512, 9.3418, 9.4254, 9.5093, 9.596, 9.6856, 9.7781, 9.8735, 9.9715, 10.0714, 10.1726, 10.2747, 10.3775, 10.4844, 10.6124, 10.7403, 10.8683, 10.9962, 11.1241, 11.2521, 11.38, 11.508, 11.6359, 11.7638, 11.8918, 12.0197, 12.1477, 12.2756], "mu": -0.021871244232891534, "sigma": 1.0510446029054428 }, { "x_metric": "comments", "y_metric": "kudos", "x_grid": [0.0, 0.3328, 0.6657, 0.9985, 1.3314, 1.6642, 1.9971, 2.3299, 2.6628, 2.9956, 3.3285, 3.6613, 3.9942, 4.327, 4.6599, 4.9927, 5.3256, 5.6584, 5.9913, 6.3241, 6.657, 6.9898, 7.3227, 7.6555, 7.9884, 8.3212, 8.6541, 8.9869, 9.3198, 9.6526, 9.9855, 10.3183, 10.6512, 10.984, 11.3169, 11.6497, 11.9826, 12.3154, 12.6483, 12.9811], "q05_curve_y": [2.0093, 2.3035, 2.5978, 2.8931, 3.1913, 3.4928, 3.7983, 4.1076, 4.4169, 4.7214, 5.0158, 5.2959, 5.5604, 5.8098, 6.0444, 6.2648, 6.4745, 6.6782, 6.8804, 7.0851, 7.289, 7.4859, 7.6695, 7.8344, 7.9817, 8.116, 8.2422, 8.3681, 8.495, 8.6219, 8.7488, 8.8757, 9.0026, 9.1294, 9.2563, 9.3832, 9.5101, 9.637, 9.7639, 9.8908], "q50_curve_y": [2.8284, 3.1258, 3.4232, 3.7217, 4.0229, 4.3275, 4.636, 4.9483, 5.2606, 5.5679, 5.8652, 6.1481, 6.4155, 6.6677, 6.9051, 7.1284, 7.3411, 7.5479, 7.7533, 7.9612, 8.1685, 8.369, 8.5563, 8.7249, 8.8761, 9.0144, 9.1446, 9.2716, 9.3984, 9.5253, 9.6522, 9.7791, 9.906, 10.0329, 10.1597, 10.2866, 10.4135, 10.5404, 10.6673, 10.7942], "q95_curve_y": [3.6809, 3.9759, 4.271, 4.5671, 4.866, 5.1684, 5.4748, 5.785, 6.0954, 6.4009, 6.6965, 6.9777, 7.2435, 7.4942, 7.7301, 7.9519, 8.1631, 8.3682, 8.5721, 8.7784, 8.9842, 9.183, 9.3686, 9.5355, 9.6847, 9.8211, 9.9493, 10.0758, 10.2027, 10.3296, 10.4564, 10.5833, 10.7102, 10.8371, 10.964, 11.0909, 11.2178, 11.3446, 11.4715, 11.5984], "mu": -0.02560361702737164, "sigma": 1.0479841045712814 }] };

      /* -- Halve100 --
      from scipy.stats import norm
      z = norm.ppf(98.5/100)      # round([99.5,100]) = 100
      p = 0.5 * (1 - norm.cdf(z)) # make 100s half as likely
      print("sigma scale:", z / norm.ppf(1 - p))
      */

      // --- HELPER FUNCTIONS ---
      function interpolate(xs, ys, targetX) {
        if (targetX <= xs[0]) return ys[0];
        if (targetX >= xs[xs.length - 1]) return ys[ys.length - 1];
        const i = xs.findIndex(x => x > targetX) - 1;
        const fraction = (targetX - xs[i]) / (xs[i + 1] - xs[i]);
        return ys[i] + fraction * (ys[i + 1] - ys[i]);
      }

      function sum(arr) { return arr.reduce((a, b) => a + b, 0); }

      function ncdf(z) {
        let t = 1 / (1 + 0.2315419 * Math.abs(z));
        let d = 0.3989423 * Math.exp(-z * z / 2);
        let prob = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
        if (z > 0) prob = 1 - prob;
        return prob;
      }

      // ======================== CORE SCORING FUNCTION ========================

      function calculateScore(article, metrics) {
        let valid_scores = []
        let bmin_valid_scores = []
        let all_scores = []
        let all_dimmed = true;

        for (const regression of MODEL.regressions) {
          const x_metric = regression.x_metric; // bookmarks
          const y_metric = regression.y_metric; // kudos

          let is_valid =
            metrics[x_metric] >= THRESHOLDS[x_metric].min &&
            metrics[y_metric] >= THRESHOLDS[y_metric].min &&
            (x_metric === 'comments' ? metrics['chapters'] >= THRESHOLDS['chapters'].min : true);

          let is_bmin_valid =
            is_valid ||
            metrics[x_metric] >= THRESHOLDS[x_metric].bmin &&
            metrics[y_metric] >= THRESHOLDS[y_metric].bmin &&
            (x_metric === 'comments' ? metrics['chapters'] >= THRESHOLDS['chapters'].bmin : true);

          let not_dimmed =
            is_valid &&
            metrics[x_metric] >= THRESHOLDS[x_metric].dim_below &&
            metrics[y_metric] >= THRESHOLDS[y_metric].dim_below &&
            (x_metric === 'comments' ? metrics['chapters'] >= THRESHOLDS['chapters'].dim_below : true);
          if (not_dimmed) all_dimmed = false;

          // Compute score
          const x_point = Math.log1p(metrics[x_metric]);
          const y_point = Math.log1p(metrics[y_metric]);

          const y_center = interpolate(regression.x_grid, regression.q50_curve_y, x_point);
          const y_lower = interpolate(regression.x_grid, regression.q05_curve_y, x_point);
          const y_upper = interpolate(regression.x_grid, regression.q95_curve_y, x_point);

          let ratio;
          let z_scale = 1.0;
          if (y_point >= y_center) {
            const upper_diff = y_upper - y_center;
            ratio = (upper_diff > 1e-6) ? (y_point - y_center) / upper_diff : 0.0;
          } else {
            const lower_diff = y_center - y_lower;
            ratio = (lower_diff > 1e-6) ? (y_point - y_center) / lower_diff : 0.0;
            z_scale = THRESHOLDS[x_metric].z_scale; // only scale positive zscores
          }
          const z_score = - MODEL.Z_95 * ratio; // flip the upside down graph

          const standardized_z = (z_score - regression.mu) / regression.sigma;
          const score = 100 * ncdf(standardized_z * z_scale);

          let res = { x_metric, score, is_valid, is_bmin_valid, dimmed: !not_dimmed, weight: THRESHOLDS[x_metric].avg_weight };
          if (is_valid) valid_scores.push(res);
          if (is_bmin_valid) bmin_valid_scores.push(res);
          all_scores.push(res);
        }

        const valid = (valid_scores.length > 0);
        const bmin_valid = (bmin_valid_scores.length > 0);

        if (valid) {
          // AVERAGE
          let premult_sum = 0.0,
            weights_sum = 0.0;
          for (let s of all_scores) {
            premult_sum += s.is_valid ? s.score * s.weight : 0.0;
            weights_sum += s.is_valid ? s.weight : s.weight * AVG_ZERO_WEIGHT;
          }
          let avg_score = premult_sum / weights_sum;

          // MAX
          let max_score = 0.0;
          for (let s of valid_scores) max_score = Math.max(max_score, s.score);

          const final_score = ALPHA * max_score + (1 - ALPHA) * avg_score;

          return [final_score, valid, true, all_dimmed, all_scores];
        }

        if (ENABLE_BMIN && bmin_valid) {
          // AVERAGE
          let premult_sum = 0.0,
            weights_sum = 0.0;
          for (let s of all_scores) {
            premult_sum += s.is_bmin_valid ? s.score * s.weight : 0.0;
            weights_sum += s.is_bmin_valid ? s.weight : s.weight * AVG_ZERO_WEIGHT;
          }
          let avg_score = premult_sum / weights_sum;

          // MAX
          let max_score = 0.0; // include invalid
          for (let s of bmin_valid_scores) max_score = Math.max(max_score, s.score);

          const final_score = BMIN_ALPHA * max_score + (1 - BMIN_ALPHA) * avg_score;

          return [final_score, false, true, true, all_scores];
        }

        return [0, false, false, true, all_scores];
      }

      // ---------------------------------- COLORS ----------------------------------




      const isDarkMode = window.getComputedStyle(document.body).color.match(/\d+/g)[0] > 128;
      if (isDarkMode) document.documentElement.classList.add('dark-theme');

      const HSL_STRINGS = [
        'hsl(0.0, 90.7%, 92.3%)',
        'hsl(47.8, 67.1%, 81.5%)',
        'hsl(118.4, 51.2%, 85%)',
        'hsl(122.9, 35.1%, 63.4%)',
      ];
      const COLORS = HSL_STRINGS.map(str => (([h, s, l]) => ({ h, s, l }))(str.match(/[\d.]+/g).map(Number)));

      function clamp(a, b, x) { return x < a ? a : (x > b ? b : x); }
      function color(t, range = 1.0, use3colors = false) {
        let a, b;
        t = t / range;
        if (t < 0) { t = 0.0; }
        if (use3colors && t > 1.0) { t = 1.0; }
        else if (t > 1.5) { t = 1.5; }

        if (t < 0.5) {
          a = COLORS[0], b = COLORS[1];
          t = t * 2.0;
        } else if (t <= 1.0) {
          a = COLORS[1], b = COLORS[2];
          t = (t - 0.5) * 2.0;
        } else {
          a = COLORS[2], b = COLORS[3];
          t = (t - 1.0) * 2.0;
        }
        const h = clamp(0, 360, a.h + (b.h - a.h) * t);
        const s = clamp(0, 100, a.s + (b.s - a.s) * t);
        const l = clamp(0, 100, a.l + (b.l - a.l) * t);
        return `hsl(${h.toFixed(1)}, ${s.toFixed(1)}%, ${l.toFixed(1)}%)`;
      }

      // ---------------------------------- NAVBAR ----------------------------------
      let navSortingString = null;
      let sortingTxt = ['⇊', '⇅'];
      let navCornerString = null;
      let cornerTxt = ['⇱', '⇲'];
      {
        let navbar = document.querySelector('ul.primary');
        if (navbar) {
          let searchBox = navbar.querySelector('.search');
          if (searchBox) {
            {
              let li = document.createElement('li');
              li.classList.add('dropdown');
              navSortingString = localStorage.getItem('C89AO3_sorting') || sortingTxt[0];
              navSortingString = sortingTxt.includes(navSortingString) ? navSortingString : sortingTxt[0];
              let a = document.createElement('a');
              a.className = 'halfWidth';
              a.textContent = navSortingString;
              a.href = '#';
              a.addEventListener('click', (e) => {
                navSortingString = sortingTxt[(sortingTxt.indexOf(a.textContent) + 1) % sortingTxt.length];
                a.textContent = navSortingString;
                localStorage.setItem('C89AO3_sorting', navSortingString);
                a.blur();
                toggleSorting(true);
              });
              li.appendChild(a);
              navbar.insertBefore(li, searchBox);
            }
            {
              let li = document.createElement('li');
              li.classList.add('dropdown');
              navCornerString = localStorage.getItem('C89AO3_corner') || cornerTxt[0];
              navCornerString = cornerTxt.includes(navCornerString) ? navCornerString : cornerTxt[0];
              let a = document.createElement('a');
              a.className = 'halfWidth';
              a.textContent = navCornerString;
              a.href = '#';
              a.addEventListener('click', (e) => {
                navCornerString = cornerTxt[(cornerTxt.indexOf(a.textContent) + 1) % cornerTxt.length];
                a.textContent = navCornerString;
                localStorage.setItem('C89AO3_corner', navCornerString);
                a.blur();
                toggleCorner();
              });
              li.appendChild(a);
              navbar.insertBefore(li, searchBox);
            }
          }
        }
      }

      // ---------------------------------- MAIN ----------------------------------

      const commaRegex = /,/g
      function parse(str) {
        return str ? parseInt(str.replace(commaRegex, ''), 10) : null;
      }

      let sortingData = [];
      const articles = document.querySelectorAll('li.work[role="article"], li.bookmark[class*="work-"], dl.work.meta.group');

      function removeOldScores() {
        document.querySelectorAll('.scoreA').forEach(el => el.remove());
      }

      function isVisible(el) { return window.getComputedStyle(el).display !== "none"; }

      function processArticles() {
        removeOldScores();
        sortingData = [];
        let i = 0;

        for (let article of articles) {
          let bookmarkCornerOccupied = !!article.querySelector('.status'); // isVisible(article.querySelector('.status'));
          let insideAWork = article?.tagName === 'DL';

          let stats = article.querySelector('dl.stats');
          if (!stats) continue;

          const metrics = {
            bookmarks: parse(stats.querySelector('dd.bookmarks')?.textContent) || 0,
            collections:
              insideAWork
                ? article.querySelector('dd.collections')?.children.length || 0
                : parse(stats.querySelector('dd.collections')?.textContent) || 0,
            comments: parse(stats.querySelector('dd.comments')?.textContent) || 0,
            kudos: parse(stats.querySelector('dd.kudos')?.textContent) || 0,
            chapters: parse(stats.querySelector('dd.chapters')?.textContent.split('/')[0]) || 1,
          };


          if (bookmarkCornerOccupied) article.classList.add('cornerFull');
          if (insideAWork) article.classList.add('inWork');


          let [finalScore, valid, bmin_valid, dimmed, all_scores] = calculateScore(article, metrics);

          function makeIndicator(score) {
            const el = document.createElement('span');
            el.classList.add('scoreA');
            el.textContent = Math.round(score);
            el.style.backgroundColor = Number.isNaN(score) ? '#b8b8b8' : color(score / 100, 1, true);
            if (dimmed) el.classList.add('darkenA');
            return el;
          }

          stats.appendChild(document.createTextNode(' '));

          const indicator = makeIndicator(finalScore);
          stats.appendChild(indicator);

          if (DEBUG) {
            const span = document.createElement("span");
            span.textContent = indicator.textContent;
            span.style.minWidth = '28px';
            span.style.zIndex = '999';
            span.style.boxShadow = 'rgba(0, 0, 0, 0.38) 0px 0px 10px';

            indicator.textContent = '';
            indicator.prepend(span);

            indicator.style.display = 'flex';
            indicator.style.alignItems = 'center';
            indicator.style.right = '85px';
            if (!valid) {
              if (bmin_valid) indicator.classList.add('bminValidA');
              else indicator.classList.add('invalidA');
            }

            stats.appendChild(indicator);

            all_scores.forEach(({ score, dimmed, is_valid, is_bmin_valid }) => {
              const dbg = makeIndicator(score);
              if (dimmed) dbg.classList.add('darkenA');
              if (is_valid) { } // dbg.classList.add('validA');
              else if (is_bmin_valid) dbg.classList.add('bminValidA');
              else dbg.classList.add('invalidA');
              dbg.style.position = 'static';
              dbg.style.display = 'inline-block';
              dbg.style.minWidth = '28px';
              indicator.appendChild(dbg);
            });
          }

          let sortKey = dimmed ? finalScore : finalScore + 100;
          sortingData.push({ indicator, article, score: finalScore, index: i++, bookmarkCornerOccupied, insideAWork, sortKey });
        }
      }

      function updateAllScores() {
        processArticles();
        toggleSorting();
        toggleCorner();
      }

      // ---------------------------------- SORTING ----------------------------------

      let isSorted = false;
      function toggleSorting(manual = false) {
        if (location.href.includes('/users/') && !SORT_USER_PAGE && !manual) return; // don't sort user pages unless manually toggled
        if (location.href.includes('/series/')) return; // keep series pages chronological

        let parent = articles[0]?.parentNode;
        if (parent) {
          let run = false;
          if (navSortingString === sortingTxt[0]) {
            sortingData.sort((a, b) => b.sortKey - a.sortKey); isSorted = true; run = true;
          } else if (isSorted) {
            sortingData.sort((a, b) => a.index - b.index); isSorted = false; run = true;
          }
          if (run) sortingData.forEach(({ article }) => {
            parent.appendChild(article);
          });
        }
      }

      // ---------------------------------- CORNER TOGGLE ----------------------------------

      let isInCorner = false;
      function toggleCorner() {
        let run = false;
        if (navCornerString === cornerTxt[0]) {
          isInCorner = true; run = true;
        } else if (isInCorner) {
          isInCorner = false; run = true;
        }
        if (run) {
          sortingData.forEach(({ article, indicator, insideAWork }) => {
            if (indicator) {
              article.querySelector('.datetime')?.classList.add('isDate'); // can be null if inside a work

              if (isInCorner) {
                let cornerParent = insideAWork ? article : article.querySelector('div.header.module');
                if (cornerParent) {
                  article.classList.add('inCorner');
                  cornerParent.appendChild(indicator);
                }
              }
              else {
                let stats = article.querySelector('dl.stats');
                if (stats) {
                  article.classList.remove('inCorner');
                  stats.appendChild(indicator);
                }
              }
            }
          });
        }
      }


      GM_addStyle(`
  /* half width navbar toggle */
  .halfWidth { width: 1.3ch !important; padding: 0.429em calc(0.75em/1) !important; }
 
  /* Indicator styling */
  .scoreA { display: inline-block; width: 28px; text-align: center; line-height: 18px; padding: 0; color: rgb(42,42,42); }  /* em scales different on mobile */
 
  /* Position inside Work pages (needs repeated selector to win) */
  .inWork.inWork.inWork          .scoreA { float: right; }  /* .stats becomes float:left inside works */
  .inWork.inWork.inWork.inCorner .scoreA { position: absolute; top: 10px; right: 10px; z-index: 1; }
 
   /* Default corner position */
  .inCorner .scoreA { position: absolute; top: -3px; right: -2px; }
  .inCorner .isDate { top: 17px; }
 
   /* Move extra below the corner Private Bookmark icon */
  .inCorner.cornerFull:not(.khx-collapsed) .isDate { top: calc(17px + 28px); }
  .inCorner.cornerFull:not(.khx-collapsed) .scoreA { top: 27px; }
 
  /* ?? khx fix skipped before:: text
   .skipped-work .isDate { top: -18px; } */
 
  @-moz-document url-prefix() {
    @media (max-width: 655px) {
      .scoreA {
        width: 26px; /* on desktop 26px doesn't cover the date, 27 does, but the 26px gap looks nicer on mobile. */
      }
    }
  }
  :root {
    --boost:    85%;
    --boostDM:  75%; /* 82%; */
    --darken:   55%;
    --darkenDM: 33.3%;
  }
  :root.dark-theme {
    --darken: var(--darkenDM);
    --boost:  var(--boostDM);
  }
  .scoreA {
    background-image: linear-gradient(hsl(0, 0%, var(--boost)), hsl(0, 0%, var(--boost)));
    background-blend-mode: color-burn;
  }
  .scoreA.darkenA, .darkenA {
    background-image: linear-gradient(hsl(0, 0%, var(--darken)), hsl(0, 0%, var(--darken)));
    background-blend-mode: multiply;
  }
  .invalidA { border: solid 1px #d00 }
  .validA { border: solid 1px #008d00 }
  .bminValidA { border: solid 1px #e1a518 }
`);
      function GM_addStyle(input) {
        let head = document.getElementsByTagName("head")[0];
        let style = document.createElement("style");
        style.innerText = input;
        head.appendChild(style);
      }

      updateAllScores()
    }
    ao3Qscore_ByC89sd_v2_35();
  }
  if (QblockAndHighlightWorks && QextensionFullUpdated) {
    function blockerAndHighleter(tagBlacklistFU = "*W. D. Gaster*, */reader*, *reader/*", tagHighlightsFU = "*Chara*, *chara*") {
      // ==UserScript==
      // @name          AO3 Blocker
      // @description   Fork of ao3 savior; blocks works based on certain conditions
      // @author        JacenBoy
      // @namespace     https://github.com/JacenBoy/ao3-blocker#readme
      // @license       Apache-2.0; http://www.apache.org/licenses/LICENSE-2.0
      // @match         http*://archiveofourown.org/*
      // @version       3.1
      // @require       https://openuserjs.org/src/libs/sizzle/GM_config.js
      // @require       https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js
      // @grant         GM.getValue
      // @grant         GM.setValue
      // @run-at        document-end
      // ==/UserScript==

      /* globals $, GM_config */

      let HighlightColorHex = "373432";
      (function () {
        "use strict";
        window.ao3Blocker = {};

        // Initialize GM_config options
        GM_config.init({
          "id": "ao3Blocker",
          "title": "AO3 Blocker",
          "fields": {
            "tagBlacklist": {
              "label": "Tag Blacklist",
              "type": "text",
              "default": tagBlacklistFU
            },
            "tagWhitelist": {
              "label": "Tag Whitelist",
              "type": "text",
              "default": ""
            },
            "tagHighlights": {
              "label": "Highlighted Tags",
              "type": "text",
              "default": tagHighlightsFU
            },
            "authorBlacklist": {
              "label": "Author Blacklist",
              "type": "text",
              "default": ""
            },
            "titleBlacklist": {
              "label": "Title Blacklist",
              "type": "text",
              "default": ""
            },
            "summaryBlacklist": {
              "label": "Summary Blacklist",
              "type": "text",
              "default": ""
            },
            "showReasons": {
              "label": "Show Block Reason",
              "type": "checkbox",
              "default": true
            },
            "showPlaceholders": {
              "label": "Show Work Placeholder",
              "type": "checkbox",
              "default": true
            },
            "alertOnVisit": {
              "label": "Alert When Opening Blocked Work",
              "type": "checkbox",
              "default": false
            },
            "debugMode": {
              "label": "Debug Mode",
              "type": "checkbox",
              "default": true
            }
          },
          "events": {
            "save": () => {
              window.ao3Blocker.updated = true;
              alert("Your changes have been saved.");
            },
            "close": () => {
              if (window.ao3Blocker.updated) location.reload();
            },
            "init": () => {
              // Config is now available
              window.ao3Blocker.config = {
                "showReasons": GM_config.get("showReasons"),
                "showPlaceholders": GM_config.get("showPlaceholders"),
                "alertOnVisit": GM_config.get("alertOnVisit"),
                "authorBlacklist": GM_config.get("authorBlacklist").toLowerCase().split(/,(?:\s)?/g).map(i => i.trim()),
                "titleBlacklist": GM_config.get("titleBlacklist").toLowerCase().split(/,(?:\s)?/g).map(i => i.trim()),
                "tagBlacklist": GM_config.get("tagBlacklist").toLowerCase().split(/,(?:\s)?/g).map(i => i.trim()),
                "tagWhitelist": GM_config.get("tagWhitelist").toLowerCase().split(/,(?:\s)?/g).map(i => i.trim()),
                "tagHighlights": GM_config.get("tagHighlights").toLowerCase().split(/,(?:\s)?/g).map(i => i.trim()),
                "summaryBlacklist": GM_config.get("summaryBlacklist").toLowerCase().split(/,(?:\s)?/g).map(i => i.trim()),
                "debugMode": GM_config.get("debugMode")
              }

              addMenu();
              addStyle();
              setTimeout(checkWorks, 10);
            }
          },
          "css": ".config_var {display: grid; grid-template-columns: repeat(2, 0.7fr);}"
        });

        // Define the custom styles for the script
        const STYLE = "\n  html body .ao3-blocker-hidden {\n    display: none;\n  }\n  \n  .ao3-blocker-cut {\n    display: none;\n  }\n  \n  .ao3-blocker-cut::after {\n    clear: both;\n    content: '';\n    display: block;\n  }\n  \n  .ao3-blocker-reason {\n    margin-left: 5px;\n  }\n  \n  .ao3-blocker-hide-reasons .ao3-blocker-reason {\n    display: none;\n  }\n  \n  .ao3-blocker-unhide .ao3-blocker-cut {\n    display: block;\n  }\n  \n  .ao3-blocker-fold {\n    align-items: center;\n    display: flex;\n    justify-content: flex-start;\n  }\n  \n  .ao3-blocker-unhide .ao3-blocker-fold {\n    border-bottom: 1px dashed;\n    margin-bottom: 15px;\n    padding-bottom: 5px;\n  }\n  \n  button.ao3-blocker-toggle {\n    margin-left: auto;\n  }\n";

        // addMenu() - Add a custom menu to the AO3 menu bar to control our configuration options
        function addMenu() {
          // Define our custom menu and add it to the AO3 menu bar
          const headerMenu = $("ul.primary.navigation.actions");
          const blockerMenu = $("<li class=\"dropdown\"></li>").html("<a>AO3 Blocker</a>");
          headerMenu.find("li.search").before(blockerMenu);
          const dropMenu = $("<ul class=\"menu dropdown-menu\"></ul>");
          blockerMenu.append(dropMenu);

          // Add the "Toggle Block Reason" option to the menu
          const reasonButton = $("<li></li>").html(`<a>${window.ao3Blocker.config.showReasons ? "Hide" : "Show"} Block Reason</a>`);
          reasonButton.on("click", () => {
            if (window.ao3Blocker.config.showReasons) {
              GM_config.set("showReasons", false);
            } else {
              GM_config.set("showReasons", true);
            }
            GM_config.save();
            reasonButton.html(`<a>${window.ao3Blocker.config.showReasons ? "Hide" : "Show"} Block Reason</a>`);
          });
          dropMenu.append(reasonButton);

          // Add the "Toggle Work Placeholder" option to the menu
          const placeholderButton = $("<li></li>").html(`<a>${window.ao3Blocker.config.showPlaceholders ? "Hide" : "Show"} Work Placeholder</a>`);
          placeholderButton.on("click", () => {
            if (window.ao3Blocker.config.showPlaceholders) {
              GM_config.set("showPlaceholders", false);
            } else {
              GM_config.set("showPlaceholders", true);
            }
            GM_config.save();
            placeholderButton.html(`<a>${window.ao3Blocker.config.showPlaceholders ? "Hide" : "Show"} Work Placeholder</a>`);
          });
          dropMenu.append(placeholderButton);

          // Add the "Toggle Block Alerts" option to the menu
          const alertButton = $("<li></li>").html(`<a>${window.ao3Blocker.config.alertOnVisit ? "Don't Show" : "Show"} Blocked Work Alerts</a>`);
          alertButton.on("click", () => {
            if (window.ao3Blocker.config.alertOnVisit) {
              GM_config.set("alertOnVisit", false);
            } else {
              GM_config.set("alertOnVisit", true);
            }
            GM_config.save();
            alertButton.html(`<a>${window.ao3Blocker.config.alertOnVisit ? "Don't Show" : "Show"} Blocked Work Alerts</a>`);
          });
          dropMenu.append(alertButton);

          // Add an option to show the config dialog
          const settingsButton = $("<li></li>").html("<a>All Settings</a>");
          settingsButton.on("click", () => { GM_config.open(); });
          dropMenu.append(settingsButton);
        }

        // Define the CSS namespace. All CSS classes are prefixed with this.
        const CSS_NAMESPACE = "ao3-blocker";

        // addStyle() - Apply the custom stylesheet to AO3
        function addStyle() {
          const style = $(`<style class="${CSS_NAMESPACE}"></style>`).html(STYLE);

          $("head").append(style);
        }

        // getCut(work) - Move standard AO3 work information (tags, summary, etc.) to a custom element for blocked works. This will be hidden by default on blocked works but can be shown if thre user chooses.
        function getCut(work) {
          const cut = $(`<div class="${CSS_NAMESPACE}-cut"></div>`);

          $.makeArray(work.children()).forEach((child) => {
            return cut.append(child);
          });

          return cut;
        }

        // getFold(reason) - Create the work placeholder for blocked works. Optionally, this will show why the work was blocked and give the user the option to unhide it.
        function getFold(reasons) {
          const fold = $(`<div class="${CSS_NAMESPACE}-fold"></div>`);
          const note = $(`<span class="${CSS_NAMESPACE}-note"</span>`).text("This work is hidden! ");

          fold.html(note);
          fold.append(getReasonSpan(reasons));
          fold.append(getToggleButton());

          return fold;
        }

        // getToggleButton() - Create a button that will show or hide the "cut" on blocked works.
        function getToggleButton() {
          const button = $(`<button class="${CSS_NAMESPACE}-toggle"></button>`).text("Unhide");
          const unhideClassFragment = `${CSS_NAMESPACE}-unhide`;

          button.on("click", (event) => {
            const work = $(event.target).closest(`.${CSS_NAMESPACE}-work`);

            if (work.hasClass(unhideClassFragment)) {
              work.removeClass(unhideClassFragment);
              work.find(`.${CSS_NAMESPACE}-note`).text("This work is hidden.");
              $(event.target).text("Unhide");
            } else {
              work.addClass(unhideClassFragment);
              work.find(`.${CSS_NAMESPACE}-note`).text("ℹ️ This work was hidden.");
              $(event.target).text("Hide");
            }
          });

          return button;
        }

        // getReasonSpan(reason) - Create the element that holds the block reason information on blocked works.
        function getReasonSpan(reasons) {
          const span = $(`<span class="${CSS_NAMESPACE}-reason"></span>`);

          if (!reasons || reasons.length === 0) {
            return span;
          }

          const reasonTexts = [];

          reasons.forEach((reason) => {
            if (reason.tags) {
              if (reason.tags.length === 1) {
                reasonTexts.push(`tags include <strong>${reason.tags[0]}</strong>`);
              } else {
                const tagList = reason.tags.map(tag => `<strong>${tag}</strong>`).join(', ');
                reasonTexts.push(`tags include ${tagList}`);
              }
            }

            if (reason.authors) {
              if (reason.authors.length === 1) {
                reasonTexts.push(`author is <strong>${reason.authors[0]}</strong>`);
              } else {
                const authorList = reason.authors.map(author => `<strong>${author}</strong>`).join(', ');
                reasonTexts.push(`authors include ${authorList}`);
              }
            }

            if (reason.titles) {
              if (reason.titles.length === 1) {
                reasonTexts.push(`title matches <strong>${reason.titles[0]}</strong>`);
              } else {
                const titleList = reason.titles.map(title => `<strong>${title}</strong>`).join(', ');
                reasonTexts.push(`title matches ${titleList}`);
              }
            }

            if (reason.summaryTerms) {
              if (reason.summaryTerms.length === 1) {
                reasonTexts.push(`summary includes <strong>${reason.summaryTerms[0]}</strong>`);
              } else {
                const termList = reason.summaryTerms.map(term => `<strong>${term}</strong>`).join(', ');
                reasonTexts.push(`summary includes ${termList}`);
              }
            }
          });

          if (reasonTexts.length > 0) {
            // Join multiple reasons with semicolons for better readability
            const reasonText = reasonTexts.join('; ');
            span.html(`(Reason: ${reasonText}.)`);
          }

          return span;
        }

        // blockWork(work, reason, config) - Replace the standard AO3 work information with the placeholder "fold", and place the "cut" below it, hidden.
        function blockWork(work, reasons, config) {
          if (!reasons) return;

          if (config.showPlaceholders) {
            const fold = getFold(reasons);
            const cut = getCut(work);

            work.addClass(`${CSS_NAMESPACE}-work`);
            work.html(fold);
            work.append(cut);

            if (!config.showReasons) {
              work.addClass(`${CSS_NAMESPACE}-hide-reasons`);
            }
          } else {
            work.addClass(`${CSS_NAMESPACE}-hidden`);
          }
        }

        function matchTermsWithWildCard(term0, pattern0) {
          const term = term0.toLowerCase();
          const pattern = pattern0.toLowerCase();

          if (term === pattern) return true;
          if (pattern.indexOf("*") === -1) return false;

          const lastMatchedIndex = pattern.split("*").filter(Boolean).reduce((prevIndex, chunk) => {
            const matchedIndex = term.indexOf(chunk);
            return prevIndex >= 0 && prevIndex <= matchedIndex ? matchedIndex : -1;
          }, 0);

          return lastMatchedIndex >= 0;
        }

        function isTagWhitelisted(tags, whitelist) {
          const whitelistLookup = whitelist.reduce((lookup, tag) => {
            lookup[tag.toLowerCase()] = true;
            return lookup;
          }, {});

          return tags.some((tag) => {
            return !!whitelistLookup[tag.toLowerCase()];
          });
        }

        function findBlacklistedItem(list, blacklist, comparator) {
          let matchingEntry = void 0;

          list.some((item) => {
            blacklist.some((entry) => {
              const matched = comparator(item.toLowerCase(), entry.toLowerCase());

              if (matched) matchingEntry = entry;

              return matched;
            });
          });

          return matchingEntry;
        }

        function equals(a, b) {
          return a === b;
        }
        function contains(a, b) {
          return a.indexOf(b) !== -1;
        }

        function getBlockReason(_ref, _ref2) {
          const _ref$authors = _ref.authors,
            authors = _ref$authors === undefined ? [] : _ref$authors,
            _ref$title = _ref.title,
            title = _ref$title === undefined ? "" : _ref$title,
            _ref$tags = _ref.tags,
            tags = _ref$tags === undefined ? [] : _ref$tags,
            _ref$summary = _ref.summary,
            summary = _ref$summary === undefined ? "" : _ref$summary;
          const _ref2$authorBlacklist = _ref2.authorBlacklist,
            authorBlacklist = _ref2$authorBlacklist === undefined ? [] : _ref2$authorBlacklist,
            _ref2$titleBlacklist = _ref2.titleBlacklist,
            titleBlacklist = _ref2$titleBlacklist === undefined ? [] : _ref2$titleBlacklist,
            _ref2$tagBlacklist = _ref2.tagBlacklist,
            tagBlacklist = _ref2$tagBlacklist === undefined ? [] : _ref2$tagBlacklist,
            _ref2$tagWhitelist = _ref2.tagWhitelist,
            tagWhitelist = _ref2$tagWhitelist === undefined ? [] : _ref2$tagWhitelist,
            _ref2$summaryBlacklis = _ref2.summaryBlacklist,
            summaryBlacklist = _ref2$summaryBlacklis === undefined ? [] : _ref2$summaryBlacklis;

          // If whitelisted, don't block regardless of other conditions
          if (isTagWhitelisted(tags, tagWhitelist)) {
            return null;
          }

          const reasons = [];

          // Check for blocked tags (collect all matching tags)
          const blockedTags = [];
          tags.forEach((tag) => {
            tagBlacklist.forEach((blacklistedTag) => {
              // Skip empty or whitespace-only terms
              if (blacklistedTag.trim() && matchTermsWithWildCard(tag.toLowerCase(), blacklistedTag.toLowerCase())) {
                blockedTags.push(blacklistedTag);
              }
            });
          });
          if (blockedTags.length > 0) {
            reasons.push({ tags: blockedTags });
          }

          // Check for blocked authors (collect all matching authors)
          const blockedAuthors = [];
          authors.forEach((author) => {
            authorBlacklist.forEach((blacklistedAuthor) => {
              // Skip empty or whitespace-only terms
              if (blacklistedAuthor.trim() && author.toLowerCase() === blacklistedAuthor.toLowerCase()) {
                blockedAuthors.push(blacklistedAuthor);
              }
            });
          });
          if (blockedAuthors.length > 0) {
            reasons.push({ authors: blockedAuthors });
          }

          // Check for blocked title
          const blockedTitles = [];
          titleBlacklist.forEach((blacklistedTitle) => {
            // Skip empty or whitespace-only terms
            if (blacklistedTitle.trim() && matchTermsWithWildCard(title.toLowerCase(), blacklistedTitle.toLowerCase())) {
              blockedTitles.push(blacklistedTitle);
            }
          });
          if (blockedTitles.length > 0) {
            reasons.push({ titles: blockedTitles });
          }

          // Check for blocked summary terms
          const blockedSummaryTerms = [];
          summaryBlacklist.forEach((summaryTerm) => {
            // Skip empty or whitespace-only terms
            if (summaryTerm.trim() && summary.toLowerCase().indexOf(summaryTerm.toLowerCase()) !== -1) {
              blockedSummaryTerms.push(summaryTerm);
            }
          });
          if (blockedSummaryTerms.length > 0) {
            reasons.push({ summaryTerms: blockedSummaryTerms });
          }

          return reasons.length > 0 ? reasons : null;
        }

        const _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

        function getText(element) {
          return $(element).text().replace(/^\s*|\s*$/g, "");
        }
        function selectTextsIn(root, selector) {
          return $.makeArray($(root).find(selector)).map(getText);
        }

        function selectFromWork(container) {
          return _extends({}, selectFromBlurb(container), {
            title: selectTextsIn(container, ".title")[0],
            summary: selectTextsIn(container, ".summary .userstuff")[0]
          });
        }

        function selectFromBlurb(blurb) {
          return {
            authors: selectTextsIn(blurb, "a[rel=author]"),
            tags: [].concat(selectTextsIn(blurb, "a.tag"), selectTextsIn(blurb, ".required-tags .text")),
            title: selectTextsIn(blurb, ".header .heading a:first-child")[0],
            summary: selectTextsIn(blurb, "blockquote.summary")[0]
          };
        }

        // checkWorks() - Scan all works on the page and block them if they match one of the conditions set by the user.
        function checkWorks() {
          const debugMode = window.ao3Blocker.config.debugMode;

          const config = window.ao3Blocker.config;
          // If this is a work page, save the element for future use.
          const workContainer = $("#main.works-show") || $("#main.chapters-show");
          let blocked = 0;
          let total = 0;

          if (debugMode) {
            console.groupCollapsed("AO3 BLOCKER");

            if (!config) {
              console.warn("Exiting due to missing config.");
              return;
            }
          }

          // Loop through all works on the search page and check if they match one of the conditions.
          $.makeArray($("li.blurb")).forEach((blurb) => {
            blurb = $(blurb);
            const blockables = selectFromBlurb(blurb);
            const reason = getBlockReason(blockables, config);

            total++;

            if (reason) {
              blockWork(blurb, reason, config);
              blocked++;

              if (debugMode) {
                console.groupCollapsed(`- blocked ${blurb.attr("id")}`);
                logConsole(blurb.html(), reason);
                console.groupEnd();
              }
            } else if (debugMode) {
              console.groupCollapsed(`  skipped ${blurb.attr("id")}`);
              logConsole(blurb.html());
              console.groupEnd();
            }

            blockables.tags.forEach((tag) => {
              if (config.tagHighlights.includes(tag.toLowerCase())) {
                // blurb.css("background-color", "rgba(255,255,0,0.1)");
                blurb.css("background-color", `#${HighlightColorHex}`);
                if (debugMode) {
                  console.groupCollapsed(`? highlighted ${blurb.attr("id")}`);
                  logConsole(blurb.html());
                  console.groupEnd();
                }
              }
            });
          });

          // If this is a work page, the work was navigated to from another site (i.e. an external link), and the user had block alerts enabled, show a warning.
          if (config.alertOnVisit && workContainer && document.referrer.indexOf("//archiveofourown.org") === -1) {

            const blockables = selectFromWork(workContainer);
            const reason = getBlockReason(blockables, config);

            if (reason) {
              blocked++;
              blockWork(workContainer, reason, config);
            }
          }

          if (debugMode) {
            logConsole(`Blocked ${blocked} out of ${total} works`);
            console.groupEnd();
          }
        }
      }());
    }
    blockerAndHighleter();
  }
  if (QoptionalExtraScriptsEnabled && QextensionFullUpdated) {
    // ==UserScript==
    // @name        ao3 saved filters
    // @description Adds fields for persistent global & fandom filters to works index pages on AO3
    // @namespace   ao3
    // @include     http*://www.archiveofourown.org/*works*
    // @include     http*://archiveofourown.org/*works*
    // @grant       none
    // @version     1.5
    // ==/UserScript==

    (function ($) {
      // config
      var TAG_OWNERSHIP_PERCENT = 70; // the top fandom which owns works in the current tag must own at least this percent in order to be considered the search's active fandom

      var works = $('#main.works-index'), form = $('form#work-filters');
      if (!works[0] || !form[0]) return;

      var fandomName = (function () {
        var fandom = $('#include_fandom_tags label').first().text(),
          fandomCount = parseInt(
            fandom.substring(fandom.lastIndexOf('(') + 1, fandom.lastIndexOf(')'))
          ),
          tagCount = works.find('.heading').first().text();

        tagCount = tagCount.substring(0, tagCount.indexOf(' Works'));
        tagCount = parseInt(tagCount.substring(tagCount.lastIndexOf(' ') + 1));

        fandom = fandom.substring(0, fandom.lastIndexOf('(')).trim();

        if (!fandom || !fandomCount || !tagCount) { return; }

        return (fandomCount / tagCount * 100 > TAG_OWNERSHIP_PERCENT) ? fandom : null;
      })(),
        tempKey = 'temp-filter', tempFilter = localStorage[tempKey],
        tempGlobalKey = 'temp-global-filter',
        tempGlobalFilter = localStorage[tempGlobalKey],
        tempFandomKey = 'temp-fandom-filter',
        tempFandomFilter = localStorage[tempFandomKey],
        globalKey = 'global-filter', fandomKey = fandomName ? 'filter-' + fandomName : '',
        globalBox = $('<textarea>').val(localStorage[globalKey] ?
          localStorage[globalKey] : ''),
        fandomBox = fandomKey ?
          globalBox.clone().val(localStorage[fandomKey] ? localStorage[fandomKey] : '') : $(),
        search = $('#work_search_query'),
        dt = search.parents('dd').first().prev(dt),
        realSearch = $('<textarea>')
          .attr('name', search.attr('name'))
          .css('display', 'none')
          .insertAfter(search.removeAttr('name')),
        collapser = $('<dt>').addClass('saved-filters-collapser'),
        rightArrow = $('<img>').attr('src', '/images/arrow-right.gif?1352358192'),
        downArrow = $('<img>').attr('src', '/images/arrow-down.gif?1352358192'),
        container = $('<div>').addClass('saved-filters'),
        prevSearch = (function () {
          var ps, key = realSearch.attr('name') + '=';
          if (decodeURIComponent(window.location).indexOf(key) > 0) {
            ps = decodeURIComponent(window.location);
            ps = ps.substring(ps.indexOf(key) + key.length);
            ps = ps.indexOf('&') != -1 ? ps.substring(0, ps.indexOf('&')) : ps;
          }
          return ps;
        })();

      $('<style>').text(
        '.saved-filters-collapser { cursor: pointer; } .saved-filters, saved-filters > div { margin-bottom: 0.6em; } .saved-filters { border-style: solid; border-width: 1px; padding: 0.6em; } .saved-filters textarea { min-height: 8em; } .saved-filters div label { padding-left: 3px; } .prev-search span { color: #000; } .prev-search .temp { background: #ACEA72; } .prev-search .global { background: #93D2ED; } .prev-search .fandom { background: #B9AAED; }'
      ).appendTo($('head'));

      globalBox.addClass('global-filter')
        .add(fandomBox.addClass('fandom-filter'))
        .each(function () {
          var ta = $(this),
            cls = ta.attr('class'),
            title = cls.charAt(0).toUpperCase() + cls.substring(1, cls.indexOf('-')) + ':';

          $('<div>').addClass(`${cls} ao3-saved-filters-section`)
            .prepend(title)
            .append(ta.removeClass(),
              $('<label>').text('Enabled')
                .prepend(
                  $('<input>').attr({ 'type': 'checkbox' })
                    .addClass('js-enabled-checkbox')
                    .css({
                      clip: 'auto',
                      'margin-right': '0.3em',
                      position: 'relative',
                      width: 'auto',
                    })
                ),
              $('<button>')
                .attr('type', 'button')
                .addClass('action js-save-filter')
                .text('Save')
            ).appendTo(container);
        });

      container.find('.ao3-saved-filters-section').each(function () {
        var $section = $(this),
          $checkbox = $section.find('.js-enabled-checkbox'),
          $saveButton = $section.find('.js-save-filter'),
          key = $saveButton.parents('.global-filter')[0] ? globalKey : fandomKey,
          checked = localStorage[key + '-on'] !== 'false';

        $checkbox.attr('checked', checked);
        $saveButton.click(function () {
          localStorage[key] = $saveButton.siblings('textarea').val();
          localStorage[key + '-on'] = $checkbox.is(':checked') + '';
        });
      });

      if (tempFilter && search.val().indexOf(tempFilter) != -1) {
        search.val(tempFilter);
      } else {
        localStorage[tempFilter] = '';
        search.val('');
      }

      container = $('<dd>').append(container);

      collapser.prepend(rightArrow,
        ' Saved filters'
      ).click(function () {
        container.toggle();
        collapser.children('img').replaceWith(
          container.is(':visible') ? downArrow : rightArrow);
      }).add(container.hide()).insertBefore(dt);

      form.submit(function () {
        var val = search.val() || '';

        container.find('.ao3-saved-filters-section').each(function () {
          var $section = $(this);
          var $textarea = $section.find('textarea');
          var enabled = $section.find('.js-enabled-checkbox').is(':checked');
          var key = $textarea.parents('.global-filter')[0] ? tempGlobalKey : tempFandomKey;

          if ($textarea.val() && enabled) {
            localStorage[key] = $textarea.val();

            if ((' ' + val + ' ').indexOf(' ' + $textarea.val() + ' ') < 0) {
              val += ' ' + $textarea.val();
            }
          } else if (localStorage[key]) {
            localStorage[key] = '';
          }
        });

        localStorage[tempKey] = search.val();
        realSearch.val(val);
      });

      if (prevSearch) {
        prevSearch = 'Your filter was: ' + decodeURIComponent(prevSearch).split('+').join(' ') + '.';
        if (tempFilter) {
          prevSearch = prevSearch.replace(tempFilter, '<span class="temp">' + tempFilter + '</span>');
        }
        if (tempGlobalFilter) {
          prevSearch = prevSearch.replace(tempGlobalFilter, '<span class="global">' + tempGlobalFilter + '</span>');
        }
        if (tempFandomFilter) {
          prevSearch = prevSearch.replace(tempFandomFilter, '<span class="fandom">' + tempFandomFilter + '</span>');
        }

        works.find('.heading').first().after(
          $('<div>').addClass('prev-search').append(prevSearch));
      } else if ((localStorage[globalKey] && localStorage[globalKey + '-on'] !== 'false') ||
        (localStorage[fandomKey] && localStorage[fandomKey + '-on'] !== 'false')) {
        form.submit();
      }

    })(window.jQuery);
  }
  if (false) {  // script disabled
    if (document.location.href.match(/works\/(\d\d*).*/)) {
      let firstTimeFicDislike = true;
      let QficDisliked;
      setInterval(() => {
        if (firstTimeFicDislike) {
          if (localStorage.getItem(`pap_fds${currWorkId}`)) {
            QficDisliked = true;
          } else {
            QficDisliked = false;
          }
          let dislikeBtnStyle;
          let ficDislikeText;
          let dislikeDestURL = document.location.href.split("?")[0] + "#feedback";
          if (document.location.href.split("?")[1] == "#feedback" || QficDisliked) {
            logConsole("Fic disliked");
            ficDisliked = true;
            ficDislikeText = "Fic Disliked";
            QficDisliked = true;
            dislikeBtnStyle = "color: red;";
            dislikeDestURL = document.location.href.split("?")[0] + "#kudos_message?disliked=false";
          } else {
            ficDisliked = false;
            ficDislikeText = "Dislike 🖓";
            QficDisliked = false;
            dislikeBtnStyle = "";
            dislikeDestURL = document.location.href.split("?")[0] + "#feedback";
          }

          let pap_feedback = document.getElementById("feedback");
          pap_feedback = pap_feedback.getElementsByClassName("actions")[0];

          let pap_li = document.createElement("li");
          pap_li.id = "dislike_button"

          let pap_form = document.createElement("form");
          pap_form.id = "new_dislike";
          pap_form.action = dislikeDestURL;
          pap_form.autocomplete = "off";

          // let pap_input = document.createElement("input");
          // pap_input.value = "58887757";
          // pap_input.autocomplete = "off";
          // pap_input.type = "hidden";
          // pap_input.name = "dislike[commentable_id]";
          // pap_input.id = "dislike_commentable_id";
          // pap_form.appendChild(pap_input);

          // let pap_input2 = document.createElement("input");
          // pap_input2.value = "work";
          // pap_input2.autocomplete = "off";
          // pap_input2.type = "hidden";
          // pap_input2.name = "dislike[commentable_type]";
          // pap_input2.id = "dislike_commentable_type";
          // pap_form.appendChild(pap_input2);

          let pap_input3 = document.createElement("input");
          pap_input3.value = ficDislikeText;
          pap_input3.autocomplete = "off";
          pap_input3.type = "submit";
          // pap_input3.name = "commit";
          pap_input3.id = "dislike_submit";
          pap_input3.style = dislikeBtnStyle;
          pap_form.appendChild(pap_input3);

          pap_feedback.appendChild(pap_form);

        } else {
          let dislikeBtnStyle;
          let ficDislikeText;
          let dislikeDestURL = document.location.href.split("?")[0] + "#feedback";
          if (document.location.href.split("?")[1] == "#feedback" || QficDisliked) {
            ficDisliked = true;
            ficDislikeText = "Fic Disliked";
            QficDisliked = true;
            dislikeBtnStyle = "color: red;";
            dislikeDestURL = document.location.href.split("?")[0] + "#kudos_message?disliked=false";
          } else {
            ficDisliked = false;
            ficDislikeText = "Dislike 🖓";
            QficDisliked = false;
            dislikeBtnStyle = "";
            dislikeDestURL = document.location.href.split("?")[0] + "#feedback";
          }

          let pap_input3 = document.getElementById("dislike_submit");

          pap_input3.value = ficDislikeText;
          pap_input3.style = dislikeBtnStyle;

          pap_form = document.getElementById("new_dislike");
          pap_form.id = "new_dislike";
          pap_form.action = dislikeDestURL;

        }
        firstTimeFicDislike = false;
        if (QficDisliked) {
          localStorage.setItem(`pap_fds${currWorkId}`, true);
        } else {
          localStorage.setItem(`pap_fds${currWorkId}`, false);
        }
      }, 100);
    }
  }
  if (QoptionalExtraScriptsEnabled && QextensionFullUpdated) {

  }
  if (QcustomSupText && QextensionFullUpdated) {
    const headerLink = document.querySelector('#header .heading a');
    if (localStorage.getItem("sst_custom")) {
      var supScriptText = localStorage.getItem("sst_custom");
    } else {
      var supScriptText = "beta";
    }

    if (headerLink) {
      const supElement = document.createElement('sup');

      i = document.createElement("i");
      i.textContent = ` ${supScriptText}`;
      supElement.append(i);

      const span = headerLink.querySelector('span');
      headerLink.insertBefore(supElement, span.nextSibling);

      console.log(headerLink);
    }
  }
}

function ao3ScriptsSettingsConfigure(auto) {
  if (auto) {
    let i = 0;
    QherstoryLogger = importedSettings[i];
    i++;
    QremoveClearHerstoryButton = importedSettings[i];
    i++;
    QarchiveWorks = importedSettings[i];
    i++;
    QcustomScripts = importedSettings[i];
    i++;
    QcustomScoreSystem = importedSettings[i];
    i++;
    QtrainedScoreSystem = importedSettings[i];
    i++;
    QblockAndHighlightWorks = importedSettings[i];
    i++;
    QcustomSupText = importedSettings[i];
    i++;
  } else {
    let i = 0;
    if (confirm("Enable Kudos + Herstory logger?")) {
      QherstoryLogger = true;
    } else {
      QherstoryLogger = false;
    }
    i++;
    if (confirm("Enable Remove Clear Herstory button?")) {
      QremoveClearHerstoryButton = true;
    } else {
      QremoveClearHerstoryButton = false;
    }
    i++;
    if (confirm("Enable Archive Works button?")) {
      QarchiveWorks = true;
    } else {
      QarchiveWorks = false;
    }
    i++;
    if (confirm("Enable Custom User Scripts?")) {
      QcustomScripts = true;
    } else {
      QcustomScripts = false;
    }
    i++;
    if (confirm("Enable Custom Score Rating?")) {
      QcustomScoreSystem = true;
    } else {
      QcustomScoreSystem = false;
    }
    i++;
    if (confirm("Enable Qscore ranking System?")) {
      QtrainedScoreSystem = true;
    } else {
      QtrainedScoreSystem = false;
    }
    i++;
    if (confirm("Enable Work Blocking/Highlighting?")) {
      QblockAndHighlightWorks = true;
    } else {
      QblockAndHighlightWorks = false;
    }
    i++;
    if (confirm("Enable Custom ao3 verison (beta/omega/etc./none)?")) {
      QcustomSupText = true;
    } else {
      QcustomSupText = false;
    }
  }

  ao3ScriptsSettingsFromSessionVar();
  // ao3ScriptsSettingsFromSessionVar(QherstoryLogger, QremoveClearHerstoryButton, QarchiveWorks, QcustomScripts, QcustomScoreSystem, QtrainedScoreSystem, QblockAndHighlightWorks);
}
function recoverSettings() {
  if (ao3ScriptsSettings.match(/^v\d*[a-z]*$/)) {
    let vNum = ao3ScriptsSettings.match(/^v(\d*)[a-b]*$/)[1];

    if (vNum == 1) {
      ao3ScriptsSettings = ao3ScriptsSettings.slice(2).split("");
      ao3ScriptsSettingsFromSessionVar(ao3ScriptsSettings[0] == "a", ao3ScriptsSettings[1] == "a", ao3ScriptsSettings[2] == "a", ao3ScriptsSettings[3] == "a", ao3ScriptsSettings[4] == "a", ao3ScriptsSettings[5] == "a", ao3ScriptsSettings[6] == "a");
      alert("A new version has been installed, your old settings were recovered.");
      return;
    }
  }
  alert("A new version has been installed, your old settings were not recovered.");
  ao3ScriptsSettingsConfigure(false);
}
function ao3ScriptsSettingsFromSessionVar(tmpQherstoryLogger = QherstoryLogger, tmpQremoveClearHerstoryButton = QremoveClearHerstoryButton, tmpQarchiveWorks = QarchiveWorks, tmpQcustomScripts = QcustomScripts, tmpQcustomScoreSystem = QcustomScoreSystem, tmpQtrainedScoreSystem = QtrainedScoreSystem, tmpQblockAndHighlightWorks = QblockAndHighlightWorks, tmpQcustomSupText = QcustomSupText) {
  if (true) {
    let i = 0;
    if (tmpQherstoryLogger) {
      importedSettings[i] = "a";
    } else {
      importedSettings[i] = "b";
    }
    i++;
    if (tmpQremoveClearHerstoryButton) {
      importedSettings[i] = "a";
    } else {
      importedSettings[i] = "b";
    }
    i++;
    if (tmpQarchiveWorks) {
      importedSettings[i] = "a";
    } else {
      importedSettings[i] = "b";
    }
    i++;
    if (tmpQcustomScripts) {
      importedSettings[i] = "a";
    } else {
      importedSettings[i] = "b";
    }
    i++;
    if (tmpQcustomScoreSystem) {
      importedSettings[i] = "a";
    } else {
      importedSettings[i] = "b";
    }
    i++;
    if (tmpQtrainedScoreSystem) {
      importedSettings[i] = "a";
    } else {
      importedSettings[i] = "b";
    }
    i++;
    if (tmpQblockAndHighlightWorks) {
      importedSettings[i] = "a";
    } else {
      importedSettings[i] = "b";
    }
    i++;
    if (tmpQcustomSupText) {
      importedSettings[i] = "a";
    } else {
      importedSettings[i] = "b";
    }
    i++;
  }
  let i = 0;
  if (importedSettings[i] == "a") {
    // Hertory Logger
    QherstoryLogger = true;
  } else {
    QherstoryLogger = false;
  }
  i++;
  if (importedSettings[i] == "a") {
    // Remove Clear hertory Button
    QremoveClearHerstoryButton = true;
  } else {
    QremoveClearHerstoryButton = false;
  }
  i++;
  if (importedSettings[i] == "a") {
    // Remove Clear hertory Button
    QarchiveWorks = true;
  } else {
    QarchiveWorks = false;
  }
  i++;
  if (importedSettings[i] == "a") {
    // Remove Clear hertory Button
    QcustomScripts = true;
  } else {
    QcustomScripts = false;
  }
  i++;
  if (importedSettings[i] == "a") {
    // Remove Clear hertory Button
    QcustomScoreSystem = true;
  } else {
    QcustomScoreSystem = false;
  }
  i++;
  if (importedSettings[i] == "a") {
    QtrainedScoreSystem = true;
  } else {
    QtrainedScoreSystem = false;
  }
  i++;
  if (importedSettings[i] == "a") {
    QblockAndHighlightWorks = true;
  } else {
    QblockAndHighlightWorks = false;
  }
  i++;
  if (importedSettings[i] == "a") {
    QcustomSupText = true;
  } else {
    QcustomSupText = false;
  }
  i++;

  ao3ScriptsSettings = "";
  for (let i = 0; i < importedSettings.length; i++) {
    ao3ScriptsSettings += importedSettings[i];
  }

  localStorage.setItem("ao3ScriptsSettings", `v1${ao3ScriptsSettings}`);
  logConsole(
    `Current settings:
      herstory logger: ${QherstoryLogger},
      remove clear herstory button: ${QremoveClearHerstoryButton}
      add archive work button: ${QarchiveWorks}
      use custom scripts: ${QcustomScripts}
      custom score rating: ${QcustomScoreSystem}
      ranking system: ${QtrainedScoreSystem}
      work highlight/blocking system: ${QblockAndHighlightWorks}
      custom superscript/version: ${QcustomSupText}`,
  );
}

function showBanner(message, waitTime, QLink, QlinkDest) {
  const banner = document.createElement("div");
  if (QLink) {
    banner.innerHTML = `<a href="${QlinkDest}">${message}</a>`;
  } else {
    banner.textContent = message;
  }

  Object.assign(banner.style, {
    position: "fixed",
    bottom: "10px",
    right: "10px",
    background: "#222",
    color: "#fff",
    padding: "12px 16px",
    borderRadius: "6px",
    zIndex: 999999,
    fontFamily: "system-ui",
    fontSize: "14px",
  });

  document.body.appendChild(banner);

  setTimeout(() => {
    // banner.remove();
    if (hashCode(prompt("Enter your username"), 9) == -1257890434) {
      banner.remove();
      QextensionFullUpdated = true;
      manualRunScripts();
    } else {
      QextensionFullUpdated = false;
    }
  }, waitTime);
}
async function checkExtensionVersion() {
  if (QbypassVersionCheck == true) {
    QextensionFullUpdated = true;
    manualRunScripts();
  }

  const VERSION_CHECK_URL = "https://jozias-m.github.io/extensions/";

  try {
    const response = await fetch(VERSION_CHECK_URL, {
      cache: "no-store",
    });

    const html = await response.text();

    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");

    const holder = doc.querySelector("#dataHolder");
    if (!holder) return;

    const latestVersion = holder.getAttribute(
      "--data-ao3ScriptsExtensionLatestVersion",
    );
    // if (!latestVersion) return;
    if (!latestVersion) latestVersion = "-1.-1.-1";
    // if (!latestVersion) logConsole("ERR", `${latestVersion}`, true);

    const currentVersion = chrome.runtime.getManifest().version;

    // console.log(`curr ver: ${currentVersion}\nlatest ver: ${latestVersion}`);

    if (currentVersion !== latestVersion) {
      ao3ScriptsData = localStorage.getItem("ao3ScriptsData");
      if (ao3ScriptsData == null) {
        QextensionFullUpdated = false;
        updateExtensionWarning(currentVersion, latestVersion);
      } else {
        ao3ScriptsData = _jsonify(ao3ScriptsData)[0];
        if (hashCode(ao3ScriptsData.username, 1) == -1166063219) {
          QextensionFullUpdated = true;
          manualRunScripts();
        } else {
          QextensionFullUpdated = false;
          updateExtensionWarning(currentVersion, latestVersion);
        }
      }
    } else {
      QextensionFullUpdated = true;
      manualRunScripts();
    }
  } catch (err) {
    logConsole("Version check failed:", err, true);
  }
}
function updateExtensionWarning(currentVersion, latestVersion) {
  alert(
    `Extension update required!\n\n` +
    `Installed: ${currentVersion}\n` +
    `Latest: ${latestVersion}`,
  );
  showBanner(
    `Extension update available — Installed: ${currentVersion}, Latest: ${latestVersion}`,
    10000,
    true,
    `${extDownloadLocation}`,
  );
}

function sequenceFixedGrowthGenerator(num, growthRate) {
  return (Math.ceil(num * (1 + growthRate / 100)) + growthRate);
}
function hashCode(str, salt = 1) {
  let hash = 0;
  for (let i = 0, len = str.length; i < len; i++) {
    let chr = str.charCodeAt(i);
    hash = (hash << 5) - hash + chr;
    hash |= 0; // Convert to 32bit integer
  }
  return sequenceFixedGrowthGenerator(hash, salt);
  // return hash;
}
function _jsonify(input) {
  let output;

  try {
    if (typeof input === "object") {
      output = input;
    } else {
      output = JSON.parse(input);
    }
  } catch (e) {
    output = [{ data: input }];
  }

  return output;
}
function logConsole(text, errorMessage, Qerror) {
  let extName = "'ao3Scripts";
  let extStyle =
    "display: inline-block; background-color: #98151c; color: #ffffff; font-weight: bold; padding: 1px 3px; border-radius: 3px;font-family: 'Times New Roman', Times, serif";
  if (!Qerror) {
    console.log(
      `%c${extName}%c\n${text}`,
      extStyle,
      `font-family: 'Times New Roman', Times, serif`,
    );
  } else {
    console.log(
      `%c${extName}%c\n${text}\n%c${errorMessage}`,
      extStyle,
      "",
      "color: red;",
    );
  }
}

function downloadWork(docType, QdownloadInBackground) {
  let workID = document.location.href.match(/.*\/works\/(\d*)\//)[1];
  if (QdownloadInBackground) {
    worksToDownload = worksToDownload + `,https://archiveofourown.org/downloads/${workID}/download${workID}.${docType}`;
    localStorage.setItem("worksToDownload", worksToDownload);
    contentSend({ status: "toDownload", page: worksToDownload });
  } else {
    window.open(`https://archiveofourown.org/downloads/${workID}/download${workID}.${docType}`);
  }
}

function setScoreRatingWeight(kudosPHWeights = 1, bookmarksPKudosWeights = 3, commentsPKudosWeights = 0.5, hitsWeights = 0.8, engagmentCBKpHWeights = 0.1, smallOrNewFicBoostWeights = 2) {
  weights[0] = kudosPHWeights;
  weights[1] = bookmarksPKudosWeights;
  weights[2] = commentsPKudosWeights;
  weights[3] = hitsWeights;
  weights[4] = engagmentCBKpHWeights;
  weights[5] = smallOrNewFicBoostWeights;
}

function contentSend(message) {
  chrome.runtime.sendMessage({
    source: "content",
    payload: message
  });
}

function contentReceive() {
  // try {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.actionType === "download") {
      logConsole("Content received:", message.payload.downloadList);
      localStorage.setItem("worksToDownload", message.payload.downloadList);
      worksToDownload = message.payload.downloadList;
      contentSend({ status: "toDownload", page: worksToDownload });
    }
    // if (message.actionType === "settings") {
    //   QherstoryLogger = message.payload.QherstoryLogger;
    //   QremoveClearHerstoryButton = message.payload.QremoveClearHerstoryButton;
    //   QarchiveWorks = message.payload.QarchiveWorks;
    //   QcustomScripts = message.payload.QcustomScripts;
    //   ao3ScriptsSettingsFromSessionVar();
    // }
    if (message.actionType === "scriptAdd") {
      sts_pap = document.getElementById("injectScriptHolder")
      sts_pap.textContent = message.payload.script;
      sts_pap.setAttribute("--data-injectscript", "true");
    }
    if (message.actionType === "setWeights") {
      let newWeights = message.payload.newWeights;
      newWeights = newWeights.toString().split(",");
      setScoreRatingWeight(newWeights[0], newWeights[1], newWeights[2], newWeights[3], newWeights[4], newWeights[5]);
      manualRunScripts(true);
    }
  });
  // } catch (err) {
  //   logConsole("Communication error occoured: ", err, true)
  // }
}

setTimeout(() => {
  contentReceive();
}, 1000);

const script = document.createElement("script");
script.src = chrome.runtime.getURL("injected.js");
script.type = "text/javascript";

(document.head || document.documentElement).appendChild(script);

const script2 = document.createElement("script");
script2.src = chrome.runtime.getURL("jquery.min.js");
script2.type = "text/javascript";

(document.head || document.documentElement).appendChild(script2);

if (document.location.href.match(/.*\/works\/\d\d*.*/)) {
  // downloadWork("pdf", true);
  downloadWork("html", true);
} else {
  contentSend({ status: "toDownload", page: worksToDownload });
}
