let links = [];
let downloadList;
let downloadItemCounter = localStorage.getItem("pap_downloadItemCounter");
if (downloadItemCounter == null) downloadItemCounter = 9
downloadItemCounter = sequenceFixedGrowthGenerator(downloadItemCounter, 1);
localStorage.setItem("pap_downloadItemCounter", downloadItemCounter);

function popupSend(message, source = "popup") {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;

    chrome.tabs.sendMessage(tabs[0].id, {
      source: source,
      payload: message
    });
  });
}

function popupReceive() {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log("Popup received:", message.payload);
    downloadList = message.payload.page.toString().split(",");
    if (downloadList) downloadList.shift()
    if (downloadList) downloadItems(1, false)
  });
}


function downloadItems(downloadedItemsCount, Qbool) {
  QdownloadFileUpdateNeeded = false;
  if (downloadedItemsCount == 0) {
    return;
  }
  if (downloadList == undefined) {
    return;
  }
  if (downloadList[0] == null) {
    return;
  }

  for (let i = 0; i < downloadedItemsCount; i++) {
    console.log(downloadList[i]);
    localStorage.setItem(`pap_${downloadItemCounter}`, downloadList[i]);
    localStorage.setItem("pap_downloadIndex", localStorage.getItem("pap_downloadIndex") + "," + downloadItemCounter)
    downloadItemCounter = sequenceFixedGrowthGenerator(downloadItemCounter, 1);
    localStorage.setItem("pap_downloadItemCounter", downloadItemCounter);
    if (!downloadList[i]) Qbool = true;
  }

  if (!Qbool) {
    popupSend({ action: "post", downloadList: downloadList.slice(downloadedItemsCount) });
  }
}

function updateDownload() {
  downloadItems(1, false);

  downloadIndex = localStorage.getItem("pap_downloadIndex");
  if (downloadIndex) {
    downloadIndex = downloadIndex.toString().split(",");
    for (let i = 0; i < downloadIndex.length; i++) {
      links[i] = localStorage.getItem(`pap_${downloadIndex[i]}`);
    }
    for (let i = 0; i < links.length; i++) {
      if (links[i] && links[i] != 'null' && links[i] != 'undefined') {
        console.log(`${links[i]}`);
      }
    }
    let fileDownloadList = document.getElementById("fileDownloadList");
    fileDownloadList.textContent = "";
    for (let i = 0; i < links.length; i++) {
      let div = document.createElement("div");

      div.className = "fileDownloadListItem";
      div.setAttribute("--data-downloadItem", `${links[i]}`);
      // div.textContent = ``;

      let a = document.createElement("a");

      a.href = `${links[i]}`;
      a.innerText = `${links[i]}`;

      div.appendChild(a);

      fileDownloadList.appendChild(div);
    }
  }
}

function downloadAll() {
  downloadIndex = localStorage.getItem("pap_downloadIndex").toString().split(",");
  localStorage.removeItem("pap_downloadIndex");
  for (let i = 0; i < downloadIndex.length; i++) {
    links[i] = localStorage.getItem(`pap_${downloadIndex[i]}`);
    console.log(links[i]);
    localStorage.removeItem(`pap_${downloadIndex[i]}`);
  }
  downloadItemCounter = 9;
  downloadItemCounter = sequenceFixedGrowthGenerator(downloadItemCounter, 1);
  localStorage.setItem("pap_downloadItemCounter", downloadItemCounter);
  for (let i = 0; i < links.length; i++) {
    if (links[i] && links[i] != 'null' && links[i] != 'undefined') {
      console.log(`${links[i]}`);
      window.open(links[i]);
    }
  }
}

updateDownload();
popupReceive();

function sequenceFixedGrowthGenerator(num, growthRate) {
  return (Math.ceil(num * (1 + growthRate / 100)) + growthRate);
}
function generateIndependentSeeds(growthRate, maxSeeds = 10) {
  const f = (n) =>
    Math.ceil(n * (1 + growthRate / 100)) + growthRate;

  const visited = new Set();
  const seeds = [];

  let candidate = 1;

  while (seeds.length < maxSeeds) {
    if (!visited.has(candidate)) {
      // new independent seed found
      seeds.push(candidate);

      // generate its sequence until Infinity
      let n = candidate;
      while (Number.isFinite(n) && !visited.has(n)) {
        visited.add(n);
        n = f(n);
      }
    }
    candidate++;
  }

  return seeds;
}
// generateIndependentSeeds(9, i).slice(-1)[0];

function hertoryLoggerToggleButtonF() {
  hertoryLoggerToggleButton = document.getElementById("hertoryLoggerToggleButton");
  if (hertoryLoggerToggleButton.innerText == "on") {
    hertoryLoggerToggleButton.innerText = "off";
  } else {
    hertoryLoggerToggleButton.innerText = "on";
  }
  updateSettings()
}
function removeHerstorybtnToggleButtonF() {
  removeHerstorybtnToggleButton = document.getElementById("removeHerstorybtnToggleButton");
  if (removeHerstorybtnToggleButton.innerText == "on") {
    removeHerstorybtnToggleButton.innerText = "off";
  } else {
    removeHerstorybtnToggleButton.innerText = "on";
  }
  updateSettings()
}
function archiveWorksToggleButtonF() {
  archiveWorksToggleButton = document.getElementById("archiveWorksToggleButton");
  if (archiveWorksToggleButton.innerText == "on") {
    archiveWorksToggleButton.innerText = "off";
  } else {
    archiveWorksToggleButton.innerText = "on";
  }
  updateSettings()
}
function updateSettings() {
  if (hertoryLoggerToggleButton.innerText == "on") QherstoryLogger = true;
  if (removeHerstorybtnToggleButton.innerText == "on") QremoveClearHerstoryButton = true;
  if (archiveWorksToggleButton.innerText == "on") QarchiveWorks = true;

  if (hertoryLoggerToggleButton.innerText == "off") QherstoryLogger = false;
  if (removeHerstorybtnToggleButton.innerText == "off") QremoveClearHerstoryButton = false;
  if (archiveWorksToggleButton.innerText == "off") QarchiveWorks = false;

    popupSend({ action: "post", QherstoryLogger: QherstoryLogger, QremoveClearHerstoryButton: QremoveClearHerstoryButton, QarchiveWorks: QarchiveWorks }, "settings");
}


document.addEventListener("DOMContentLoaded", () => {
  const downloadBtn = document.getElementById("downloadAll");

  downloadBtn.addEventListener("click", downloadAll);


  const downloadBtn2 = document.getElementById("updateDownload");

  downloadBtn2.addEventListener("click", updateDownload);

  updateDownload();

  const hertoryLoggerToggleButton = document.getElementById("hertoryLoggerToggleButton");
  const removeHerstorybtnToggleButton = document.getElementById("removeHerstorybtnToggleButton");
  const archiveWorksToggleButton = document.getElementById("archiveWorksToggleButton");

  hertoryLoggerToggleButton.addEventListener("click", hertoryLoggerToggleButtonF);
  removeHerstorybtnToggleButton.addEventListener("click", removeHerstorybtnToggleButtonF);
  archiveWorksToggleButton.addEventListener("click", archiveWorksToggleButtonF);
});